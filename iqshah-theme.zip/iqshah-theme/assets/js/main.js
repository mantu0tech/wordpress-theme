document.addEventListener('DOMContentLoaded', function () {

	/* -----------------------------------------------------
	 * Mobile menu toggle
	 * --------------------------------------------------- */
	var toggle = document.querySelector('.iq-menu-toggle');
	var mobileNav = document.querySelector('.iq-mobile-nav');
	if (toggle && mobileNav) {
		toggle.addEventListener('click', function () {
			var isOpen = mobileNav.classList.toggle('is-open');
			toggle.classList.toggle('is-active', isOpen);
			toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
		});
		// Close mobile menu when a link is clicked
		mobileNav.querySelectorAll('a').forEach(function (link) {
			link.addEventListener('click', function () {
				mobileNav.classList.remove('is-open');
				toggle.classList.remove('is-active');
			});
		});
	}

	/* -----------------------------------------------------
	 * Scroll reveal animations
	 * --------------------------------------------------- */
	var animatedEls = document.querySelectorAll('[data-animate]');
	if ('IntersectionObserver' in window && animatedEls.length) {
		var observer = new IntersectionObserver(function (entries) {
			entries.forEach(function (entry) {
				if (entry.isIntersecting) {
					entry.target.classList.add('iq-visible');
					observer.unobserve(entry.target);
				}
			});
		}, { threshold: 0.15 });
		animatedEls.forEach(function (el) { observer.observe(el); });
	} else {
		animatedEls.forEach(function (el) { el.classList.add('iq-visible'); });
	}

	/* -----------------------------------------------------
	 * Password show/hide toggle
	 * --------------------------------------------------- */
	document.querySelectorAll('.iq-password-toggle').forEach(function (btn) {
		btn.addEventListener('click', function () {
			var input = btn.previousElementSibling;
			if (!input) return;
			var isPassword = input.getAttribute('type') === 'password';
			input.setAttribute('type', isPassword ? 'text' : 'password');
			btn.textContent = isPassword ? '🙈' : '👁';
		});
	});

	/* -----------------------------------------------------
	 * Landing page countdown (resets daily at midnight, for urgency)
	 * --------------------------------------------------- */
	var countdownEl = document.getElementById('iq-countdown');
	if (countdownEl) {
		function renderCountdown() {
			var now = new Date();
			var endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
			var diff = endOfMonth - now;
			if (diff < 0) diff = 0;

			var days = Math.floor(diff / (1000 * 60 * 60 * 24));
			var hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
			var mins = Math.floor((diff / (1000 * 60)) % 60);
			var secs = Math.floor((diff / 1000) % 60);

			countdownEl.innerHTML =
				'<span><span class="iq-countdown-num">' + days + '</span><span class="iq-countdown-label">Days</span></span>' +
				'<span><span class="iq-countdown-num">' + hours + '</span><span class="iq-countdown-label">Hrs</span></span>' +
				'<span><span class="iq-countdown-num">' + mins + '</span><span class="iq-countdown-label">Min</span></span>' +
				'<span><span class="iq-countdown-num">' + secs + '</span><span class="iq-countdown-label">Sec</span></span>';
		}
		renderCountdown();
		setInterval(renderCountdown, 1000);
	}

	/* -----------------------------------------------------
	 * Sticky header shrink on scroll
	 * --------------------------------------------------- */
	var header = document.querySelector('.iq-header');
	if (header) {
		var lastY = window.scrollY;
		window.addEventListener('scroll', function () {
			if (window.scrollY > 40) {
				header.classList.add('iq-scrolled');
			} else {
				header.classList.remove('iq-scrolled');
			}
			lastY = window.scrollY;
		}, { passive: true });
	}

	/* -----------------------------------------------------
	 * Basic client-side validation feedback for required fields
	 * (native HTML5 validation already blocks submit; this just
	 * adds a visual nudge class on invalid attempt)
	 * --------------------------------------------------- */
	document.querySelectorAll('form.iq-form').forEach(function (form) {
		form.addEventListener('submit', function (e) {
			var invalid = form.querySelectorAll(':invalid');
			if (invalid.length) {
				invalid.forEach(function (el) { el.classList.add('iq-field-invalid'); });
			}
		});
	});

});
