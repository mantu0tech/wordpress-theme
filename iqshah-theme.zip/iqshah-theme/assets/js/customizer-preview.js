(function( $ ) {
	var map = {
		'iqshah_color_primary': '--iq-maroon',
		'iqshah_color_primary_dark': '--iq-maroon-dark',
		'iqshah_color_accent': '--iq-gold',
		'iqshah_color_accent_light': '--iq-gold-light',
		'iqshah_color_bg': '--iq-cream',
		'iqshah_color_bg_dark': '--iq-cream-dark',
		'iqshah_color_text': '--iq-text'
	};
	Object.keys( map ).forEach( function( settingId ) {
		wp.customize( settingId, function( value ) {
			value.bind( function( newval ) {
				document.documentElement.style.setProperty( map[ settingId ], newval );
			} );
		} );
	} );
})( jQuery );
