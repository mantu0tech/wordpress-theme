<?php
/**
 * IQSHAH Theme functions
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'IQSHAH_VERSION', '1.0.0' );
define( 'IQSHAH_DIR', get_template_directory() );
define( 'IQSHAH_URI', get_template_directory_uri() );

/* ---------------------------------------------------------
 * Theme Setup
 * ------------------------------------------------------- */
function iqshah_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array(
		'height'      => 90,
		'width'       => 220,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'iqshah' ),
		'footer'  => __( 'Footer Menu', 'iqshah' ),
	) );
}
add_action( 'after_setup_theme', 'iqshah_setup' );

/* ---------------------------------------------------------
 * Widget areas
 * ------------------------------------------------------- */
function iqshah_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Footer Column 1', 'iqshah' ),
		'id'            => 'footer-1',
		'before_widget' => '<div class="footer-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="footer-widget-title">',
		'after_title'   => '</h4>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Column 2', 'iqshah' ),
		'id'            => 'footer-2',
		'before_widget' => '<div class="footer-widget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="footer-widget-title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'iqshah_widgets_init' );

/* ---------------------------------------------------------
 * Scripts & Styles
 * ------------------------------------------------------- */
function iqshah_scripts() {
	wp_enqueue_style( 'iqshah-google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,600;0,700;1,500&family=Poppins:wght@300;400;500;600;700&display=swap', array(), null );
	wp_enqueue_style( 'iqshah-main', IQSHAH_URI . '/assets/css/main.css', array(), IQSHAH_VERSION );

	wp_enqueue_script( 'iqshah-main', IQSHAH_URI . '/assets/js/main.js', array(), IQSHAH_VERSION, true );
	wp_localize_script( 'iqshah-main', 'iqshahData', array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'iqshah_nonce' ),
	) );

	if ( is_singular() ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'iqshah_scripts' );

/* ---------------------------------------------------------
 * Inline CSS variables from Customizer colors
 * ------------------------------------------------------- */
function iqshah_dynamic_css() {
	$maroon      = get_theme_mod( 'iqshah_color_primary', '#6B1226' );
	$maroon_dark = get_theme_mod( 'iqshah_color_primary_dark', '#4A0C1A' );
	$gold        = get_theme_mod( 'iqshah_color_accent', '#C6A250' );
	$gold_light  = get_theme_mod( 'iqshah_color_accent_light', '#E4CC94' );
	$cream       = get_theme_mod( 'iqshah_color_bg', '#FAF6EB' );
	$cream_dark  = get_theme_mod( 'iqshah_color_bg_dark', '#F0E6D2' );
	$text        = get_theme_mod( 'iqshah_color_text', '#2B1810' );
	?>
	<style id="iqshah-dynamic-css">
		:root{
			--iq-maroon: <?php echo esc_html( $maroon ); ?>;
			--iq-maroon-dark: <?php echo esc_html( $maroon_dark ); ?>;
			--iq-gold: <?php echo esc_html( $gold ); ?>;
			--iq-gold-light: <?php echo esc_html( $gold_light ); ?>;
			--iq-cream: <?php echo esc_html( $cream ); ?>;
			--iq-cream-dark: <?php echo esc_html( $cream_dark ); ?>;
			--iq-text: <?php echo esc_html( $text ); ?>;
		}
	</style>
	<?php
}
add_action( 'wp_head', 'iqshah_dynamic_css', 5 );

/* ---------------------------------------------------------
 * Includes
 * ------------------------------------------------------- */
require IQSHAH_DIR . '/inc/customizer.php';
require IQSHAH_DIR . '/inc/cpt-testimonials.php';
require IQSHAH_DIR . '/inc/cpt-leads.php';
require IQSHAH_DIR . '/inc/auth-handlers.php';
require IQSHAH_DIR . '/inc/template-tags.php';
require IQSHAH_DIR . '/inc/default-content.php';

/* ---------------------------------------------------------
 * Misc cleanups
 * ------------------------------------------------------- */

// Remove WooCommerce default wrappers so our own markup in header/footer controls layout
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
function iqshah_wc_wrapper_start() {
	echo '<main id="primary" class="site-main woocommerce-page"><div class="container">';
}
add_action( 'woocommerce_before_main_content', 'iqshah_wc_wrapper_start', 10 );
function iqshah_wc_wrapper_end() {
	echo '</div></main>';
}
add_action( 'woocommerce_after_main_content', 'iqshah_wc_wrapper_end', 10 );

// Change number of products per row / per page (editable defaults, still filterable)
add_filter( 'loop_shop_columns', function() { return 3; } );

// Excerpt length
add_filter( 'excerpt_length', function( $length ) { return 22; } );

// Body classes
add_filter( 'body_class', function( $classes ) {
	if ( is_front_page() ) $classes[] = 'iqshah-home';
	return $classes;
} );

/* ---------------------------------------------------------
 * Brand the native wp-login.php (used by admins/staff via
 * wp-admin, or as a fallback) with IQSHAH colors + logo.
 * ------------------------------------------------------- */
function iqshah_login_logo() {
	$maroon = get_theme_mod( 'iqshah_color_primary', '#6B1226' );
	$gold   = get_theme_mod( 'iqshah_color_accent', '#C6A250' );
	$cream  = get_theme_mod( 'iqshah_color_bg', '#FAF6EB' );
	?>
	<style>
		body.login{ background: <?php echo esc_html( $cream ); ?>; }
		body.login #login h1 a{
			background-image: url('<?php echo esc_url( IQSHAH_URI . '/assets/images/logo.jpg' ); ?>');
			background-size: contain; width: 220px; height: 90px;
		}
		body.login form{ border-radius: 14px; box-shadow: 0 10px 30px rgba(107,18,38,.12); }
		body.login .button-primary{ background: <?php echo esc_html( $maroon ); ?> !important; border-color: <?php echo esc_html( $maroon ); ?> !important; border-radius: 50px !important; }
		body.login #backtoblog a, body.login #nav a{ color: <?php echo esc_html( $maroon ); ?>; }
		body.login input[type="text"]:focus, body.login input[type="password"]:focus{ border-color: <?php echo esc_html( $gold ); ?> !important; box-shadow: 0 0 0 1px <?php echo esc_html( $gold ); ?> !important; }
	</style>
	<?php
}
add_action( 'login_enqueue_scripts', 'iqshah_login_logo' );
add_filter( 'login_headerurl', function() { return home_url( '/' ); } );
add_filter( 'login_headertext', function() { return get_bloginfo( 'name' ); } );
