<?php
/* Template Name: Landing Page */
if ( ! defined( 'ABSPATH' ) ) exit;
$booked = isset( $_GET['booked'] );
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'iq-landing-body' ); ?>>
<?php wp_body_open(); ?>

<div class="iq-landing-wrap">

	<header class="iq-landing-header">
		<div class="container iq-landing-header-inner">
			<?php if ( has_custom_logo() ) : the_custom_logo(); else : ?>
				<img src="<?php echo esc_url( IQSHAH_URI . '/assets/images/logo.jpg' ); ?>" alt="<?php bloginfo('name'); ?>" class="iq-default-logo">
			<?php endif; ?>
			<a href="https://wa.me/<?php echo esc_attr( preg_replace( '/[^0-9]/', '', get_theme_mod( 'iqshah_whatsapp', '918369766855' ) ) ); ?>" target="_blank" rel="noopener" class="iq-btn iq-btn-outline iq-btn-sm">Chat on WhatsApp</a>
		</div>
	</header>

	<section class="iq-landing-hero">
		<div class="container iq-narrow iq-center" data-animate="fade-up">
			<h1><?php echo esc_html( get_theme_mod( 'iqshah_landing_headline', 'Stop Guessing Your Size. Get It Right the First Time — Free.' ) ); ?></h1>
			<p class="iq-landing-sub"><?php echo esc_html( get_theme_mod( 'iqshah_landing_subheadline', '' ) ); ?></p>
			<a href="#iq-lead-form" class="iq-btn iq-btn-primary iq-btn-xl iq-pulse"><?php echo esc_html( get_theme_mod( 'iqshah_landing_cta', 'Claim My Free Consultation' ) ); ?></a>
		</div>
	</section>

	<section class="iq-section iq-landing-why">
		<div class="container iq-narrow iq-center" data-animate="fade-up">
			<h2>Why This Matters</h2>
			<p>You've ordered clothes online before and regretted it — too tight, too loose, the wrong cut for your body. A free Fit Consultation means you talk to a real person (one of us!) who walks you through sizing, fabric, and style before you spend a single rupee. Then, when you're ready, your ₹300 discount is already waiting.</p>
		</div>
	</section>

	<section class="iq-section iq-landing-proof">
		<div class="container iq-narrow iq-center" data-animate="fade-up">
			<blockquote class="iq-landing-quote">
				"The fit consultation alone was worth it — I finally understood why store-bought sizes never worked for me. My custom dress fit perfectly on the first try."
				<footer>— Pooja, 27</footer>
			</blockquote>
			<p class="iq-landing-stat"><?php echo esc_html( get_theme_mod( 'iqshah_landing_proof_stat', '127 women have booked a Fit Consultation this month.' ) ); ?></p>
		</div>
	</section>

	<section class="iq-section iq-landing-urgency">
		<div class="container iq-narrow iq-center" data-animate="fade-up">
			<div class="iq-urgency-box">
				<p><?php echo esc_html( get_theme_mod( 'iqshah_landing_urgency', "This offer is limited to the first 50 bookings this month — after that, the ₹300 discount closes until next month's batch opens." ) ); ?></p>
				<div class="iq-countdown" id="iq-countdown" aria-label="Offer countdown timer"></div>
			</div>
		</div>
	</section>

	<section class="iq-section iq-lead-form-section" id="iq-lead-form">
		<div class="container iq-narrow" data-animate="fade-up">

			<?php if ( $booked ) : ?>
				<div class="iq-form-success" role="status">
					✅ You're booked! We'll reach out on WhatsApp within 24 hours to schedule your free Fit Consultation.
				</div>
			<?php else : ?>

				<h2 class="iq-center">Yes, Book My Free Consultation Now</h2>
				<p class="iq-center iq-form-note">Takes less than 2 minutes. No payment required.</p>

				<form class="iq-form iq-lead-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="iqshah_landing_lead">
					<?php wp_nonce_field( 'iqshah_landing_action', 'iqshah_landing_nonce' ); ?>
					<input type="text" name="iqshah_hp" class="iq-honeypot" tabindex="-1" autocomplete="off">

					<div class="iq-form-row">
						<label for="l_name">Name</label>
						<input type="text" id="l_name" name="iqshah_name" required placeholder="Your full name">
					</div>
					<div class="iq-form-row iq-form-row-half">
						<div>
							<label for="l_whatsapp">WhatsApp Number</label>
							<input type="tel" id="l_whatsapp" name="iqshah_whatsapp" required placeholder="+91 XXXXX XXXXX">
						</div>
						<div>
							<label for="l_email">Email (optional)</label>
							<input type="email" id="l_email" name="iqshah_email" placeholder="you@email.com">
						</div>
					</div>
					<div class="iq-form-row">
						<label for="l_message">Anything specific you'd like help with?</label>
						<textarea id="l_message" name="iqshah_message" rows="3" placeholder="e.g. sizing for a wedding lehenga..."></textarea>
					</div>
					<button type="submit" class="iq-btn iq-btn-primary iq-btn-xl iq-btn-block"><?php echo esc_html( get_theme_mod( 'iqshah_landing_cta', 'Claim My Free Consultation' ) ); ?></button>
					<p class="iq-form-microcopy">🔒 No spam. No obligation. Just a real conversation about your fit.</p>
				</form>
			<?php endif; ?>
		</div>
	</section>

	<footer class="iq-landing-footer">
		<div class="container iq-center">
			<p><?php echo esc_html( get_theme_mod( 'iqshah_footer_copyright', '© ' . date('Y') . ' IQSHAH. All rights reserved.' ) ); ?></p>
			<?php iqshah_social_links( 'iq-social-links iq-center' ); ?>
		</div>
	</footer>
</div>

<?php wp_footer(); ?>
</body>
</html>
