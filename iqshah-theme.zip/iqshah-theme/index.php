<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>
<main id="primary" class="site-main">
	<div class="container iq-generic-page">
		<?php if ( have_posts() ) : ?>
			<div class="iq-post-grid">
				<?php while ( have_posts() ) : the_post(); ?>
					<article id="post-<?php the_ID(); ?>" <?php post_class( 'iq-post-card' ); ?>>
						<?php if ( has_post_thumbnail() ) : ?>
							<a href="<?php the_permalink(); ?>" class="iq-post-thumb"><?php the_post_thumbnail( 'medium_large' ); ?></a>
						<?php endif; ?>
						<div class="iq-post-body">
							<h2 class="iq-post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
							<div class="iq-post-excerpt"><?php the_excerpt(); ?></div>
							<a href="<?php the_permalink(); ?>" class="iq-btn iq-btn-ghost-sm">Read More</a>
						</div>
					</article>
				<?php endwhile; ?>
			</div>
			<div class="iq-pagination"><?php the_posts_pagination(); ?></div>
		<?php else : ?>
			<p><?php esc_html_e( 'Nothing found here.', 'iqshah' ); ?></p>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
