# IQSHAH WordPress Theme

Custom theme for **IQSHAH — Always Beautiful**, built around your logo colors:
- Maroon `#6B1226`
- Gold `#C6A250`
- Cream `#FAF6EB`

## 1. Installation

1. Zip the `iqshah-theme` folder (already done: `iqshah-theme.zip`).
2. In wp-admin go to **Appearance → Themes → Add New → Upload Theme**, choose the zip, install, and **Activate**.
3. On activation the theme automatically creates these pages for you:
   - Home (set as your homepage)
   - About Us
   - Products
   - Contact
   - Free Fit Consultation (the ads landing page)
   - Login
   - Register
4. It also creates a **Main Menu** with Home / About / Products / Contact and assigns it automatically.
5. Go to **Settings → General** to make sure your Site Title/Tagline are set.

## 2. Install WooCommerce (required for the Products page & cart/checkout)

1. **Plugins → Add New**, search "WooCommerce", install & activate.
2. Run the WooCommerce setup wizard (store address, currency ₹ INR, payment methods).
3. Add your products under **Products → Add New**, and organize them into categories like "Custom Dresses", "Ready-to-Wear", "Dupattas" — these show automatically on the Products page and Shop.
4. WooCommerce automatically creates Cart, Checkout, and My Account pages — the theme is already styled to match.

## 3. What You Can Edit Yourself (no coding needed)

Go to **Appearance → Customize**:

- **IQSHAH Brand Colors** — change maroon/gold/cream anytime; whole site updates.
- **Contact & Social Links** — your email, WhatsApp number, Instagram, Facebook, address. These automatically update the header bar, footer, WhatsApp floating button, and Contact page.
- **Homepage Content** — hero headline/subheadline/buttons, pain-point section, the 4 "IQSHAH Difference" blocks, trust strip, final CTA — all editable text fields.
- **Landing Page (Ads) Settings** — headline, subheadline, CTA button text, proof stat, urgency line for your ad campaigns.
- **Footer Settings** — tagline & copyright line.
- **Site Identity** — upload your logo (replaces the default logo image) and set a site icon (favicon).

Go to the **Pages** section in wp-admin to edit the About Us page story and Contact page intro directly with the normal WordPress editor (Gutenberg blocks) — just like any Word doc.

Go to **Testimonials** in the left admin menu to add/edit/delete customer reviews shown on the homepage (name = title, quote = content, plus a "Role / Location" field and star rating).

Go to **Form Submissions** in the left admin menu to see every Contact form and Free Consultation booking submitted on the site — no external plugin needed, it's all stored inside WordPress.

## 4. Login / Register

- `/login/` works for **everyone** — customers land on their My Account page, Administrators/Shop Managers/Editors are redirected straight to `/wp-admin`.
- `/register/` creates a **customer** account (for shopping, order history). Staff/admin accounts should still be created by you under **Users → Add New** for security.
- The native `/wp-login.php` screen is also re-styled with your logo and colors as a backup entry point.

## 5. Your Contact Details (pre-filled, editable in Customizer)

- Email: hello.iqshah@gmail.com
- WhatsApp: +91 83697 66855
- Instagram: @iqshah_ethnic
- Facebook: iqshah_ethnic

## 6. Fully Responsive

Every page — Home, About, Products, Contact, Landing, Login, Register, and all WooCommerce shop/cart/checkout pages — is mobile, tablet, and desktop responsive, with a slide-down mobile menu and a tap-friendly floating WhatsApp button.

## 7. File Structure (for a developer, if needed later)

```
iqshah-theme/
├── style.css              → theme header (required by WP)
├── functions.php          → theme setup, enqueues, hooks
├── header.php / footer.php
├── front-page.php          → Home
├── page-about.php          → About Us template
├── page-products.php       → Products template (WooCommerce)
├── page-contact.php        → Contact template + form
├── page-landing.php        → Ads Landing Page template (own header/footer)
├── page-login.php / page-register.php
├── index.php               → fallback/blog template
├── inc/
│   ├── customizer.php      → all Customizer panels/sections
│   ├── cpt-testimonials.php→ Testimonials post type
│   ├── cpt-leads.php       → Form Submissions post type
│   ├── auth-handlers.php   → login/register/contact/landing form processing
│   ├── template-tags.php   → reusable helper functions
│   └── default-content.php→ auto-creates pages/menu/testimonials on activation
└── assets/
    ├── css/main.css
    ├── js/main.js + customizer-preview.js
    └── images/logo.jpg
```
