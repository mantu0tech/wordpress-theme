<?php
/* Template Name: Products Page */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>
<main id="primary" class="site-main">

	<section class="iq-page-hero">
		<div class="container iq-narrow iq-center" data-animate="fade-up">
			<span class="iq-eyebrow">Made for You, or Ready When You Are</span>
			<h1>Two Ways to Feel Beautiful</h1>
		</div>
	</section>

	<?php
	while ( have_posts() ) : the_post();
		if ( trim( get_the_content() ) ) : ?>
			<section class="iq-section">
				<div class="container iq-narrow iq-prose" data-animate="fade-up"><?php the_content(); ?></div>
			</section>
		<?php endif;
	endwhile;
	?>

	<!-- CUSTOM DRESSES -->
	<section class="iq-section iq-product-feature">
		<div class="container iq-feature-grid">
			<div class="iq-feature-text" data-animate="fade-right">
				<span class="iq-eyebrow">Custom Dresses</span>
				<h2>Designed around your life, not a size chart.</h2>
				<p>Stop adjusting your body to fit clothes — let your clothes fit you. Tell us the occasion, your measurements, and your color story, and our team designs and stitches a dress made specifically for you.</p>
				<ul class="iq-check-list">
					<li>A dress fitted to your exact measurements</li>
					<li>Your choice of fabric, color, and silhouette</li>
					<li>A one-of-a-kind dupatta to match</li>
					<li>A finished look you won't see on anyone else at the event</li>
				</ul>
				<p class="iq-best-for"><strong>Best for:</strong> Weddings, farewells, festive occasions, or simply when you want something that's truly yours.</p>
				<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="iq-btn iq-btn-primary">Start My Custom Order</a>
			</div>
			<div class="iq-feature-visual iq-feature-visual-1" data-animate="fade-left" aria-hidden="true"></div>
		</div>
	</section>

	<!-- READY-TO-WEAR -->
	<section class="iq-section iq-product-feature iq-feature-reverse">
		<div class="container iq-feature-grid">
			<div class="iq-feature-visual iq-feature-visual-2" data-animate="fade-right" aria-hidden="true"></div>
			<div class="iq-feature-text" data-animate="fade-left">
				<span class="iq-eyebrow">Ready-to-Wear & Combo Sets</span>
				<h2>Beautiful, expertly paired, ready when you are.</h2>
				<p>Not every day needs a custom order — sometimes you just need something gorgeous, ready to go. Our combo sets take the guesswork out of getting dressed.</p>
				<ul class="iq-check-list">
					<li>Pre-styled dress + dupatta combinations</li>
					<li>Easy, transparent pricing — no surprise costs</li>
					<li>Comfortable fabrics for college & office</li>
					<li>Quick ordering, faster delivery</li>
				</ul>
				<p class="iq-best-for"><strong>Best for:</strong> College, daily office wear, casual outings, or last-minute plans.</p>
				<?php if ( class_exists( 'WooCommerce' ) ) : ?>
					<a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="iq-btn iq-btn-primary">Shop Ready Dresses</a>
				<?php else : ?>
					<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="iq-btn iq-btn-primary">Shop Ready Dresses</a>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<!-- DUPATTAS -->
	<section class="iq-section iq-product-feature">
		<div class="container iq-feature-grid">
			<div class="iq-feature-text" data-animate="fade-right">
				<span class="iq-eyebrow">Unique Dupattas</span>
				<h2>The detail everyone asks about.</h2>
				<p>Already have the perfect outfit but need the dupatta that makes it unforgettable? Our dupattas are hand-selected or custom-designed in-house — the kind people stop you to ask about.</p>
				<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="iq-btn iq-btn-primary">Explore Dupattas</a>
			</div>
			<div class="iq-feature-visual iq-feature-visual-3" data-animate="fade-left" aria-hidden="true"></div>
		</div>
	</section>

	<?php if ( class_exists( 'WooCommerce' ) ) : ?>
	<!-- LIVE PRODUCT CATEGORIES / SHOP -->
	<section class="iq-section iq-shop-section">
		<div class="container">
			<h2 class="iq-section-title" data-animate="fade-up">Shop by Category</h2>
			<div class="iq-cat-grid">
				<?php echo do_shortcode( '[product_categories number="6" columns="3"]' ); ?>
			</div>

			<h2 class="iq-section-title" data-animate="fade-up">Latest Arrivals</h2>
			<div class="iq-shop-preview-grid">
				<?php echo do_shortcode( '[products limit="8" columns="4"]' ); ?>
			</div>
			<div class="iq-center"><a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="iq-btn iq-btn-outline">View Full Shop</a></div>
		</div>
	</section>
	<?php else : ?>
	<section class="iq-section">
		<div class="container iq-narrow iq-center">
			<p><em>Activate WooCommerce to display live products, categories, and enable checkout here.</em></p>
		</div>
	</section>
	<?php endif; ?>

</main>
<?php get_footer(); ?>
