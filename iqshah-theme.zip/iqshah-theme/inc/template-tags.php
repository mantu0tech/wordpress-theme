<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Print the social + contact icon links used in header & footer.
 */
function iqshah_social_links( $class = 'iq-social-links' ) {
	$whatsapp = get_theme_mod( 'iqshah_whatsapp', '918369766855' );
	$email    = get_theme_mod( 'iqshah_email', 'hello.iqshah@gmail.com' );
	$insta    = get_theme_mod( 'iqshah_instagram', 'iqshah_ethnic' );
	$fb       = get_theme_mod( 'iqshah_facebook', 'iqshah_ethnic' );
	?>
	<div class="<?php echo esc_attr( $class ); ?>">
		<a href="https://wa.me/<?php echo esc_attr( preg_replace( '/[^0-9]/', '', $whatsapp ) ); ?>" target="_blank" rel="noopener" aria-label="WhatsApp" class="iq-social-icon iq-whatsapp">
			<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347zM12.04 21.79h-.004a9.936 9.936 0 01-5.062-1.387l-.363-.216-3.759.987 1.005-3.666-.236-.376a9.94 9.94 0 01-1.514-5.297C2.109 6.686 6.598 2.196 12.045 2.196c2.638 0 5.116 1.03 6.982 2.898a9.825 9.825 0 012.885 6.998c-.002 5.448-4.492 9.938-9.872 9.938zm8.413-18.352A11.815 11.815 0 0012.045.192C5.495.192.192 5.495.19 12.045c0 2.123.554 4.198 1.606 6.032L.096 23.808l5.868-1.539a11.87 11.87 0 005.67 1.444h.005c6.55 0 11.853-5.303 11.856-11.855a11.788 11.788 0 00-3.037-8.02z"/></svg>
		</a>
		<a href="mailto:<?php echo esc_attr( $email ); ?>" aria-label="Email" class="iq-social-icon iq-email">
			<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
		</a>
		<a href="https://instagram.com/<?php echo esc_attr( $insta ); ?>" target="_blank" rel="noopener" aria-label="Instagram" class="iq-social-icon iq-instagram">
			<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zM12 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zm0 10.162a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
		</a>
		<a href="https://facebook.com/<?php echo esc_attr( $fb ); ?>" target="_blank" rel="noopener" aria-label="Facebook" class="iq-social-icon iq-facebook">
			<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.891h-2.33v6.987C18.343 21.128 22 16.991 22 12z"/></svg>
		</a>
	</div>
	<?php
}

/**
 * Render 4 "Difference" blocks on homepage from Customizer content.
 */
function iqshah_difference_blocks() {
	$icons = array( '✂️', '🧣', '👗', '💛' );
	for ( $i = 1; $i <= 4; $i++ ) {
		$title = get_theme_mod( "iqshah_diff_{$i}_title", '' );
		$body  = get_theme_mod( "iqshah_diff_{$i}_body", '' );
		if ( ! $title ) continue;
		?>
		<div class="iq-diff-card" data-aos>
			<span class="iq-diff-num"><?php echo esc_html( $i ); ?></span>
			<h3><?php echo esc_html( $title ); ?></h3>
			<p><?php echo esc_html( $body ); ?></p>
		</div>
		<?php
	}
}

/**
 * Render testimonials (CPT) as a slider/grid on the homepage.
 */
function iqshah_render_testimonials( $count = 6 ) {
	$q = new WP_Query( array(
		'post_type'      => 'testimonial',
		'posts_per_page' => $count,
		'orderby'        => 'menu_order date',
		'order'          => 'ASC',
	) );
	if ( ! $q->have_posts() ) return;
	echo '<div class="iq-testimonial-track">';
	while ( $q->have_posts() ) {
		$q->the_post();
		$role  = get_post_meta( get_the_ID(), '_iqshah_testimonial_role', true );
		$stars = (int) get_post_meta( get_the_ID(), '_iqshah_testimonial_stars', true );
		if ( ! $stars ) $stars = 5;
		?>
		<div class="iq-testimonial-card">
			<div class="iq-stars"><?php echo str_repeat( '★', $stars ) . str_repeat( '☆', 5 - $stars ); ?></div>
			<p class="iq-testimonial-quote">&ldquo;<?php echo esc_html( wp_strip_all_tags( get_the_content() ) ); ?>&rdquo;</p>
			<p class="iq-testimonial-author">— <?php the_title(); ?><?php if ( $role ) echo ', <span>' . esc_html( $role ) . '</span>'; ?></p>
		</div>
		<?php
	}
	echo '</div>';
	wp_reset_postdata();
}

/**
 * WhatsApp floating button (shown site-wide).
 */
function iqshah_whatsapp_float() {
	$whatsapp = get_theme_mod( 'iqshah_whatsapp', '918369766855' );
	$num = preg_replace( '/[^0-9]/', '', $whatsapp );
	?>
	<a href="https://wa.me/<?php echo esc_attr( $num ); ?>?text=Hi%20IQSHAH!%20I%27d%20love%20to%20know%20more." class="iq-whatsapp-float" target="_blank" rel="noopener" aria-label="Chat with us on WhatsApp">
		<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path fill="currentColor" d="M12.04 21.79h-.004a9.936 9.936 0 01-5.062-1.387l-.363-.216-3.759.987 1.005-3.666-.236-.376a9.94 9.94 0 01-1.514-5.297C2.109 6.686 6.598 2.196 12.045 2.196c2.638 0 5.116 1.03 6.982 2.898a9.825 9.825 0 012.885 6.998c-.002 5.448-4.492 9.938-9.872 9.938z"/></svg>
	</a>
	<?php
}
