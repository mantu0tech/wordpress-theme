<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function iqshah_customize_register( $wp_customize ) {

	/* =========================================================
	 * PANEL: Brand Colors
	 * ======================================================= */
	$wp_customize->add_section( 'iqshah_colors', array(
		'title'    => __( 'IQSHAH Brand Colors', 'iqshah' ),
		'priority' => 30,
	) );

	$color_fields = array(
		'iqshah_color_primary'      => array( 'Primary (Maroon)',    '#6B1226' ),
		'iqshah_color_primary_dark' => array( 'Primary Dark (Hover)','#4A0C1A' ),
		'iqshah_color_accent'       => array( 'Accent (Gold)',       '#C6A250' ),
		'iqshah_color_accent_light' => array( 'Accent Light (Gold)', '#E4CC94' ),
		'iqshah_color_bg'           => array( 'Background (Cream)',  '#FAF6EB' ),
		'iqshah_color_bg_dark'      => array( 'Background Shade',    '#F0E6D2' ),
		'iqshah_color_text'         => array( 'Body Text',           '#2B1810' ),
	);
	foreach ( $color_fields as $id => $data ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $data[1],
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		) );
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, array(
			'label'   => __( $data[0], 'iqshah' ),
			'section' => 'iqshah_colors',
		) ) );
	}

	/* =========================================================
	 * PANEL: Contact & Socials (used sitewide - header/footer)
	 * ======================================================= */
	$wp_customize->add_section( 'iqshah_contact', array(
		'title'    => __( 'Contact & Social Links', 'iqshah' ),
		'priority' => 35,
	) );

	$contact_fields = array(
		'iqshah_email'        => array( 'Email Address', 'hello.iqshah@gmail.com', 'text' ),
		'iqshah_whatsapp'     => array( 'WhatsApp Number (with country code, no +)', '918369766855', 'text' ),
		'iqshah_whatsapp_display' => array( 'WhatsApp Number (display format)', '+91 83697 66855', 'text' ),
		'iqshah_instagram'    => array( 'Instagram Handle', 'iqshah_ethnic', 'text' ),
		'iqshah_facebook'     => array( 'Facebook Handle', 'iqshah_ethnic', 'text' ),
		'iqshah_address'      => array( 'Address / Location line', 'Based in Mumbai, shipping across India', 'text' ),
	);
	foreach ( $contact_fields as $id => $data ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $data[1],
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		) );
		$wp_customize->add_control( $id, array(
			'label'   => __( $data[0], 'iqshah' ),
			'section' => 'iqshah_contact',
			'type'    => $data[2],
		) );
	}

	/* =========================================================
	 * PANEL: Homepage Content
	 * ======================================================= */
	$wp_customize->add_panel( 'iqshah_home_panel', array(
		'title'    => __( 'Homepage Content', 'iqshah' ),
		'priority' => 40,
	) );

	// --- Hero ---
	$wp_customize->add_section( 'iqshah_home_hero', array(
		'title' => __( 'Hero Section', 'iqshah' ),
		'panel' => 'iqshah_home_panel',
	) );
	iqshah_add_text_setting( $wp_customize, 'iqshah_hero_headline', 'Hero Headline', "Tired of dresses that look perfect on the hanger and wrong on you?", 'iqshah_home_hero', 'textarea' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_hero_subheadline', 'Hero Subheadline', "Most \"ready-made\" fashion is made for an average body that doesn't exist. At IQSHAH, every dress can be made to fit your story — your size, your color, your dupatta — without the wait or the price tag of a designer boutique.", 'iqshah_home_hero', 'textarea' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_hero_cta_primary_text', 'Primary Button Text', 'Design My Dress', 'iqshah_home_hero' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_hero_cta_primary_link', 'Primary Button Link', home_url( '/contact/' ), 'iqshah_home_hero' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_hero_cta_secondary_text', 'Secondary Button Text', 'Shop Ready Dresses', 'iqshah_home_hero' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_hero_cta_secondary_link', 'Secondary Button Link', home_url( '/shop/' ), 'iqshah_home_hero' );

	$wp_customize->add_setting( 'iqshah_hero_image', array( 'default' => '', 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'iqshah_hero_image', array(
		'label'   => __( 'Hero Background Image', 'iqshah' ),
		'section' => 'iqshah_home_hero',
	) ) );

	// --- Pain point section ---
	$wp_customize->add_section( 'iqshah_home_pain', array(
		'title' => __( 'Pain Point Section', 'iqshah' ),
		'panel' => 'iqshah_home_panel',
	) );
	iqshah_add_text_setting( $wp_customize, 'iqshah_pain_heading', 'Heading', "You shouldn't have to compromise on beautiful.", 'iqshah_home_pain' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_pain_body', 'Body Text', "You've been there. Scrolling through a dozen online stores, falling in love with a dress, ordering it in hope — and unboxing disappointment. Wrong fit. Dull fabric. A dupatta that looks nothing like the photo. So you either settle, or you pay a tailor extra just to make it wearable.\n\nWe started IQSHAH because we were tired of that too.", 'iqshah_home_pain', 'textarea' );

	// --- Difference blocks (4) ---
	$wp_customize->add_section( 'iqshah_home_diff', array(
		'title' => __( 'The IQSHAH Difference (4 blocks)', 'iqshah' ),
		'panel' => 'iqshah_home_panel',
	) );
	iqshah_add_text_setting( $wp_customize, 'iqshah_diff_heading', 'Section Heading', 'Beautiful, made for you — not just made.', 'iqshah_home_diff' );
	$diffs = array(
		1 => array( 'Custom Fit, Zero Hassle', 'Tell us your measurements, your colors, your occasion. We design and stitch it around you, not the other way around.' ),
		2 => array( "Dupattas You Won't See on Anyone Else", 'Every dupatta is hand-picked or custom-designed in-house — because the dupatta makes the outfit, and yours should be unmistakably yours.' ),
		3 => array( 'Combo Dressing, Done for You', 'No more mixing and guessing. Get expertly paired dress + dupatta + accents combos that just work, straight out of the box.' ),
		4 => array( 'Honest, Easy Pricing', 'Beautiful shouldn\'t mean expensive. Transparent pricing, no hidden "customization fee" surprises.' ),
	);
	foreach ( $diffs as $i => $d ) {
		iqshah_add_text_setting( $wp_customize, "iqshah_diff_{$i}_title", "Block {$i} Title", $d[0], 'iqshah_home_diff' );
		iqshah_add_text_setting( $wp_customize, "iqshah_diff_{$i}_body", "Block {$i} Text", $d[1], 'iqshah_home_diff', 'textarea' );
	}

	// --- Trust strip ---
	$wp_customize->add_section( 'iqshah_home_trust', array(
		'title' => __( 'Trust Strip', 'iqshah' ),
		'panel' => 'iqshah_home_panel',
	) );
	iqshah_add_text_setting( $wp_customize, 'iqshah_trust_strip', 'Trust Strip Text (use " · " to separate)', '500+ Dresses Stitched with Love · 2 Years of Passion · 3 Sisters, 1 Dream · Made Across Mumbai', 'iqshah_home_trust' );

	// --- Final CTA ---
	$wp_customize->add_section( 'iqshah_home_final', array(
		'title' => __( 'Final CTA Section', 'iqshah' ),
		'panel' => 'iqshah_home_panel',
	) );
	iqshah_add_text_setting( $wp_customize, 'iqshah_final_heading', 'Heading', 'Your dress. Your fit. Your story.', 'iqshah_home_final' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_final_body', 'Body Text', 'Whether you want something made just for you, or a ready-to-wear piece you can order today — IQSHAH is here to make sure you walk out feeling always beautiful.', 'iqshah_home_final', 'textarea' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_final_cta1_text', 'Button 1 Text', 'Start Designing My Dress', 'iqshah_home_final' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_final_cta1_link', 'Button 1 Link', home_url( '/contact/' ), 'iqshah_home_final' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_final_cta2_text', 'Button 2 Text', 'Browse Ready Collection', 'iqshah_home_final' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_final_cta2_link', 'Button 2 Link', home_url( '/shop/' ), 'iqshah_home_final' );

	/* =========================================================
	 * PANEL: Landing Page (Ads)
	 * ======================================================= */
	$wp_customize->add_section( 'iqshah_landing', array(
		'title'    => __( 'Landing Page (Ads) Settings', 'iqshah' ),
		'priority' => 45,
	) );
	iqshah_add_text_setting( $wp_customize, 'iqshah_landing_headline', 'Headline', 'Stop Guessing Your Size. Get It Right the First Time — Free.', 'iqshah_landing' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_landing_subheadline', 'Subheadline', 'Book a free 10-minute Fit Consultation with the IQSHAH team and get ₹300 off your first custom dress. No catch, no obligation — just clarity before you commit.', 'iqshah_landing', 'textarea' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_landing_cta', 'CTA Button Text', 'Claim My Free Consultation', 'iqshah_landing' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_landing_proof_stat', 'Proof Stat Line', '127 women have booked a Fit Consultation this month.', 'iqshah_landing' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_landing_urgency', 'Urgency Line', 'This offer is limited to the first 50 bookings this month — after that, the ₹300 discount closes until next month\'s batch opens.', 'iqshah_landing', 'textarea' );

	/* =========================================================
	 * PANEL: Footer
	 * ======================================================= */
	$wp_customize->add_section( 'iqshah_footer', array(
		'title'    => __( 'Footer Settings', 'iqshah' ),
		'priority' => 50,
	) );
	iqshah_add_text_setting( $wp_customize, 'iqshah_footer_tagline', 'Footer Tagline', 'Always Beautiful.', 'iqshah_footer' );
	iqshah_add_text_setting( $wp_customize, 'iqshah_footer_copyright', 'Copyright Text', '© ' . date( 'Y' ) . ' IQSHAH. All rights reserved.', 'iqshah_footer' );
}
add_action( 'customize_register', 'iqshah_customize_register' );

/**
 * Helper to quickly register a text/textarea customizer setting+control.
 */
function iqshah_add_text_setting( $wp_customize, $id, $label, $default, $section, $type = 'text' ) {
	$wp_customize->add_setting( $id, array(
		'default'           => $default,
		'sanitize_callback' => ( $type === 'textarea' ) ? 'sanitize_textarea_field' : 'sanitize_text_field',
		'transport'         => 'refresh',
	) );
	$wp_customize->add_control( $id, array(
		'label'   => __( $label, 'iqshah' ),
		'section' => $section,
		'type'    => $type,
	) );
}

/**
 * Output live-preview JS for postMessage color transports (basic refresh fallback covers the rest).
 */
function iqshah_customize_preview_js() {
	wp_enqueue_script( 'iqshah-customizer-preview', IQSHAH_URI . '/assets/js/customizer-preview.js', array( 'customize-preview' ), IQSHAH_VERSION, true );
}
add_action( 'customize_preview_init', 'iqshah_customize_preview_js' );
