<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * All Contact Form & Landing Page (lead) submissions are stored as a
 * private CPT so the client can view them from wp-admin, no external
 * plugin or database table needed — everything lives in WordPress.
 */
function iqshah_register_lead_cpt() {
	register_post_type( 'iqshah_lead', array(
		'labels' => array(
			'name'          => __( 'Form Submissions', 'iqshah' ),
			'singular_name' => __( 'Submission', 'iqshah' ),
			'menu_name'     => __( 'Form Submissions', 'iqshah' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => true,
		'menu_icon'    => 'dashicons-email-alt',
		'supports'     => array( 'title' ),
		'capability_type' => 'post',
		'map_meta_cap' => true,
	) );
}
add_action( 'init', 'iqshah_register_lead_cpt' );

/**
 * Show submission details (name, contact, message, type) in the admin list & edit screen.
 */
function iqshah_lead_metabox() {
	add_meta_box( 'iqshah_lead_meta', __( 'Submission Details', 'iqshah' ), 'iqshah_lead_meta_cb', 'iqshah_lead', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'iqshah_lead_metabox' );

function iqshah_lead_meta_cb( $post ) {
	$fields = array( 'form_type', 'name', 'whatsapp', 'email', 'looking_for', 'message', 'submitted_at' );
	echo '<table class="widefat"><tbody>';
	foreach ( $fields as $f ) {
		$val = get_post_meta( $post->ID, '_iqshah_' . $f, true );
		echo '<tr><td style="width:180px"><strong>' . esc_html( ucwords( str_replace( '_', ' ', $f ) ) ) . '</strong></td><td>' . esc_html( $val ) . '</td></tr>';
	}
	echo '</tbody></table>';
}

/**
 * Custom admin columns for quick scanning of leads.
 */
add_filter( 'manage_iqshah_lead_posts_columns', function( $columns ) {
	$columns['form_type']  = __( 'Form', 'iqshah' );
	$columns['contact']    = __( 'Contact', 'iqshah' );
	$columns['looking_for']= __( 'Looking For', 'iqshah' );
	return $columns;
} );
add_action( 'manage_iqshah_lead_posts_custom_column', function( $column, $post_id ) {
	if ( $column === 'form_type' ) echo esc_html( get_post_meta( $post_id, '_iqshah_form_type', true ) );
	if ( $column === 'contact' ) {
		echo esc_html( get_post_meta( $post_id, '_iqshah_whatsapp', true ) ) . '<br>' . esc_html( get_post_meta( $post_id, '_iqshah_email', true ) );
	}
	if ( $column === 'looking_for' ) echo esc_html( get_post_meta( $post_id, '_iqshah_looking_for', true ) );
}, 10, 2 );

/**
 * Store a lead/submission programmatically.
 */
function iqshah_save_lead( $form_type, $data ) {
	$title = sprintf( '%s — %s (%s)', ucwords( str_replace( '_', ' ', $form_type ) ), sanitize_text_field( $data['name'] ?? 'Unknown' ), date( 'd M Y, H:i' ) );
	$post_id = wp_insert_post( array(
		'post_type'   => 'iqshah_lead',
		'post_title'  => $title,
		'post_status' => 'publish',
	) );
	if ( is_wp_error( $post_id ) || ! $post_id ) return false;

	update_post_meta( $post_id, '_iqshah_form_type', sanitize_text_field( $form_type ) );
	update_post_meta( $post_id, '_iqshah_name', sanitize_text_field( $data['name'] ?? '' ) );
	update_post_meta( $post_id, '_iqshah_whatsapp', sanitize_text_field( $data['whatsapp'] ?? '' ) );
	update_post_meta( $post_id, '_iqshah_email', sanitize_email( $data['email'] ?? '' ) );
	update_post_meta( $post_id, '_iqshah_looking_for', sanitize_text_field( $data['looking_for'] ?? '' ) );
	update_post_meta( $post_id, '_iqshah_message', sanitize_textarea_field( $data['message'] ?? '' ) );
	update_post_meta( $post_id, '_iqshah_submitted_at', current_time( 'mysql' ) );

	return $post_id;
}
