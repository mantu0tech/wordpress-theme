<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Testimonial CPT — lets the client add/edit/reorder testimonials
 * from wp-admin without touching any code.
 */
function iqshah_register_testimonial_cpt() {
	$labels = array(
		'name'          => __( 'Testimonials', 'iqshah' ),
		'singular_name' => __( 'Testimonial', 'iqshah' ),
		'add_new_item'  => __( 'Add New Testimonial', 'iqshah' ),
		'edit_item'     => __( 'Edit Testimonial', 'iqshah' ),
		'menu_name'     => __( 'Testimonials', 'iqshah' ),
	);
	register_post_type( 'testimonial', array(
		'labels'        => $labels,
		'public'        => false,
		'show_ui'       => true,
		'show_in_menu'  => true,
		'menu_icon'     => 'dashicons-format-quote',
		'supports'      => array( 'title', 'editor', 'page-attributes' ),
		'hierarchical'  => false,
	) );
}
add_action( 'init', 'iqshah_register_testimonial_cpt' );

/**
 * Meta box: customer role/location line (e.g. "College Student, Mumbai")
 */
function iqshah_testimonial_metabox() {
	add_meta_box( 'iqshah_testimonial_meta', __( 'Customer Details', 'iqshah' ), 'iqshah_testimonial_meta_cb', 'testimonial', 'side', 'default' );
}
add_action( 'add_meta_boxes', 'iqshah_testimonial_metabox' );

function iqshah_testimonial_meta_cb( $post ) {
	wp_nonce_field( 'iqshah_testimonial_save', 'iqshah_testimonial_nonce' );
	$role  = get_post_meta( $post->ID, '_iqshah_testimonial_role', true );
	$stars = get_post_meta( $post->ID, '_iqshah_testimonial_stars', true );
	if ( ! $stars ) $stars = 5;
	echo '<p><label for="iqshah_testimonial_role"><strong>' . esc_html__( 'Role / Location', 'iqshah' ) . '</strong></label><br>';
	echo '<input type="text" id="iqshah_testimonial_role" name="iqshah_testimonial_role" value="' . esc_attr( $role ) . '" style="width:100%" placeholder="e.g. College Student, Mumbai" /></p>';
	echo '<p><label for="iqshah_testimonial_stars"><strong>' . esc_html__( 'Star Rating (1-5)', 'iqshah' ) . '</strong></label><br>';
	echo '<input type="number" min="1" max="5" id="iqshah_testimonial_stars" name="iqshah_testimonial_stars" value="' . esc_attr( $stars ) . '" style="width:100%" /></p>';
	echo '<p><em>' . esc_html__( 'Title field = customer name. Content editor = the quote.', 'iqshah' ) . '</em></p>';
}

function iqshah_testimonial_save( $post_id ) {
	if ( ! isset( $_POST['iqshah_testimonial_nonce'] ) || ! wp_verify_nonce( $_POST['iqshah_testimonial_nonce'], 'iqshah_testimonial_save' ) ) return;
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( isset( $_POST['iqshah_testimonial_role'] ) ) {
		update_post_meta( $post_id, '_iqshah_testimonial_role', sanitize_text_field( $_POST['iqshah_testimonial_role'] ) );
	}
	if ( isset( $_POST['iqshah_testimonial_stars'] ) ) {
		update_post_meta( $post_id, '_iqshah_testimonial_stars', absint( $_POST['iqshah_testimonial_stars'] ) );
	}
}
add_action( 'save_post_testimonial', 'iqshah_testimonial_save' );
