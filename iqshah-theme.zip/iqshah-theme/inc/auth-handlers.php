<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Custom Login handler
 * Works for BOTH customers and admins/staff: after successful login we
 * redirect based on the user's role — admins/staff go to wp-admin,
 * everyone else goes to their account / the homepage.
 */
function iqshah_handle_login() {
	if ( ! isset( $_POST['iqshah_login_nonce'] ) || ! wp_verify_nonce( $_POST['iqshah_login_nonce'], 'iqshah_login_action' ) ) {
		wp_die( __( 'Security check failed. Please go back and try again.', 'iqshah' ) );
	}

	$creds = array(
		'user_login'    => sanitize_text_field( $_POST['iqshah_username'] ?? '' ),
		'user_password' => $_POST['iqshah_password'] ?? '',
		'remember'      => isset( $_POST['iqshah_remember'] ),
	);

	$redirect_to = ! empty( $_POST['iqshah_redirect'] ) ? esc_url_raw( $_POST['iqshah_redirect'] ) : home_url( '/' );

	$user = wp_signon( $creds, is_ssl() );

	if ( is_wp_error( $user ) ) {
		$error = urlencode( $user->get_error_message() );
		wp_safe_redirect( add_query_arg( 'login_error', $error, wp_get_referer() ?: home_url( '/login/' ) ) );
		exit;
	}

	// Route by role.
	if ( in_array( 'administrator', (array) $user->roles, true ) || in_array( 'shop_manager', (array) $user->roles, true ) || in_array( 'editor', (array) $user->roles, true ) ) {
		wp_safe_redirect( admin_url() );
		exit;
	}

	// Customers -> WooCommerce account page if it exists, else homepage/redirect param.
	if ( function_exists( 'wc_get_page_id' ) && wc_get_page_id( 'myaccount' ) > 0 ) {
		wp_safe_redirect( get_permalink( wc_get_page_id( 'myaccount' ) ) );
		exit;
	}

	wp_safe_redirect( $redirect_to );
	exit;
}
add_action( 'admin_post_nopriv_iqshah_login', 'iqshah_handle_login' );
add_action( 'admin_post_iqshah_login', 'iqshah_handle_login' );

/**
 * Custom Register handler — creates a new user with the "customer" role
 * (compatible with WooCommerce) so they can shop, track orders, etc.
 * Admin/staff accounts are still created normally from wp-admin > Users
 * by the site owner — this public form is intentionally customer-only
 * for security, but logging in on the Login page works for any role.
 */
function iqshah_handle_register() {
	if ( ! isset( $_POST['iqshah_register_nonce'] ) || ! wp_verify_nonce( $_POST['iqshah_register_nonce'], 'iqshah_register_action' ) ) {
		wp_die( __( 'Security check failed. Please go back and try again.', 'iqshah' ) );
	}

	$name     = sanitize_text_field( $_POST['iqshah_reg_name'] ?? '' );
	$email    = sanitize_email( $_POST['iqshah_reg_email'] ?? '' );
	$password = $_POST['iqshah_reg_password'] ?? '';
	$whatsapp = sanitize_text_field( $_POST['iqshah_reg_whatsapp'] ?? '' );

	$errors = array();
	if ( empty( $name ) )        $errors[] = __( 'Please enter your name.', 'iqshah' );
	if ( ! is_email( $email ) )  $errors[] = __( 'Please enter a valid email address.', 'iqshah' );
	if ( email_exists( $email ) ) $errors[] = __( 'An account with this email already exists. Try logging in instead.', 'iqshah' );
	if ( strlen( $password ) < 6 ) $errors[] = __( 'Password must be at least 6 characters.', 'iqshah' );

	if ( ! empty( $errors ) ) {
		wp_safe_redirect( add_query_arg( 'register_error', urlencode( implode( ' ', $errors ) ), wp_get_referer() ?: home_url( '/register/' ) ) );
		exit;
	}

	$username = sanitize_user( current( explode( '@', $email ) ) . wp_rand( 10, 99 ) );
	$user_id  = wp_insert_user( array(
		'user_login'   => $username,
		'user_email'   => $email,
		'user_pass'    => $password,
		'display_name' => $name,
		'first_name'   => $name,
		'role'         => 'customer',
	) );

	if ( is_wp_error( $user_id ) ) {
		wp_safe_redirect( add_query_arg( 'register_error', urlencode( $user_id->get_error_message() ), wp_get_referer() ?: home_url( '/register/' ) ) );
		exit;
	}

	if ( $whatsapp ) {
		update_user_meta( $user_id, 'iqshah_whatsapp', $whatsapp );
	}

	wp_new_user_notification( $user_id, null, 'both' );

	$creds = array( 'user_login' => $username, 'user_password' => $password, 'remember' => true );
	wp_signon( $creds, is_ssl() );

	if ( function_exists( 'wc_get_page_id' ) && wc_get_page_id( 'myaccount' ) > 0 ) {
		wp_safe_redirect( get_permalink( wc_get_page_id( 'myaccount' ) ) );
		exit;
	}

	wp_safe_redirect( home_url( '/?registered=1' ) );
	exit;
}
add_action( 'admin_post_nopriv_iqshah_register', 'iqshah_handle_register' );
add_action( 'admin_post_iqshah_register', 'iqshah_handle_register' );

/**
 * Contact page form handler — saves to Form Submissions (CPT) + emails the team.
 */
function iqshah_handle_contact_form() {
	if ( ! isset( $_POST['iqshah_contact_nonce'] ) || ! wp_verify_nonce( $_POST['iqshah_contact_nonce'], 'iqshah_contact_action' ) ) {
		wp_die( __( 'Security check failed. Please go back and try again.', 'iqshah' ) );
	}
	// Honeypot
	if ( ! empty( $_POST['iqshah_hp'] ) ) {
		wp_safe_redirect( home_url( '/contact/?sent=1' ) );
		exit;
	}

	$data = array(
		'name'        => sanitize_text_field( $_POST['iqshah_name'] ?? '' ),
		'whatsapp'    => sanitize_text_field( $_POST['iqshah_whatsapp'] ?? '' ),
		'email'       => sanitize_email( $_POST['iqshah_email'] ?? '' ),
		'looking_for' => sanitize_text_field( $_POST['iqshah_looking_for'] ?? '' ),
		'message'     => sanitize_textarea_field( $_POST['iqshah_message'] ?? '' ),
	);

	iqshah_save_lead( 'contact_form', $data );
	iqshah_notify_team( 'New Contact Form Submission', $data );

	wp_safe_redirect( home_url( '/contact/?sent=1' ) );
	exit;
}
add_action( 'admin_post_nopriv_iqshah_contact', 'iqshah_handle_contact_form' );
add_action( 'admin_post_iqshah_contact', 'iqshah_handle_contact_form' );

/**
 * Landing page lead / fit-consultation form handler.
 */
function iqshah_handle_landing_form() {
	if ( ! isset( $_POST['iqshah_landing_nonce'] ) || ! wp_verify_nonce( $_POST['iqshah_landing_nonce'], 'iqshah_landing_action' ) ) {
		wp_die( __( 'Security check failed. Please go back and try again.', 'iqshah' ) );
	}
	if ( ! empty( $_POST['iqshah_hp'] ) ) {
		wp_safe_redirect( add_query_arg( 'booked', 1, wp_get_referer() ) );
		exit;
	}

	$data = array(
		'name'        => sanitize_text_field( $_POST['iqshah_name'] ?? '' ),
		'whatsapp'    => sanitize_text_field( $_POST['iqshah_whatsapp'] ?? '' ),
		'email'       => sanitize_email( $_POST['iqshah_email'] ?? '' ),
		'looking_for' => 'Free Fit Consultation',
		'message'     => sanitize_textarea_field( $_POST['iqshah_message'] ?? '' ),
	);

	iqshah_save_lead( 'landing_consultation', $data );
	iqshah_notify_team( 'New Fit Consultation Booking', $data );

	wp_safe_redirect( add_query_arg( 'booked', 1, wp_get_referer() ?: home_url( '/landing/' ) ) );
	exit;
}
add_action( 'admin_post_nopriv_iqshah_landing_lead', 'iqshah_handle_landing_form' );
add_action( 'admin_post_iqshah_landing_lead', 'iqshah_handle_landing_form' );

/**
 * Email the IQSHAH team whenever a form is submitted.
 */
function iqshah_notify_team( $subject, $data ) {
	$to = get_theme_mod( 'iqshah_email', 'hello.iqshah@gmail.com' );
	$body  = "You've received a new submission on the IQSHAH website:\n\n";
	foreach ( $data as $key => $val ) {
		$body .= ucwords( str_replace( '_', ' ', $key ) ) . ': ' . $val . "\n";
	}
	wp_mail( $to, '[IQSHAH Website] ' . $subject, $body );
}
