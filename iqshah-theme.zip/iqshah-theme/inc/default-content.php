<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Runs once on theme activation: creates the core pages with their
 * templates assigned and the copy pre-filled (fully editable afterwards
 * via the normal WordPress block editor), sets up the menu, and adds
 * a few starter testimonials.
 */
function iqshah_after_switch_theme() {

	if ( get_option( 'iqshah_setup_done' ) ) return;

	// ---- Pages ----
	$pages = array(
		'home' => array(
			'title'    => 'Home',
			'template' => 'front-page.php',
			'content'  => '',
		),
		'about' => array(
			'title'   => 'About Us',
			'template'=> 'page-about.php',
			'content' => "<h2>We Are Three Sisters Who Refused to Settle</h2>\n<p>Our story didn't begin in a boardroom. It began at home, with three sisters from Mumbai, a sewing machine, and parents who taught us that hard work and confidence aren't separate things — they go hand in hand. The name IQSHAH itself carries them in it, a quiet tribute to our father and mother, who showed us what it means to build something with patience and heart. We didn't set out to start a \"brand.\" We just wanted to make clothes that made us — and the women around us — feel like the best version of ourselves.</p>\n<p>For two years, before IQSHAH ever had a name, we were designing, stitching, and wearing our own outfits — figuring out what actually felt good on real bodies, in real Mumbai heat, for real days at college and at work. We made mistakes. We unpicked seams more times than we can count. But somewhere in those late nights of fabric scraps and chai, we found our signature: dresses that are unique, elegant, and — most importantly — comfortable enough to live your life in.</p>\n<p>What turned this into IQSHAH wasn't a business plan. It was you. The compliments from friends. The \"where did you get that dupatta from?\" messages from colleagues. The cousins who wanted the same dress in their size. That love is what told us this wasn't just a hobby — it was something worth sharing with more women. So today, we welcome you into a brand built on family, faith in our craft, and one simple promise: with IQSHAH, you are always beautiful.</p>",
		),
		'products' => array(
			'title'   => 'Products',
			'template'=> 'page-products.php',
			'content' => '',
		),
		'contact' => array(
			'title'   => 'Contact',
			'template'=> 'page-contact.php',
			'content' => "<p>Have a question about custom orders, sizing, or a design idea you're not sure how to explain? You don't need the perfect words — just tell us what's in your head, and we'll help shape it into something beautiful.</p>",
		),
		'landing' => array(
			'title'   => 'Free Fit Consultation',
			'template'=> 'page-landing.php',
			'content' => '',
		),
		'login' => array(
			'title'   => 'Login',
			'template'=> 'page-login.php',
			'content' => '',
		),
		'register' => array(
			'title'   => 'Register',
			'template'=> 'page-register.php',
			'content' => '',
		),
	);

	$page_ids = array();

	foreach ( $pages as $key => $data ) {
		$existing = get_page_by_title( $data['title'] );
		if ( $existing ) {
			$page_ids[ $key ] = $existing->ID;
			continue;
		}
		$id = wp_insert_post( array(
			'post_title'   => $data['title'],
			'post_content' => $data['content'],
			'post_status'  => 'publish',
			'post_type'    => 'page',
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_wp_page_template', $data['template'] );
			$page_ids[ $key ] = $id;
		}
	}

	// Set static front page.
	if ( ! empty( $page_ids['home'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $page_ids['home'] );
	}

	// ---- Primary Menu ----
	$menu_name = 'IQSHAH Main Menu';
	$menu_exists = wp_get_nav_menu_object( $menu_name );
	if ( ! $menu_exists ) {
		$menu_id = wp_create_nav_menu( $menu_name );
		$menu_items = array(
			array( 'title' => 'Home',     'page' => 'home' ),
			array( 'title' => 'About Us', 'page' => 'about' ),
			array( 'title' => 'Products', 'page' => 'products' ),
			array( 'title' => 'Contact',  'page' => 'contact' ),
		);
		foreach ( $menu_items as $item ) {
			if ( empty( $page_ids[ $item['page'] ] ) ) continue;
			wp_update_nav_menu_item( $menu_id, 0, array(
				'menu-item-title'     => $item['title'],
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $page_ids[ $item['page'] ],
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			) );
		}
		$locations = get_theme_mod( 'nav_menu_locations', array() );
		$locations['primary'] = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );
	}

	// ---- Starter Testimonials ----
	if ( ! get_option( 'iqshah_testimonials_seeded' ) ) {
		$testimonials = array(
			array( 'Riya', 'College Student, Mumbai', "I ordered a custom dress for my farewell and it fit better than anything I've bought from a store. The dupatta was stunning." ),
			array( 'Sneha', 'Marketing Executive', "Finally a brand that understands office wear doesn't have to be boring. I get compliments every single time." ),
			array( 'Ayesha, 24', '', 'The combo set saved me so much time before my cousin\'s wedding. Easy, beautiful, affordable.' ),
			array( 'Pooja, 27', '', "The fit consultation alone was worth it — I finally understood why store-bought sizes never worked for me. My custom dress fit perfectly on the first try." ),
		);
		foreach ( $testimonials as $t ) {
			$tid = wp_insert_post( array(
				'post_type'    => 'testimonial',
				'post_title'   => $t[0],
				'post_content' => $t[2],
				'post_status'  => 'publish',
			) );
			if ( $tid && $t[1] ) update_post_meta( $tid, '_iqshah_testimonial_role', $t[1] );
			if ( $tid ) update_post_meta( $tid, '_iqshah_testimonial_stars', 5 );
		}
		update_option( 'iqshah_testimonials_seeded', 1 );
	}

	update_option( 'iqshah_setup_done', 1 );
}
add_action( 'after_switch_theme', 'iqshah_after_switch_theme' );
