<?php
/* Template Name: About Page */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
?>
<main id="primary" class="site-main">

	<section class="iq-page-hero iq-about-hero">
		<div class="container iq-narrow" data-animate="fade-up">
			<span class="iq-eyebrow">Our Story</span>
			<h1>Three Sisters. One Sewing Machine. A Brand Built on Love.</h1>
		</div>
	</section>

	<section class="iq-section">
		<div class="container iq-narrow iq-prose" data-animate="fade-up">
			<?php
			while ( have_posts() ) : the_post();
				the_content();
			endwhile;
			?>
		</div>
	</section>

	<section class="iq-section iq-about-values">
		<div class="container">
			<div class="iq-values-grid">
				<div class="iq-value-card" data-animate="fade-up">
					<span class="iq-value-icon">👨‍👩‍👧‍👧</span>
					<h3>Family First</h3>
					<p>IQSHAH carries our parents' name in it — a tribute to the people who taught us patience and heart.</p>
				</div>
				<div class="iq-value-card" data-animate="fade-up">
					<span class="iq-value-icon">✂️</span>
					<h3>Real Craft</h3>
					<p>Two years of designing, stitching, and unpicking seams before IQSHAH ever had a name.</p>
				</div>
				<div class="iq-value-card" data-animate="fade-up">
					<span class="iq-value-icon">💛</span>
					<h3>Built By You</h3>
					<p>Every compliment, every "where did you get that from?" is what turned this into a brand.</p>
				</div>
			</div>
		</div>
	</section>

	<section class="iq-section iq-final-cta">
		<div class="container iq-narrow iq-center" data-animate="fade-up">
			<h2>Ready to feel <em>always beautiful</em>?</h2>
			<div class="iq-hero-ctas iq-center">
				<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="iq-btn iq-btn-primary iq-btn-lg">Start My Custom Order</a>
				<a href="<?php echo esc_url( home_url( '/products/' ) ); ?>" class="iq-btn iq-btn-outline iq-btn-lg">Explore Products</a>
			</div>
		</div>
	</section>

</main>
<?php get_footer(); ?>
