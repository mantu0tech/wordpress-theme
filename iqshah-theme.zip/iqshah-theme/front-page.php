<?php
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();

$hero_image = get_theme_mod( 'iqshah_hero_image', '' );
$trust      = get_theme_mod( 'iqshah_trust_strip', '' );
$trust_items = $trust ? array_map( 'trim', explode( '·', $trust ) ) : array();
?>

<main id="primary" class="site-main">

	<!-- HERO -->
	<section class="iq-hero" <?php if ( $hero_image ) echo 'style="background-image:linear-gradient(120deg, rgba(107,18,38,.88), rgba(74,12,26,.7)), url(' . esc_url( $hero_image ) . ');background-size:cover;background-position:center;"'; ?>>
		<div class="container iq-hero-inner">
			<div class="iq-hero-content" data-animate="fade-up">
				<span class="iq-eyebrow">Custom Fashion, Made With Love</span>
				<h1><?php echo esc_html( get_theme_mod( 'iqshah_hero_headline', "Tired of dresses that look perfect on the hanger and wrong on you?" ) ); ?></h1>
				<p class="iq-hero-sub"><?php echo esc_html( get_theme_mod( 'iqshah_hero_subheadline', '' ) ); ?></p>
				<div class="iq-hero-ctas">
					<a href="<?php echo esc_url( get_theme_mod( 'iqshah_hero_cta_primary_link', home_url('/contact/') ) ); ?>" class="iq-btn iq-btn-primary iq-btn-lg"><?php echo esc_html( get_theme_mod( 'iqshah_hero_cta_primary_text', 'Design My Dress' ) ); ?></a>
					<a href="<?php echo esc_url( get_theme_mod( 'iqshah_hero_cta_secondary_link', home_url('/shop/') ) ); ?>" class="iq-btn iq-btn-outline iq-btn-lg"><?php echo esc_html( get_theme_mod( 'iqshah_hero_cta_secondary_text', 'Shop Ready Dresses' ) ); ?></a>
				</div>
			</div>
		</div>
		<div class="iq-hero-wave">
			<svg viewBox="0 0 1440 100" preserveAspectRatio="none"><path d="M0,40 C360,100 1080,0 1440,50 L1440,100 L0,100 Z" fill="var(--iq-cream)"></path></svg>
		</div>
	</section>

	<!-- PAIN POINT -->
	<section class="iq-section iq-pain-section">
		<div class="container iq-narrow" data-animate="fade-up">
			<h2><?php echo esc_html( get_theme_mod( 'iqshah_pain_heading', "You shouldn't have to compromise on beautiful." ) ); ?></h2>
			<div class="iq-pain-body">
				<?php echo wpautop( esc_html( get_theme_mod( 'iqshah_pain_body', '' ) ) ); ?>
			</div>
		</div>
	</section>

	<!-- THE DIFFERENCE -->
	<section class="iq-section iq-diff-section">
		<div class="container">
			<h2 class="iq-section-title" data-animate="fade-up"><?php echo esc_html( get_theme_mod( 'iqshah_diff_heading', 'Beautiful, made for you — not just made.' ) ); ?></h2>
			<div class="iq-diff-grid">
				<?php iqshah_difference_blocks(); ?>
			</div>
		</div>
	</section>

	<!-- SOCIAL PROOF -->
	<section class="iq-section iq-testimonial-section">
		<div class="container">
			<h2 class="iq-section-title" data-animate="fade-up">Real women. Real confidence.</h2>
			<?php iqshah_render_testimonials(); ?>

			<?php if ( ! empty( $trust_items ) ) : ?>
				<div class="iq-trust-strip" data-animate="fade-up">
					<?php foreach ( $trust_items as $i => $item ) : ?>
						<span class="iq-trust-item"><?php echo esc_html( $item ); ?></span>
						<?php if ( $i < count( $trust_items ) - 1 ) echo '<span class="iq-trust-dot">•</span>'; ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</section>

	<!-- PRODUCTS PREVIEW (if WooCommerce active) -->
	<?php if ( class_exists( 'WooCommerce' ) ) : ?>
	<section class="iq-section iq-shop-preview">
		<div class="container">
			<h2 class="iq-section-title" data-animate="fade-up">Shop the Latest</h2>
			<div class="iq-shop-preview-grid">
				<?php echo do_shortcode( '[products limit="4" columns="4"]' ); ?>
			</div>
			<div class="iq-center"><a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="iq-btn iq-btn-outline">View All Products</a></div>
		</div>
	</section>
	<?php endif; ?>

	<!-- FINAL CTA -->
	<section class="iq-section iq-final-cta">
		<div class="container iq-narrow" data-animate="fade-up">
			<h2><?php echo esc_html( get_theme_mod( 'iqshah_final_heading', 'Your dress. Your fit. Your story.' ) ); ?></h2>
			<p><?php echo esc_html( get_theme_mod( 'iqshah_final_body', '' ) ); ?></p>
			<div class="iq-hero-ctas iq-center">
				<a href="<?php echo esc_url( get_theme_mod( 'iqshah_final_cta1_link', home_url('/contact/') ) ); ?>" class="iq-btn iq-btn-primary iq-btn-lg"><?php echo esc_html( get_theme_mod( 'iqshah_final_cta1_text', 'Start Designing My Dress' ) ); ?></a>
				<a href="<?php echo esc_url( get_theme_mod( 'iqshah_final_cta2_link', home_url('/shop/') ) ); ?>" class="iq-btn iq-btn-outline iq-btn-lg"><?php echo esc_html( get_theme_mod( 'iqshah_final_cta2_text', 'Browse Ready Collection' ) ); ?></a>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
