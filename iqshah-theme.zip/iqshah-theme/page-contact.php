<?php
/* Template Name: Contact Page */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
$sent = isset( $_GET['sent'] );
?>
<main id="primary" class="site-main">

	<section class="iq-page-hero">
		<div class="container iq-narrow iq-center" data-animate="fade-up">
			<span class="iq-eyebrow">We'd Love to Hear From You</span>
			<h1>Let's Talk About Your Dress</h1>
		</div>
	</section>

	<section class="iq-section iq-contact-section">
		<div class="container iq-contact-grid">

			<div class="iq-contact-left" data-animate="fade-right">
				<?php while ( have_posts() ) : the_post(); the_content(); endwhile; ?>

				<?php if ( $sent ) : ?>
					<div class="iq-form-success" role="status">
						✅ Thank you! Your message has been sent — one of us will personally reply on WhatsApp or email within 24 hours.
					</div>
				<?php endif; ?>

				<form class="iq-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="iqshah_contact">
					<?php wp_nonce_field( 'iqshah_contact_action', 'iqshah_contact_nonce' ); ?>
					<input type="text" name="iqshah_hp" class="iq-honeypot" tabindex="-1" autocomplete="off">

					<div class="iq-form-row">
						<label for="iqshah_name">Name</label>
						<input type="text" id="iqshah_name" name="iqshah_name" required placeholder="Your full name">
					</div>
					<div class="iq-form-row iq-form-row-half">
						<div>
							<label for="iqshah_whatsapp">WhatsApp Number</label>
							<input type="tel" id="iqshah_whatsapp" name="iqshah_whatsapp" required placeholder="+91 XXXXX XXXXX">
						</div>
						<div>
							<label for="iqshah_email">Email</label>
							<input type="email" id="iqshah_email" name="iqshah_email" placeholder="you@email.com">
						</div>
					</div>
					<div class="iq-form-row">
						<label for="iqshah_looking_for">What are you looking for?</label>
						<select id="iqshah_looking_for" name="iqshah_looking_for">
							<option value="Custom Dress">Custom Dress</option>
							<option value="Ready Dress">Ready Dress</option>
							<option value="Dupatta">Dupatta</option>
							<option value="Just a Question">Just a Question</option>
						</select>
					</div>
					<div class="iq-form-row">
						<label for="iqshah_message">Your Message</label>
						<textarea id="iqshah_message" name="iqshah_message" rows="5" required placeholder="Tell us about the dress you have in mind..."></textarea>
					</div>
					<button type="submit" class="iq-btn iq-btn-primary iq-btn-lg iq-btn-block">Send Message</button>
				</form>
			</div>

			<div class="iq-contact-right" data-animate="fade-left">
				<div class="iq-contact-card">
					<h3>What Happens After You Hit Send</h3>
					<ol class="iq-steps">
						<li><strong>Within 24 hours</strong>, one of us (yes, an actual IQSHAH sister or team member) will personally reply on WhatsApp or email.</li>
						<li>If it's a <strong>custom order</strong>, we'll ask a few quick questions about size, occasion, and style preferences to get you an accurate quote.</li>
						<li>If it's a <strong>ready dress or dupatta query</strong>, we'll confirm stock and share next steps to order.</li>
						<li>No spam, no sales pressure — just a real conversation about your dress.</li>
					</ol>
				</div>

				<div class="iq-contact-card iq-contact-direct">
					<h3>Prefer to chat directly?</h3>
					<a class="iq-contact-direct-link" href="https://wa.me/<?php echo esc_attr( preg_replace( '/[^0-9]/', '', get_theme_mod( 'iqshah_whatsapp', '918369766855' ) ) ); ?>" target="_blank" rel="noopener">📱 WhatsApp: <?php echo esc_html( get_theme_mod( 'iqshah_whatsapp_display', '+91 83697 66855' ) ); ?></a>
					<a class="iq-contact-direct-link" href="mailto:<?php echo esc_attr( get_theme_mod( 'iqshah_email', 'hello.iqshah@gmail.com' ) ); ?>">📧 Email: <?php echo esc_html( get_theme_mod( 'iqshah_email', 'hello.iqshah@gmail.com' ) ); ?></a>
					<p class="iq-contact-address">📍 <?php echo esc_html( get_theme_mod( 'iqshah_address', 'Based in Mumbai, shipping across India' ) ); ?></p>
					<?php iqshah_social_links( 'iq-social-links iq-contact-socials' ); ?>
				</div>
			</div>

		</div>
	</section>

</main>
<?php get_footer(); ?>
