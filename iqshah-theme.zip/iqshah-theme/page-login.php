<?php
/* Template Name: Login Page */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( is_user_logged_in() ) {
	$user = wp_get_current_user();
	if ( in_array( 'administrator', (array) $user->roles, true ) ) {
		wp_safe_redirect( admin_url() );
	} elseif ( function_exists( 'wc_get_page_permalink' ) ) {
		wp_safe_redirect( wc_get_page_permalink( 'myaccount' ) );
	} else {
		wp_safe_redirect( home_url( '/' ) );
	}
	exit;
}

get_header();
$login_error = isset( $_GET['login_error'] ) ? sanitize_text_field( wp_unslash( $_GET['login_error'] ) ) : '';
$redirect_to = isset( $_GET['redirect_to'] ) ? esc_url_raw( $_GET['redirect_to'] ) : home_url( '/' );
?>
<main id="primary" class="site-main">
	<section class="iq-section iq-auth-section">
		<div class="container iq-auth-container">
			<div class="iq-auth-card" data-animate="fade-up">
				<div class="iq-auth-logo">
					<?php if ( has_custom_logo() ) : the_custom_logo(); else : ?>
						<img src="<?php echo esc_url( IQSHAH_URI . '/assets/images/logo.jpg' ); ?>" alt="IQSHAH">
					<?php endif; ?>
				</div>
				<h1 class="iq-auth-title">Welcome Back</h1>
				<p class="iq-auth-sub">Log in to track your orders, manage your custom fit profile, or access your dashboard.</p>

				<?php if ( $login_error ) : ?>
					<div class="iq-form-error" role="alert"><?php echo wp_kses_post( $login_error ); ?></div>
				<?php endif; ?>
				<?php if ( isset( $_GET['registered'] ) ) : ?>
					<div class="iq-form-success" role="status">✅ Account created! You can now log in below.</div>
				<?php endif; ?>

				<form class="iq-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="iqshah_login">
					<input type="hidden" name="iqshah_redirect" value="<?php echo esc_url( $redirect_to ); ?>">
					<?php wp_nonce_field( 'iqshah_login_action', 'iqshah_login_nonce' ); ?>

					<div class="iq-form-row">
						<label for="iqshah_username">Username or Email</label>
						<input type="text" id="iqshah_username" name="iqshah_username" required autofocus placeholder="you@email.com">
					</div>
					<div class="iq-form-row">
						<label for="iqshah_password">Password</label>
						<div class="iq-password-wrap">
							<input type="password" id="iqshah_password" name="iqshah_password" required placeholder="••••••••">
							<button type="button" class="iq-password-toggle" aria-label="Show password">👁</button>
						</div>
					</div>
					<div class="iq-form-row iq-form-row-inline">
						<label class="iq-checkbox-label"><input type="checkbox" name="iqshah_remember" checked> Remember me</label>
						<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>" class="iq-forgot-link">Forgot password?</a>
					</div>
					<button type="submit" class="iq-btn iq-btn-primary iq-btn-lg iq-btn-block">Log In</button>
				</form>

				<p class="iq-auth-switch">Don't have an account? <a href="<?php echo esc_url( home_url( '/register/' ) ); ?>">Register here</a></p>
			</div>
		</div>
	</section>
</main>
<?php get_footer(); ?>
