<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'iqshah' ); ?></a>

<div class="iq-topbar">
	<div class="container iq-topbar-inner">
		<div class="iq-topbar-left">
			<span>✨ <?php echo esc_html( get_theme_mod( 'iqshah_footer_tagline', 'Always Beautiful.' ) ); ?></span>
		</div>
		<div class="iq-topbar-right">
			<a href="mailto:<?php echo esc_attr( get_theme_mod( 'iqshah_email', 'hello.iqshah@gmail.com' ) ); ?>"><?php echo esc_html( get_theme_mod( 'iqshah_email', 'hello.iqshah@gmail.com' ) ); ?></a>
			<span class="iq-topbar-divider">|</span>
			<a href="https://wa.me/<?php echo esc_attr( preg_replace( '/[^0-9]/', '', get_theme_mod( 'iqshah_whatsapp', '918369766855' ) ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( get_theme_mod( 'iqshah_whatsapp_display', '+91 83697 66855' ) ); ?></a>
		</div>
	</div>
</div>

<header id="masthead" class="iq-header">
	<div class="container iq-header-inner">
		<div class="iq-branding">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="iq-logo-link" rel="home">
				<?php
				if ( has_custom_logo() ) {
					the_custom_logo();
				} else {
					?>
					<img src="<?php echo esc_url( IQSHAH_URI . '/assets/images/logo.jpg' ); ?>" alt="<?php bloginfo( 'name' ); ?>" class="iq-default-logo">
					<?php
				}
				?>
			</a>
		</div>

		<nav id="site-navigation" class="iq-primary-nav" aria-label="Primary">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'iq-nav-menu',
				'fallback_cb'    => false,
			) );
			?>
		</nav>

		<div class="iq-header-actions">
			<?php if ( is_user_logged_in() ) :
				$current_user = wp_get_current_user();
				?>
				<a href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : admin_url() ); ?>" class="iq-account-link" title="My Account">
					<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M12 12c2.7 0 4.9-2.2 4.9-4.9S14.7 2.2 12 2.2 7.1 4.4 7.1 7.1 9.3 12 12 12zm0 2.4c-3.3 0-9.8 1.6-9.8 4.9v2.5h19.6v-2.5c0-3.3-6.5-4.9-9.8-4.9z"/></svg>
					<span><?php echo esc_html( $current_user->display_name ); ?></span>
				</a>
			<?php else : ?>
				<a href="<?php echo esc_url( home_url( '/login/' ) ); ?>" class="iq-btn iq-btn-ghost">Login</a>
			<?php endif; ?>

			<?php if ( class_exists( 'WooCommerce' ) ) : ?>
				<a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="iq-cart-link" title="Cart">
					<svg viewBox="0 0 24 24" width="20" height="20"><path fill="currentColor" d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12L8.1 13h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zM17 18c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg>
					<span class="iq-cart-count"><?php echo absint( WC()->cart ? WC()->cart->get_cart_contents_count() : 0 ); ?></span>
				</a>
			<?php endif; ?>

			<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="iq-btn iq-btn-primary iq-header-cta">Design My Dress</a>

			<button class="iq-menu-toggle" aria-label="Toggle menu" aria-expanded="false">
				<span></span><span></span><span></span>
			</button>
		</div>
	</div>

	<div class="iq-mobile-nav">
		<?php
		wp_nav_menu( array(
			'theme_location' => 'primary',
			'container'      => false,
			'menu_class'     => 'iq-mobile-nav-menu',
			'fallback_cb'    => false,
		) );
		?>
		<div class="iq-mobile-nav-actions">
			<?php if ( ! is_user_logged_in() ) : ?>
				<a href="<?php echo esc_url( home_url( '/login/' ) ); ?>" class="iq-btn iq-btn-ghost">Login</a>
				<a href="<?php echo esc_url( home_url( '/register/' ) ); ?>" class="iq-btn iq-btn-primary">Register</a>
			<?php endif; ?>
			<a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="iq-btn iq-btn-primary">Design My Dress</a>
		</div>
	</div>
</header>
