<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<footer id="colophon" class="iq-footer">
	<div class="container iq-footer-top">
		<div class="iq-footer-col iq-footer-brand">
			<?php
			if ( has_custom_logo() ) {
				the_custom_logo();
			} else {
				echo '<img src="' . esc_url( IQSHAH_URI . '/assets/images/logo.jpg' ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" class="iq-footer-logo">';
			}
			?>
			<p class="iq-footer-tagline"><?php echo esc_html( get_theme_mod( 'iqshah_footer_tagline', 'Always Beautiful.' ) ); ?></p>
			<?php iqshah_social_links( 'iq-social-links iq-footer-socials' ); ?>
		</div>

		<div class="iq-footer-col">
			<h4 class="footer-widget-title"><?php esc_html_e( 'Quick Links', 'iqshah' ); ?></h4>
			<?php
			wp_nav_menu( array(
				'theme_location' => 'footer',
				'container'      => false,
				'menu_class'     => 'iq-footer-menu',
				'fallback_cb'    => 'iqshah_default_footer_links',
			) );
			?>
		</div>

		<div class="iq-footer-col">
			<?php if ( is_active_sidebar( 'footer-1' ) ) dynamic_sidebar( 'footer-1' ); ?>
		</div>

		<div class="iq-footer-col">
			<h4 class="footer-widget-title"><?php esc_html_e( 'Get in Touch', 'iqshah' ); ?></h4>
			<ul class="iq-footer-contact">
				<li>📧 <a href="mailto:<?php echo esc_attr( get_theme_mod( 'iqshah_email', 'hello.iqshah@gmail.com' ) ); ?>"><?php echo esc_html( get_theme_mod( 'iqshah_email', 'hello.iqshah@gmail.com' ) ); ?></a></li>
				<li>📱 <a href="https://wa.me/<?php echo esc_attr( preg_replace( '/[^0-9]/', '', get_theme_mod( 'iqshah_whatsapp', '918369766855' ) ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( get_theme_mod( 'iqshah_whatsapp_display', '+91 83697 66855' ) ); ?></a></li>
				<li>📍 <?php echo esc_html( get_theme_mod( 'iqshah_address', 'Based in Mumbai, shipping across India' ) ); ?></li>
			</ul>
			<?php if ( is_active_sidebar( 'footer-2' ) ) dynamic_sidebar( 'footer-2' ); ?>
		</div>
	</div>

	<div class="iq-footer-bottom">
		<div class="container iq-footer-bottom-inner">
			<p><?php echo esc_html( get_theme_mod( 'iqshah_footer_copyright', '© ' . date( 'Y' ) . ' IQSHAH. All rights reserved.' ) ); ?></p>
			<p class="iq-footer-credit"><?php esc_html_e( 'Made with love, in Mumbai.', 'iqshah' ); ?></p>
		</div>
	</div>
</footer>

<?php iqshah_whatsapp_float(); ?>

<?php wp_footer(); ?>
</body>
</html>
<?php
function iqshah_default_footer_links() {
	echo '<ul class="iq-footer-menu">';
	echo '<li><a href="' . esc_url( home_url( '/about/' ) ) . '">About Us</a></li>';
	echo '<li><a href="' . esc_url( home_url( '/products/' ) ) . '">Products</a></li>';
	echo '<li><a href="' . esc_url( home_url( '/contact/' ) ) . '">Contact</a></li>';
	echo '<li><a href="' . esc_url( home_url( '/login/' ) ) . '">Login</a></li>';
	echo '</ul>';
}
