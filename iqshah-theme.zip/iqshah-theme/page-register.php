<?php
/* Template Name: Register Page */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( is_user_logged_in() ) {
	wp_safe_redirect( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/' ) );
	exit;
}

get_header();
$register_error = isset( $_GET['register_error'] ) ? sanitize_text_field( wp_unslash( $_GET['register_error'] ) ) : '';
?>
<main id="primary" class="site-main">
	<section class="iq-section iq-auth-section">
		<div class="container iq-auth-container">
			<div class="iq-auth-card" data-animate="fade-up">
				<div class="iq-auth-logo">
					<?php if ( has_custom_logo() ) : the_custom_logo(); else : ?>
						<img src="<?php echo esc_url( IQSHAH_URI . '/assets/images/logo.jpg' ); ?>" alt="IQSHAH">
					<?php endif; ?>
				</div>
				<h1 class="iq-auth-title">Join IQSHAH</h1>
				<p class="iq-auth-sub">Create an account to track custom orders, save your measurements, and shop faster next time.</p>

				<?php if ( $register_error ) : ?>
					<div class="iq-form-error" role="alert"><?php echo wp_kses_post( $register_error ); ?></div>
				<?php endif; ?>

				<form class="iq-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="iqshah_register">
					<?php wp_nonce_field( 'iqshah_register_action', 'iqshah_register_nonce' ); ?>

					<div class="iq-form-row">
						<label for="iqshah_reg_name">Full Name</label>
						<input type="text" id="iqshah_reg_name" name="iqshah_reg_name" required autofocus placeholder="Your full name">
					</div>
					<div class="iq-form-row">
						<label for="iqshah_reg_email">Email</label>
						<input type="email" id="iqshah_reg_email" name="iqshah_reg_email" required placeholder="you@email.com">
					</div>
					<div class="iq-form-row">
						<label for="iqshah_reg_whatsapp">WhatsApp Number</label>
						<input type="tel" id="iqshah_reg_whatsapp" name="iqshah_reg_whatsapp" placeholder="+91 XXXXX XXXXX">
					</div>
					<div class="iq-form-row">
						<label for="iqshah_reg_password">Password</label>
						<div class="iq-password-wrap">
							<input type="password" id="iqshah_reg_password" name="iqshah_reg_password" required minlength="6" placeholder="At least 6 characters">
							<button type="button" class="iq-password-toggle" aria-label="Show password">👁</button>
						</div>
					</div>
					<div class="iq-form-row">
						<label class="iq-checkbox-label"><input type="checkbox" required> I agree to be contacted about my order via WhatsApp or email.</label>
					</div>
					<button type="submit" class="iq-btn iq-btn-primary iq-btn-lg iq-btn-block">Create My Account</button>
				</form>

				<p class="iq-auth-switch">Already have an account? <a href="<?php echo esc_url( home_url( '/login/' ) ); ?>">Log in here</a></p>
			</div>
		</div>
	</section>
</main>
<?php get_footer(); ?>
