<?php
/**
 * The template for displaying all static pages.
 *
 * @package Manish_Construction
 */

get_header();
?>

<section class="mc-section">
	<div class="mc-container">

		<?php while ( have_posts() ) : the_post(); ?>

			<?php if ( has_post_thumbnail() && ! is_front_page() ) : ?>
				<div class="mc-property-hero">
					<?php the_post_thumbnail( 'mc-hero-large' ); ?>
				</div>
			<?php endif; ?>

			<header class="mc-section-header" style="text-align:left;max-width:820px;margin:0 auto 30px;">
				<h1><?php the_title(); ?></h1>
			</header>

			<div class="page-content">
				<?php
				the_content();

				wp_link_pages( array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'manish-construction' ),
					'after'  => '</div>',
				) );
				?>
			</div>

			<?php if ( comments_open() || get_comments_number() ) : ?>
				<?php comments_template(); ?>
			<?php endif; ?>

		<?php endwhile; ?>

	</div>
</section>

<?php get_footer(); ?>
