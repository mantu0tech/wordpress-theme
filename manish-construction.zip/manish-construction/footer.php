<?php
/**
 * The footer for the Manish Construction theme.
 *
 * @package Manish_Construction
 */
?>

</div><!-- #content -->

<footer id="colophon" class="site-footer">

	<div class="mc-footer-top">
		<div class="mc-container mc-footer-grid">

			<div class="mc-footer-col">
				<span class="mc-footer-logo"><?php bloginfo( 'name' ); ?></span>
				<p><?php esc_html_e( 'Building homes and businesses with quality, integrity and craftsmanship since day one. Your trusted partner in real estate and construction.', 'manish-construction' ); ?></p>
				<div class="mc-footer-social">
					<?php if ( mc_mod( 'mc_facebook' ) ) : ?><a href="<?php echo esc_url( mc_mod( 'mc_facebook' ) ); ?>" aria-label="Facebook">FB</a><?php endif; ?>
					<?php if ( mc_mod( 'mc_instagram' ) ) : ?><a href="<?php echo esc_url( mc_mod( 'mc_instagram' ) ); ?>" aria-label="Instagram">IG</a><?php endif; ?>
					<?php if ( mc_mod( 'mc_linkedin' ) ) : ?><a href="<?php echo esc_url( mc_mod( 'mc_linkedin' ) ); ?>" aria-label="LinkedIn">IN</a><?php endif; ?>
				</div>
			</div>

			<div class="mc-footer-col">
				<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
					<?php dynamic_sidebar( 'footer-1' ); ?>
				<?php else : ?>
					<h3><?php esc_html_e( 'Quick Links', 'manish-construction' ); ?></h3>
					<?php
					wp_nav_menu( array(
						'theme_location' => 'footer',
						'container'      => false,
						'menu_id'        => 'footer-menu',
						'fallback_cb'    => false,
					) );
					?>
				<?php endif; ?>
			</div>

			<div class="mc-footer-col">
				<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
					<?php dynamic_sidebar( 'footer-2' ); ?>
				<?php else : ?>
					<h3><?php esc_html_e( 'Properties', 'manish-construction' ); ?></h3>
					<ul>
						<li><a href="<?php echo esc_url( get_post_type_archive_link( 'property' ) ); ?>"><?php esc_html_e( 'All Listings', 'manish-construction' ); ?></a></li>
						<?php
						$types = get_terms( array( 'taxonomy' => 'property_type', 'hide_empty' => false, 'number' => 4 ) );
						if ( ! is_wp_error( $types ) ) {
							foreach ( $types as $type ) {
								echo '<li><a href="' . esc_url( get_term_link( $type ) ) . '">' . esc_html( $type->name ) . '</a></li>';
							}
						}
						?>
					</ul>
				<?php endif; ?>
			</div>

			<div class="mc-footer-col">
				<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
					<?php dynamic_sidebar( 'footer-3' ); ?>
				<?php else : ?>
					<h3><?php esc_html_e( 'Contact Us', 'manish-construction' ); ?></h3>
					<p>&#128205; <?php echo esc_html( mc_mod( 'mc_address', 'Downtown Business District' ) ); ?></p>
					<p>&#128222; <a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', mc_mod( 'mc_phone', '+15551234567' ) ) ); ?>"><?php echo esc_html( mc_mod( 'mc_phone', '+1 (555) 123-4567' ) ); ?></a></p>
					<p>&#9993; <a href="mailto:<?php echo esc_attr( mc_mod( 'mc_email', 'info@manishconstruction.com' ) ); ?>"><?php echo esc_html( mc_mod( 'mc_email', 'info@manishconstruction.com' ) ); ?></a></p>
				<?php endif; ?>
			</div>

		</div>
	</div>

	<div class="mc-footer-bottom">
		<div class="mc-container">
			<p>&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'manish-construction' ); ?></p>
			<p><?php esc_html_e( 'Built with WordPress', 'manish-construction' ); ?></p>
		</div>
	</div>

</footer>

<?php wp_footer(); ?>
</body>
</html>
