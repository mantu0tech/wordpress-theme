<?php
/**
 * The header for the Manish Construction theme.
 *
 * @package Manish_Construction
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'manish-construction' ); ?></a>

<div class="mc-topbar">
	<div class="mc-container">
		<div class="mc-topbar-contacts">
			<?php if ( mc_mod( 'mc_phone' ) ) : ?>
				<span>&#128222; <a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', mc_mod( 'mc_phone' ) ) ); ?>"><?php echo esc_html( mc_mod( 'mc_phone', '+1 (555) 123-4567' ) ); ?></a></span>
			<?php else : ?>
				<span>&#128222; <a href="tel:+15551234567">+1 (555) 123-4567</a></span>
			<?php endif; ?>
			<span>&#9993; <a href="mailto:<?php echo esc_attr( mc_mod( 'mc_email', 'info@manishconstruction.com' ) ); ?>"><?php echo esc_html( mc_mod( 'mc_email', 'info@manishconstruction.com' ) ); ?></a></span>
			<span>&#128205; <?php echo esc_html( mc_mod( 'mc_address', 'Downtown Business District' ) ); ?></span>
		</div>
		<div class="mc-topbar-social">
			<?php if ( mc_mod( 'mc_facebook' ) ) : ?><a href="<?php echo esc_url( mc_mod( 'mc_facebook' ) ); ?>" aria-label="Facebook">FB</a><?php endif; ?>
			<?php if ( mc_mod( 'mc_instagram' ) ) : ?><a href="<?php echo esc_url( mc_mod( 'mc_instagram' ) ); ?>" aria-label="Instagram">IG</a><?php endif; ?>
			<?php if ( mc_mod( 'mc_linkedin' ) ) : ?><a href="<?php echo esc_url( mc_mod( 'mc_linkedin' ) ); ?>" aria-label="LinkedIn">IN</a><?php endif; ?>
		</div>
	</div>
</div>

<header id="masthead" class="site-header">
	<div class="mc-header-inner mc-container">

		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<div>
					<p class="site-title">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
					</p>
					<?php $description = get_bloginfo( 'description', 'display' ); ?>
					<?php if ( $description ) : ?>
						<p class="site-description"><?php echo esc_html( $description ); ?></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>

		<nav id="site-navigation" class="main-navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'manish-construction' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'menu_id'        => 'primary-menu',
				'container'      => false,
				'fallback_cb'    => 'mc_fallback_menu',
			) );
			?>
		</nav>

		<div class="mc-header-cta">
			<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', mc_mod( 'mc_phone', '+15551234567' ) ) ); ?>" class="mc-btn mc-btn-dark">
				<?php esc_html_e( 'Get a Quote', 'manish-construction' ); ?>
			</a>
			<button class="mc-menu-toggle" aria-controls="site-navigation" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle menu', 'manish-construction' ); ?>">
				<span></span><span></span><span></span>
			</button>
		</div>

	</div>
</header>

<div id="content" class="site-content">
