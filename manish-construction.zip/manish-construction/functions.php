<?php
/**
 * Manish Construction Theme functions and definitions
 *
 * @package Manish_Construction
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'MC_THEME_VERSION', '1.0.0' );

/* =========================================================
   1. THEME SETUP
========================================================= */
function mc_theme_setup() {

	load_theme_textdomain( 'manish-construction', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 60,
		'width'       => 200,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
	) );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );

	set_post_thumbnail_size( 800, 600, true );
	add_image_size( 'mc-card', 600, 450, true );
	add_image_size( 'mc-hero-large', 1600, 900, true );

	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'manish-construction' ),
		'footer'  => __( 'Footer Menu', 'manish-construction' ),
	) );
}
add_action( 'after_setup_theme', 'mc_theme_setup' );

/* =========================================================
   2. ENQUEUE STYLES & SCRIPTS
========================================================= */
function mc_enqueue_assets() {
	wp_enqueue_style( 'mc-google-fonts', 'https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Inter:wght@400;500;600&display=swap', array(), null );
	wp_enqueue_style( 'manish-construction-style', get_stylesheet_uri(), array(), MC_THEME_VERSION );
	wp_enqueue_script( 'manish-construction-custom', get_template_directory_uri() . '/js/custom.js', array(), MC_THEME_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'mc_enqueue_assets' );

/* =========================================================
   3. WIDGET AREAS
========================================================= */
function mc_register_widgets() {
	register_sidebar( array(
		'name'          => __( 'Footer Column 1', 'manish-construction' ),
		'id'            => 'footer-1',
		'before_widget' => '<div class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Column 2', 'manish-construction' ),
		'id'            => 'footer-2',
		'before_widget' => '<div class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Column 3', 'manish-construction' ),
		'id'            => 'footer-3',
		'before_widget' => '<div class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'mc_register_widgets' );

/* =========================================================
   4. CUSTOM POST TYPE: PROPERTY
========================================================= */
function mc_register_property_cpt() {

	$labels = array(
		'name'               => __( 'Properties', 'manish-construction' ),
		'singular_name'      => __( 'Property', 'manish-construction' ),
		'add_new_item'       => __( 'Add New Property', 'manish-construction' ),
		'edit_item'          => __( 'Edit Property', 'manish-construction' ),
		'new_item'           => __( 'New Property', 'manish-construction' ),
		'view_item'          => __( 'View Property', 'manish-construction' ),
		'search_items'       => __( 'Search Properties', 'manish-construction' ),
		'not_found'          => __( 'No properties found', 'manish-construction' ),
		'menu_name'          => __( 'Properties', 'manish-construction' ),
	);

	register_post_type( 'property', array(
		'labels'        => $labels,
		'public'        => true,
		'has_archive'   => true,
		'menu_icon'     => 'dashicons-admin-multisite',
		'rewrite'       => array( 'slug' => 'properties' ),
		'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
		'show_in_rest'  => true,
	) );

	register_taxonomy( 'property_type', 'property', array(
		'labels'            => array(
			'name'          => __( 'Property Types', 'manish-construction' ),
			'singular_name' => __( 'Property Type', 'manish-construction' ),
		),
		'hierarchical'      => true,
		'show_admin_column' => true,
		'rewrite'           => array( 'slug' => 'property-type' ),
		'show_in_rest'      => true,
	) );

	register_taxonomy( 'property_location', 'property', array(
		'labels'            => array(
			'name'          => __( 'Locations', 'manish-construction' ),
			'singular_name' => __( 'Location', 'manish-construction' ),
		),
		'hierarchical'      => true,
		'show_admin_column' => true,
		'rewrite'           => array( 'slug' => 'location' ),
		'show_in_rest'      => true,
	) );
}
add_action( 'init', 'mc_register_property_cpt' );

/* =========================================================
   5. PROPERTY META BOX
========================================================= */
function mc_add_property_meta_box() {
	add_meta_box(
		'mc_property_details',
		__( 'Property Details', 'manish-construction' ),
		'mc_render_property_meta_box',
		'property',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'mc_add_property_meta_box' );

function mc_render_property_meta_box( $post ) {
	wp_nonce_field( 'mc_save_property_meta', 'mc_property_meta_nonce' );

	$fields = array(
		'mc_price'      => __( 'Price (e.g. $250,000)', 'manish-construction' ),
		'mc_status'     => __( 'Status (For Sale / For Rent / Sold)', 'manish-construction' ),
		'mc_location'   => __( 'Address / Location', 'manish-construction' ),
		'mc_bedrooms'   => __( 'Bedrooms', 'manish-construction' ),
		'mc_bathrooms'  => __( 'Bathrooms', 'manish-construction' ),
		'mc_area'       => __( 'Area (sq ft)', 'manish-construction' ),
		'mc_year_built' => __( 'Year Built', 'manish-construction' ),
	);

	echo '<table class="form-table">';
	foreach ( $fields as $key => $label ) {
		$value = get_post_meta( $post->ID, $key, true );
		echo '<tr><th style="text-align:left;padding:8px 0;"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th>';
		echo '<td><input type="text" style="width:100%;" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" /></td></tr>';
	}
	echo '</table>';
}

function mc_save_property_meta( $post_id ) {
	if ( ! isset( $_POST['mc_property_meta_nonce'] ) || ! wp_verify_nonce( $_POST['mc_property_meta_nonce'], 'mc_save_property_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$keys = array( 'mc_price', 'mc_status', 'mc_location', 'mc_bedrooms', 'mc_bathrooms', 'mc_area', 'mc_year_built' );
	foreach ( $keys as $key ) {
		if ( isset( $_POST[ $key ] ) ) {
			update_post_meta( $post_id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
}
add_action( 'save_post_property', 'mc_save_property_meta' );

/**
 * Helper: get all property meta as an array.
 */
function mc_get_property_meta( $post_id ) {
	return array(
		'price'      => get_post_meta( $post_id, 'mc_price', true ),
		'status'     => get_post_meta( $post_id, 'mc_status', true ),
		'location'   => get_post_meta( $post_id, 'mc_location', true ),
		'bedrooms'   => get_post_meta( $post_id, 'mc_bedrooms', true ),
		'bathrooms'  => get_post_meta( $post_id, 'mc_bathrooms', true ),
		'area'       => get_post_meta( $post_id, 'mc_area', true ),
		'year_built' => get_post_meta( $post_id, 'mc_year_built', true ),
	);
}

/* =========================================================
   6. MISC THEME HELPERS
========================================================= */

// Trim excerpt length.
function mc_excerpt_length( $length ) {
	return 22;
}
add_filter( 'excerpt_length', 'mc_excerpt_length' );

function mc_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'mc_excerpt_more' );

// Fallback menu if no menu assigned.
function mc_fallback_menu() {
	echo '<ul id="primary-menu">';
	wp_list_pages( array( 'title_li' => '' ) );
	echo '<li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">' . esc_html__( 'Add a Menu', 'manish-construction' ) . '</a></li>';
	echo '</ul>';
}

// Register a Customizer setting for phone/contact info + hero (kept lightweight, no external libraries).
function mc_customize_register( $wp_customize ) {
	$wp_customize->add_section( 'mc_contact_section', array(
		'title'    => __( 'Company Contact Info', 'manish-construction' ),
		'priority' => 30,
	) );

	$fields = array(
		'mc_phone'       => __( 'Phone Number', 'manish-construction' ),
		'mc_email'       => __( 'Email Address', 'manish-construction' ),
		'mc_address'     => __( 'Office Address', 'manish-construction' ),
		'mc_facebook'    => __( 'Facebook URL', 'manish-construction' ),
		'mc_instagram'   => __( 'Instagram URL', 'manish-construction' ),
		'mc_linkedin'    => __( 'LinkedIn URL', 'manish-construction' ),
		'mc_hero_title'  => __( 'Hero Heading', 'manish-construction' ),
		'mc_hero_text'   => __( 'Hero Subtext', 'manish-construction' ),
	);

	foreach ( $fields as $id => $label ) {
		$wp_customize->add_setting( $id, array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
		$wp_customize->add_control( $id, array(
			'label'   => $label,
			'section' => 'mc_contact_section',
			'type'    => 'text',
		) );
	}
}
add_action( 'customize_register', 'mc_customize_register' );

/**
 * Safe theme_mod getter with fallback text.
 */
function mc_mod( $key, $fallback = '' ) {
	$val = get_theme_mod( $key, '' );
	return $val ? $val : $fallback;
}

// Add a "read more" excerpt wrapper class, widen content width for embeds, etc.
if ( ! isset( $content_width ) ) {
	$content_width = 820;
}

// Body classes helper.
function mc_body_classes( $classes ) {
	if ( ! is_singular() ) {
		$classes[] = 'mc-has-sidebar-off';
	}
	return $classes;
}
add_filter( 'body_class', 'mc_body_classes' );

/* =========================================================
   7. REUSABLE TEMPLATE HELPERS (used by index/archive)
========================================================= */

/**
 * Output a property card. Echoes markup directly.
 */
function mc_render_property_card() {
	$meta = mc_get_property_meta( get_the_ID() );
	?>
	<article <?php post_class( 'mc-card' ); ?>>
		<a href="<?php the_permalink(); ?>" class="mc-card-thumb">
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'mc-card' ); ?>
			<?php else : ?>
				<div style="width:100%;height:100%;background:var(--mc-light);"></div>
			<?php endif; ?>
			<?php if ( $meta['status'] ) : ?>
				<span class="mc-card-badge"><?php echo esc_html( $meta['status'] ); ?></span>
			<?php endif; ?>
			<?php if ( $meta['price'] ) : ?>
				<span class="mc-card-price"><?php echo esc_html( $meta['price'] ); ?></span>
			<?php endif; ?>
		</a>
		<div class="mc-card-body">
			<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
			<?php if ( $meta['location'] ) : ?>
				<p class="mc-card-location">&#128205; <?php echo esc_html( $meta['location'] ); ?></p>
			<?php endif; ?>
			<div class="mc-card-meta">
				<?php if ( $meta['bedrooms'] ) : ?><span>&#128716; <?php echo esc_html( $meta['bedrooms'] ); ?> <?php esc_html_e( 'Beds', 'manish-construction' ); ?></span><?php endif; ?>
				<?php if ( $meta['bathrooms'] ) : ?><span>&#128705; <?php echo esc_html( $meta['bathrooms'] ); ?> <?php esc_html_e( 'Baths', 'manish-construction' ); ?></span><?php endif; ?>
				<?php if ( $meta['area'] ) : ?><span>&#128207; <?php echo esc_html( $meta['area'] ); ?> <?php esc_html_e( 'sqft', 'manish-construction' ); ?></span><?php endif; ?>
			</div>
		</div>
	</article>
	<?php
}

/**
 * Output a standard blog post card.
 */
function mc_render_post_card() {
	?>
	<article <?php post_class( 'mc-post-card' ); ?>>
		<?php if ( has_post_thumbnail() ) : ?>
			<a href="<?php the_permalink(); ?>" class="mc-post-thumb">
				<?php the_post_thumbnail( 'mc-card' ); ?>
			</a>
		<?php endif; ?>
		<div class="mc-post-body">
			<p class="mc-post-meta">
				<?php echo esc_html( get_the_date() ); ?> &middot;
				<?php esc_html_e( 'by', 'manish-construction' ); ?> <?php the_author(); ?>
				<?php if ( has_category() ) : ?> &middot; <?php the_category( ', ' ); ?><?php endif; ?>
			</p>
			<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<div><?php the_excerpt(); ?></div>
			<a href="<?php the_permalink(); ?>" class="mc-btn mc-btn-dark" style="align-self:flex-start;">
				<?php esc_html_e( 'Read More', 'manish-construction' ); ?>
			</a>
		</div>
	</article>
	<?php
}

/**
 * Custom pagination wrapper using core the_posts_pagination().
 */
function mc_pagination() {
	the_posts_pagination( array(
		'mid_size'  => 2,
		'prev_text' => __( '&larr; Previous', 'manish-construction' ),
		'next_text' => __( 'Next &rarr;', 'manish-construction' ),
		'screen_reader_text' => __( 'Posts navigation', 'manish-construction' ),
		'before_page_number' => '',
	) );
}
