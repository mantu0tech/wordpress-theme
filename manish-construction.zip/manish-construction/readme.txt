=== Manish Construction ===
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A modern, responsive WordPress theme for real estate and construction businesses, built entirely with native/core WordPress functions (no page builder or third-party framework required).

== Installation ==

1. Zip the "manish-construction" folder (if not already zipped).
2. In wp-admin go to Appearance > Themes > Add New > Upload Theme.
3. Choose the manish-construction.zip file and click Install Now, then Activate.

== Setting Up ==

1. Appearance > Menus — create a menu, assign it to "Primary Menu" and/or "Footer Menu".
2. Appearance > Customize > Company Contact Info — add your phone, email, address and social links.
3. Appearance > Customize > Homepage Settings — set a static front page if desired (the theme's built-in homepage layout shows automatically when the front page displays your latest posts, or assign a Page and it will use page.php).
4. Properties menu (left sidebar in wp-admin) — click "Add New" to add a property listing. Fill in the Property Details box (price, status, location, bedrooms, bathrooms, area, year built) and set a Featured Image.
5. Organize listings using the "Property Types" and "Locations" taxonomies (found under the Properties menu).
6. Appearance > Widgets — add widgets to Footer Column 1, 2 and 3.
7. Upload a custom logo via Appearance > Customize > Site Identity.

== Included Templates ==

* style.css        — theme stylesheet & header (required by WordPress)
* functions.php     — theme setup, Property custom post type, meta boxes, menus, widget areas, customizer fields
* header.php        — site header, top bar, logo, navigation, mobile menu button
* footer.php        — footer widget columns, contact info, copyright
* index.php         — homepage hero/sections when set as front page, and default blog loop otherwise
* page.php          — standard WordPress Page template
* single.php         — single blog post AND single Property listing (auto-detected by post type)
* archive.php       — Property archive, taxonomy archives, and standard blog archives/categories/tags
* 404.php           — not found page with search
* comments.php      — threaded comments template
* js/custom.js      — mobile navigation toggle & sticky header script

== Notes ==

- The theme uses only core WordPress template tags/functions (register_post_type, register_taxonomy, add_meta_box, wp_nav_menu, register_sidebar, get_theme_mod, etc.) — no external page builder is required.
- After activation, go to Settings > Permalinks and click "Save Changes" once to flush rewrite rules for the new "Properties" URL structure.
- Add a screenshot.png (1200x900px) to the theme folder for a preview thumbnail in Appearance > Themes.
