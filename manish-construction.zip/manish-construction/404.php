<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @package Manish_Construction
 */

get_header();
?>

<section class="mc-section">
	<div class="mc-container mc-404">
		<h1>404</h1>
		<h2><?php esc_html_e( 'This Page Could Not Be Found', 'manish-construction' ); ?></h2>
		<p><?php esc_html_e( 'The page you are looking for may have been moved, renamed, or is temporarily unavailable. Try searching below or head back to the homepage.', 'manish-construction' ); ?></p>

		<form class="mc-404-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="mc-404-s"><?php esc_html_e( 'Search for:', 'manish-construction' ); ?></label>
			<input type="text" id="mc-404-s" name="s" placeholder="<?php esc_attr_e( 'Search the site&hellip;', 'manish-construction' ); ?>">
			<button type="submit" class="mc-btn mc-btn-primary"><?php esc_html_e( 'Search', 'manish-construction' ); ?></button>
		</form>

		<div class="mc-hero-actions" style="justify-content:center;">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="mc-btn mc-btn-dark"><?php esc_html_e( 'Back to Home', 'manish-construction' ); ?></a>
			<a href="<?php echo esc_url( get_post_type_archive_link( 'property' ) ); ?>" class="mc-btn mc-btn-outline" style="color:var(--mc-primary);border-color:var(--mc-primary);"><?php esc_html_e( 'Browse Properties', 'manish-construction' ); ?></a>
		</div>
	</div>
</section>

<?php get_footer(); ?>
