<?php
/**
 * The template for displaying comments.
 *
 * @package Manish_Construction
 */

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			$count = get_comments_number();
			/* translators: %s: number of comments */
			printf( esc_html( _n( '%s Comment', '%s Comments', $count, 'manish-construction' ) ), esc_html( number_format_i18n( $count ) ) );
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments( array(
				'style'      => 'ol',
				'short_ping' => true,
				'avatar_size'=> 48,
			) );
			?>
		</ol>

		<?php
		the_comments_pagination( array(
			'prev_text' => esc_html__( '&larr; Older Comments', 'manish-construction' ),
			'next_text' => esc_html__( 'Newer Comments &rarr;', 'manish-construction' ),
		) );
		?>

	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'manish-construction' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form( array(
		'class_submit' => 'mc-btn mc-btn-primary',
		'title_reply'  => esc_html__( 'Leave a Comment', 'manish-construction' ),
	) );
	?>

</div>
