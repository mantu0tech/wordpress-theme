/**
 * Manish Construction theme scripts
 * Mobile menu toggle, sticky header shadow, submenu handling on touch.
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {

		var header   = document.getElementById( 'masthead' );
		var toggle   = document.querySelector( '.mc-menu-toggle' );
		var nav      = document.getElementById( 'site-navigation' );

		// Mobile menu toggle.
		if ( toggle && nav ) {
			toggle.addEventListener( 'click', function () {
				var isOpen = nav.classList.toggle( 'is-open' );
				toggle.classList.toggle( 'is-active', isOpen );
				toggle.setAttribute( 'aria-expanded', isOpen ? 'true' : 'false' );
				document.body.style.overflow = isOpen ? 'hidden' : '';
			} );

			// Close menu when a link (without children) is clicked.
			nav.querySelectorAll( 'a' ).forEach( function ( link ) {
				link.addEventListener( 'click', function () {
					if ( window.innerWidth <= 782 ) {
						nav.classList.remove( 'is-open' );
						toggle.classList.remove( 'is-active' );
						toggle.setAttribute( 'aria-expanded', 'false' );
						document.body.style.overflow = '';
					}
				} );
			} );
		}

		// Toggle submenus on tap for touch devices.
		document.querySelectorAll( '.main-navigation .menu-item-has-children > a' ).forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				if ( window.innerWidth <= 782 ) {
					var parentLi = link.parentElement;
					var submenu  = parentLi.querySelector( '.sub-menu' );
					if ( submenu ) {
						e.preventDefault();
						submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
					}
				}
			} );
		} );

		// Sticky header shadow on scroll.
		if ( header ) {
			window.addEventListener( 'scroll', function () {
				if ( window.scrollY > 10 ) {
					header.classList.add( 'mc-scrolled' );
				} else {
					header.classList.remove( 'mc-scrolled' );
				}
			} );
		}

	} );

}() );
