<?php
/**
 * The template for displaying single posts and single properties.
 *
 * @package Manish_Construction
 */

get_header();
?>

<section class="mc-section">
	<div class="mc-container">

		<?php while ( have_posts() ) : the_post(); ?>

			<?php if ( 'property' === get_post_type() ) : ?>

				<!-- ================= SINGLE PROPERTY ================= -->
				<?php $meta = mc_get_property_meta( get_the_ID() ); ?>

				<?php if ( has_post_thumbnail() ) : ?>
					<div class="mc-property-hero">
						<?php the_post_thumbnail( 'mc-hero-large' ); ?>
					</div>
				<?php endif; ?>

				<div class="mc-property-header">
					<div>
						<h1>
							<?php the_title(); ?>
							<?php if ( $meta['status'] ) : ?><span class="mc-property-status"><?php echo esc_html( $meta['status'] ); ?></span><?php endif; ?>
						</h1>
						<?php if ( $meta['location'] ) : ?>
							<p class="mc-property-location">&#128205; <?php echo esc_html( $meta['location'] ); ?></p>
						<?php endif; ?>
					</div>
					<?php if ( $meta['price'] ) : ?>
						<div class="mc-property-price"><?php echo esc_html( $meta['price'] ); ?></div>
					<?php endif; ?>
				</div>

				<div class="mc-property-facts">
					<?php if ( $meta['bedrooms'] ) : ?><div class="mc-fact"><strong><?php echo esc_html( $meta['bedrooms'] ); ?></strong><span><?php esc_html_e( 'Bedrooms', 'manish-construction' ); ?></span></div><?php endif; ?>
					<?php if ( $meta['bathrooms'] ) : ?><div class="mc-fact"><strong><?php echo esc_html( $meta['bathrooms'] ); ?></strong><span><?php esc_html_e( 'Bathrooms', 'manish-construction' ); ?></span></div><?php endif; ?>
					<?php if ( $meta['area'] ) : ?><div class="mc-fact"><strong><?php echo esc_html( $meta['area'] ); ?></strong><span><?php esc_html_e( 'Sq Ft', 'manish-construction' ); ?></span></div><?php endif; ?>
					<?php if ( $meta['year_built'] ) : ?><div class="mc-fact"><strong><?php echo esc_html( $meta['year_built'] ); ?></strong><span><?php esc_html_e( 'Year Built', 'manish-construction' ); ?></span></div><?php endif; ?>
				</div>

				<div class="mc-content-layout">
					<div class="mc-property-content">
						<h2><?php esc_html_e( 'Description', 'manish-construction' ); ?></h2>
						<?php the_content(); ?>

						<?php
						$ptypes = get_the_terms( get_the_ID(), 'property_type' );
						if ( $ptypes && ! is_wp_error( $ptypes ) ) :
						?>
							<p class="mc-post-tags">
								<?php foreach ( $ptypes as $t ) : ?>
									<a href="<?php echo esc_url( get_term_link( $t ) ); ?>"><?php echo esc_html( $t->name ); ?></a>
								<?php endforeach; ?>
							</p>
						<?php endif; ?>
					</div>

					<aside class="mc-sidebar-box">
						<h3><?php esc_html_e( 'Interested in this property?', 'manish-construction' ); ?></h3>
						<?php if ( $meta['price'] ) : ?><div class="mc-contact-fact"><span><?php esc_html_e( 'Price', 'manish-construction' ); ?></span><strong><?php echo esc_html( $meta['price'] ); ?></strong></div><?php endif; ?>
						<?php if ( $meta['status'] ) : ?><div class="mc-contact-fact"><span><?php esc_html_e( 'Status', 'manish-construction' ); ?></span><strong><?php echo esc_html( $meta['status'] ); ?></strong></div><?php endif; ?>
						<?php if ( $meta['location'] ) : ?><div class="mc-contact-fact"><span><?php esc_html_e( 'Location', 'manish-construction' ); ?></span><strong><?php echo esc_html( $meta['location'] ); ?></strong></div><?php endif; ?>
						<a href="mailto:<?php echo esc_attr( mc_mod( 'mc_email', 'info@manishconstruction.com' ) ); ?>?subject=<?php echo esc_attr( rawurlencode( get_the_title() ) ); ?>" class="mc-btn mc-btn-primary"><?php esc_html_e( 'Email Us', 'manish-construction' ); ?></a>
						<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', mc_mod( 'mc_phone', '+15551234567' ) ) ); ?>" class="mc-btn mc-btn-dark"><?php esc_html_e( 'Call Now', 'manish-construction' ); ?></a>
					</aside>
				</div>

			<?php else : ?>

				<!-- ================= STANDARD SINGLE POST ================= -->
				<div class="single-post-content">

					<header style="margin-bottom:26px;">
						<?php
						$cats = get_the_category();
						if ( $cats ) :
						?>
							<span class="mc-eyebrow"><?php echo esc_html( $cats[0]->name ); ?></span>
						<?php endif; ?>
						<h1><?php the_title(); ?></h1>
						<p class="mc-post-meta">
							<?php echo esc_html( get_the_date() ); ?> &middot;
							<?php esc_html_e( 'by', 'manish-construction' ); ?> <?php the_author(); ?>
						</p>
					</header>

					<?php if ( has_post_thumbnail() ) : ?>
						<div class="mc-property-hero"><?php the_post_thumbnail( 'mc-hero-large' ); ?></div>
					<?php endif; ?>

					<?php the_content(); ?>

					<?php
					wp_link_pages( array(
						'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'manish-construction' ),
						'after'  => '</div>',
					) );
					?>

					<?php
					$tags = get_the_tags();
					if ( $tags ) :
					?>
						<p class="mc-post-tags">
							<?php foreach ( $tags as $tag ) : ?>
								<a href="<?php echo esc_url( get_tag_link( $tag ) ); ?>">#<?php echo esc_html( $tag->name ); ?></a>
							<?php endforeach; ?>
						</p>
					<?php endif; ?>

					<div class="mc-author-box">
						<?php echo get_avatar( get_the_author_meta( 'ID' ), 64 ); ?>
						<div>
							<strong><?php the_author(); ?></strong>
							<p style="margin:0;"><?php the_author_meta( 'description' ); ?></p>
						</div>
					</div>

				</div>

				<?php if ( comments_open() || get_comments_number() ) : ?>
					<?php comments_template(); ?>
				<?php endif; ?>

			<?php endif; ?>

		<?php endwhile; ?>

	</div>
</section>

<?php get_footer(); ?>
