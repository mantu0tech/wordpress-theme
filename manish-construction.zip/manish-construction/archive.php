<?php
/**
 * The template for displaying archive pages (properties, categories, tags, dates, custom taxonomies).
 *
 * @package Manish_Construction
 */

get_header();

$is_property_archive = is_post_type_archive( 'property' ) || is_tax( array( 'property_type', 'property_location' ) );
?>

<section class="mc-section">
	<div class="mc-container">

		<header class="mc-section-header">
			<span class="mc-eyebrow">
				<?php echo $is_property_archive ? esc_html__( 'Listings', 'manish-construction' ) : esc_html__( 'Archive', 'manish-construction' ); ?>
			</span>
			<h1><?php the_archive_title(); ?></h1>
			<?php if ( get_the_archive_description() ) : ?>
				<div><?php the_archive_description(); ?></div>
			<?php endif; ?>
		</header>

		<?php if ( have_posts() ) : ?>

			<?php if ( $is_property_archive ) : ?>

				<div class="mc-grid">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php mc_render_property_card(); ?>
					<?php endwhile; ?>
				</div>

			<?php else : ?>

				<div class="mc-post-list">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php mc_render_post_card(); ?>
					<?php endwhile; ?>
				</div>

			<?php endif; ?>

			<?php mc_pagination(); ?>

		<?php else : ?>

			<p style="text-align:center;"><?php esc_html_e( 'No content found in this archive.', 'manish-construction' ); ?></p>

		<?php endif; ?>

	</div>
</section>

<?php get_footer(); ?>
