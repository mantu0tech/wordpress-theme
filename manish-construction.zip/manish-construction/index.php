<?php
/**
 * The main template file.
 *
 * @package Manish_Construction
 */

get_header();
?>

<?php if ( is_front_page() && ! is_paged() ) : ?>
	<!-- ================= HERO ================= -->
	<section class="mc-hero">
		<div class="mc-container-hero mc-hero-inner">
			<span class="mc-hero-eyebrow"><?php esc_html_e( 'Trusted Real Estate & Construction', 'manish-construction' ); ?></span>
			<h1><?php echo esc_html( mc_mod( 'mc_hero_title', 'Building Your Future, One Property at a Time' ) ); ?></h1>
			<p><?php echo esc_html( mc_mod( 'mc_hero_text', 'Manish Construction delivers quality homes, commercial spaces, and construction services you can trust — from foundation to finish.' ) ); ?></p>
			<div class="mc-hero-actions">
				<a href="<?php echo esc_url( get_post_type_archive_link( 'property' ) ); ?>" class="mc-btn mc-btn-primary"><?php esc_html_e( 'Browse Properties', 'manish-construction' ); ?></a>
				<a href="#mc-contact" class="mc-btn mc-btn-outline"><?php esc_html_e( 'Contact Us', 'manish-construction' ); ?></a>
			</div>
		</div>
	</section>

	<div class="mc-container-hero">
		<div class="mc-search-widget">
			<form class="mc-search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<input type="hidden" name="post_type" value="property">
				<div class="field">
					<label for="mc-s"><?php esc_html_e( 'Keyword', 'manish-construction' ); ?></label>
					<input type="text" id="mc-s" name="s" placeholder="<?php esc_attr_e( 'Search properties&hellip;', 'manish-construction' ); ?>">
				</div>
				<div class="field">
					<label for="mc-type"><?php esc_html_e( 'Property Type', 'manish-construction' ); ?></label>
					<select id="mc-type" name="property_type">
						<option value=""><?php esc_html_e( 'Any Type', 'manish-construction' ); ?></option>
						<?php
						$types = get_terms( array( 'taxonomy' => 'property_type', 'hide_empty' => false ) );
						if ( ! is_wp_error( $types ) ) {
							foreach ( $types as $type ) {
								echo '<option value="' . esc_attr( $type->slug ) . '">' . esc_html( $type->name ) . '</option>';
							}
						}
						?>
					</select>
				</div>
				<button type="submit" class="mc-btn mc-btn-primary"><?php esc_html_e( 'Search', 'manish-construction' ); ?></button>
			</form>
		</div>
	</div>

	<!-- ================= FEATURED PROPERTIES ================= -->
	<section class="mc-section">
		<div class="mc-container">
			<div class="mc-section-header">
				<span class="mc-eyebrow"><?php esc_html_e( 'Featured Listings', 'manish-construction' ); ?></span>
				<h2><?php esc_html_e( 'Explore Our Latest Properties', 'manish-construction' ); ?></h2>
			</div>

			<?php
			$featured = new WP_Query( array(
				'post_type'      => 'property',
				'posts_per_page' => 6,
			) );
			?>

			<?php if ( $featured->have_posts() ) : ?>
				<div class="mc-grid">
					<?php while ( $featured->have_posts() ) : $featured->the_post(); ?>
						<?php mc_render_property_card(); ?>
					<?php endwhile; ?>
				</div>
				<div style="text-align:center;margin-top:40px;">
					<a href="<?php echo esc_url( get_post_type_archive_link( 'property' ) ); ?>" class="mc-btn mc-btn-dark"><?php esc_html_e( 'View All Properties', 'manish-construction' ); ?></a>
				</div>
			<?php else : ?>
				<p style="text-align:center;"><?php esc_html_e( 'No properties published yet — add some from the Properties menu in wp-admin.', 'manish-construction' ); ?></p>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>
		</div>
	</section>

	<!-- ================= WHY CHOOSE US ================= -->
	<section class="mc-section mc-section-alt">
		<div class="mc-container">
			<div class="mc-section-header">
				<span class="mc-eyebrow"><?php esc_html_e( 'Why Choose Us', 'manish-construction' ); ?></span>
				<h2><?php esc_html_e( 'Quality Construction, Honest Service', 'manish-construction' ); ?></h2>
			</div>
			<div class="mc-grid">
				<div class="mc-card"><div class="mc-card-body">
					<h3><?php esc_html_e( '20+ Years Experience', 'manish-construction' ); ?></h3>
					<p><?php esc_html_e( 'Decades of hands-on experience building residential and commercial properties.', 'manish-construction' ); ?></p>
				</div></div>
				<div class="mc-card"><div class="mc-card-body">
					<h3><?php esc_html_e( 'Licensed & Insured', 'manish-construction' ); ?></h3>
					<p><?php esc_html_e( 'Fully licensed contractors and comprehensive insurance for total peace of mind.', 'manish-construction' ); ?></p>
				</div></div>
				<div class="mc-card"><div class="mc-card-body">
					<h3><?php esc_html_e( 'On-Time, On-Budget', 'manish-construction' ); ?></h3>
					<p><?php esc_html_e( 'Transparent timelines and pricing so there are never any surprises.', 'manish-construction' ); ?></p>
				</div></div>
			</div>
		</div>
	</section>

	<!-- ================= LATEST NEWS ================= -->
	<?php
	$news = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 3 ) );
	if ( $news->have_posts() ) :
	?>
	<section class="mc-section">
		<div class="mc-container">
			<div class="mc-section-header">
				<span class="mc-eyebrow"><?php esc_html_e( 'From the Blog', 'manish-construction' ); ?></span>
				<h2><?php esc_html_e( 'News & Insights', 'manish-construction' ); ?></h2>
			</div>
			<div class="mc-grid">
				<?php while ( $news->have_posts() ) : $news->the_post(); ?>
					<article <?php post_class( 'mc-card' ); ?>>
						<a href="<?php the_permalink(); ?>" class="mc-card-thumb">
							<?php if ( has_post_thumbnail() ) the_post_thumbnail( 'mc-card' ); ?>
						</a>
						<div class="mc-card-body">
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<div><?php the_excerpt(); ?></div>
						</div>
					</article>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<!-- ================= CONTACT CTA ================= -->
	<section id="mc-contact" class="mc-section mc-section-alt">
		<div class="mc-container" style="text-align:center;">
			<div class="mc-section-header">
				<span class="mc-eyebrow"><?php esc_html_e( 'Get In Touch', 'manish-construction' ); ?></span>
				<h2><?php esc_html_e( 'Ready to Start Your Project?', 'manish-construction' ); ?></h2>
				<p><?php esc_html_e( 'Reach out today for a free consultation and quote.', 'manish-construction' ); ?></p>
			</div>
			<a href="mailto:<?php echo esc_attr( mc_mod( 'mc_email', 'info@manishconstruction.com' ) ); ?>" class="mc-btn mc-btn-primary"><?php esc_html_e( 'Email Us', 'manish-construction' ); ?></a>
		</div>
	</section>

<?php else : ?>

	<!-- ================= STANDARD BLOG LOOP ================= -->
	<section class="mc-section">
		<div class="mc-container">
			<?php if ( have_posts() ) : ?>
				<div class="mc-post-list">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php mc_render_post_card(); ?>
					<?php endwhile; ?>
				</div>
				<?php mc_pagination(); ?>
			<?php else : ?>
				<p><?php esc_html_e( 'Nothing found.', 'manish-construction' ); ?></p>
			<?php endif; ?>
		</div>
	</section>

<?php endif; ?>

<?php get_footer(); ?>
