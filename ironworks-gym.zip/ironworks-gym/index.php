<?php
/**
 * The main blog/fallback template.
 *
 * @package Ironworks_Gym
 */

get_header();
?>
<section class="section" style="padding-top:170px;">
	<div class="container">
		<div class="section-head center reveal" style="max-width:720px;">
			<span class="eyebrow"><?php esc_html_e( 'Gym Blog', 'ironworks-gym' ); ?></span>
			<h1><?php is_home() && ! is_front_page() ? single_post_title() : esc_html_e( 'Training Notes & News', 'ironworks-gym' ); ?></h1>
		</div>

		<div class="about-grid" style="grid-template-columns: 2fr 1fr;">
			<div>
				<?php if ( have_posts() ) : ?>
					<div class="post-grid" style="grid-template-columns:1fr;">
						<?php while ( have_posts() ) : the_post(); ?>
							<?php get_template_part( 'template-parts/content' ); ?>
						<?php endwhile; ?>
					</div>
					<?php iwg_pagination(); ?>
				<?php else : ?>
					<?php get_template_part( 'template-parts/content', 'none' ); ?>
				<?php endif; ?>
			</div>
			<div><?php get_sidebar(); ?></div>
		</div>
	</div>
</section>
<?php
get_footer();
