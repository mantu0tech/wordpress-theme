<?php
/**
 * The footer for the theme.
 *
 * @package Ironworks_Gym
 */

$phone = get_theme_mod( 'iwg_contact_phone', '' );
$email = get_theme_mod( 'iwg_contact_email', '' );
$addr  = get_theme_mod( 'iwg_contact_address', '' );
$city  = get_theme_mod( 'iwg_contact_city', '' );
$hours = get_theme_mod( 'iwg_contact_hours', '' );
$ig    = get_theme_mod( 'iwg_social_instagram', '' );
$fb    = get_theme_mod( 'iwg_social_facebook', '' );
$yt    = get_theme_mod( 'iwg_social_youtube', '' );
?>
</main><!-- #main-content -->

<footer class="site-footer">
	<div class="container">
		<div class="footer-grid">
			<div class="footer-brand">
				<?php if ( has_custom_logo() ) : ?>
					<?php the_custom_logo(); ?>
				<?php else : ?>
					<div class="brand-name">IRON<span>WORKS</span></div>
				<?php endif; ?>
				<p><?php echo esc_html( get_theme_mod( 'iwg_footer_about', '' ) ); ?></p>
				<div class="footer-social">
					<?php if ( $ig ) : ?><a href="<?php echo esc_url( $ig ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><?php echo iwg_icon( 'instagram' ); ?></a><?php endif; ?>
					<?php if ( $fb ) : ?><a href="<?php echo esc_url( $fb ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Facebook"><?php echo iwg_icon( 'facebook' ); ?></a><?php endif; ?>
					<?php if ( $yt ) : ?><a href="<?php echo esc_url( $yt ); ?>" target="_blank" rel="noopener noreferrer" aria-label="YouTube"><?php echo iwg_icon( 'youtube' ); ?></a><?php endif; ?>
				</div>
			</div>

			<div class="footer-col">
				<h4><?php esc_html_e( 'Explore', 'ironworks-gym' ); ?></h4>
				<?php if ( has_nav_menu( 'footer' ) ) : ?>
					<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'items_wrap' => '<ul>%3$s</ul>', 'depth' => 1 ) ); ?>
				<?php else : ?>
					<ul>
						<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'ironworks-gym' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>"><?php esc_html_e( 'About Us', 'ironworks-gym' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php esc_html_e( 'Services', 'ironworks-gym' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>"><?php esc_html_e( 'Contact Us', 'ironworks-gym' ); ?></a></li>
					</ul>
				<?php endif; ?>
			</div>

			<div class="footer-col">
				<h4><?php esc_html_e( 'Contact', 'ironworks-gym' ); ?></h4>
				<ul>
					<?php if ( $addr ) : ?><li><?php echo esc_html( $addr ); ?><?php echo $city ? ', ' . esc_html( $city ) : ''; ?></li><?php endif; ?>
					<?php if ( $phone ) : ?><li><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></li><?php endif; ?>
					<?php if ( $email ) : ?><li><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></li><?php endif; ?>
				</ul>
			</div>

			<div class="footer-col">
				<h4><?php esc_html_e( 'Hours', 'ironworks-gym' ); ?></h4>
				<ul>
					<?php foreach ( explode( "\n", $hours ) as $line ) : ?>
						<?php if ( trim( $line ) ) : ?><li><?php echo esc_html( trim( $line ) ); ?></li><?php endif; ?>
					<?php endforeach; ?>
				</ul>
				<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
					<?php dynamic_sidebar( 'footer-1' ); ?>
				<?php endif; ?>
			</div>
		</div>

		<div class="footer-bottom">
			<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'ironworks-gym' ); ?></span>
			<span><?php esc_html_e( 'Built on WordPress.', 'ironworks-gym' ); ?></span>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
