<?php
/**
 * Home — About teaser section.
 *
 * @package Ironworks_Gym
 */

$pillars = iwg_get_pillars();
$body    = get_theme_mod( 'iwg_about_body', '' );
$paras   = array_filter( array_map( 'trim', explode( "\n", $body ) ) );
?>
<section class="section" id="about">
	<div class="container">
		<div class="about-grid">
			<div class="about-copy reveal">
				<span class="eyebrow"><?php echo esc_html( get_theme_mod( 'iwg_about_eyebrow', 'Our Story' ) ); ?></span>
				<h2><?php echo esc_html( get_theme_mod( 'iwg_about_title', '' ) ); ?></h2>
				<?php foreach ( $paras as $p ) : ?>
					<p><?php echo esc_html( $p ); ?></p>
				<?php endforeach; ?>
				<p><a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>" class="btn btn--ghost btn--sm"><?php esc_html_e( 'More About Us', 'ironworks-gym' ); ?></a></p>
			</div>

			<div class="pillars reveal">
				<?php foreach ( $pillars as $i => $pillar ) : ?>
					<div class="pillar">
						<span class="index"><?php echo esc_html( str_pad( $i + 1, 2, '0', STR_PAD_LEFT ) ); ?></span>
						<div>
							<h4><?php echo esc_html( $pillar[0] ); ?></h4>
							<p><?php echo esc_html( $pillar[1] ); ?></p>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
