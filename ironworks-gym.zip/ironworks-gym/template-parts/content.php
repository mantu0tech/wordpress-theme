<?php
/**
 * Post card used in blog loops.
 *
 * @package Ironworks_Gym
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card reveal' ); ?> style="flex-direction:row; flex-wrap:wrap;">
	<?php if ( has_post_thumbnail() ) : ?>
		<a href="<?php the_permalink(); ?>" class="thumb" style="flex:0 0 280px; max-width:280px;">
			<?php the_post_thumbnail( 'iwg-card' ); ?>
		</a>
	<?php endif; ?>
	<div class="body" style="flex:1; min-width:240px;">
		<span class="date"><?php echo esc_html( get_the_date() ); ?></span>
		<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<p><?php the_excerpt(); ?></p>
		<a class="read-more" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read More', 'ironworks-gym' ); ?> &rarr;</a>
	</div>
</article>
