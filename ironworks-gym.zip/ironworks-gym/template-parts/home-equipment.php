<?php
/**
 * Home — Equipment showcase. Uses the theme's vector icon set by default;
 * if a real gym photo is set on the "Our Equipment" page (or a matching
 * attachment), swap it in via the Customizer > Equipment Showcase panel,
 * or simply add photos through custom fields — see readme.txt.
 *
 * @package Ironworks_Gym
 */

$equipment = iwg_get_equipment();
?>
<section class="section section--alt" id="equipment">
	<div class="container">
		<?php iwg_section_head( 'On The Floor', 'Real Equipment, Not A Photo Op', 'Every machine on our floor is here because it earns its space. Here\'s what you\'ll be training on.', true ); ?>

		<div class="card-grid">
			<?php foreach ( $equipment as $item ) : ?>
				<div class="program-card reveal">
					<div class="icon"><?php echo iwg_icon( $item[0] ); ?></div>
					<h3><?php echo esc_html( $item[1] ); ?></h3>
					<p><?php echo esc_html( $item[2] ); ?></p>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>
