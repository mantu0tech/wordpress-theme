<?php
/**
 * Home — Testimonials.
 *
 * @package Ironworks_Gym
 */

$testimonials = iwg_get_testimonials();
?>
<section class="section section--alt" id="testimonials">
	<div class="container">
		<?php iwg_section_head( 'Member Results', 'Real People. Real Numbers.', '', true ); ?>

		<?php if ( ! empty( $testimonials ) ) : ?>
			<div class="testimonial-grid">
				<?php foreach ( $testimonials as $t ) : ?>
					<div class="testimonial-card reveal">
						<span class="quote-mark">&ldquo;</span>
						<p class="quote"><?php echo esc_html( $t[0] ); ?></p>
						<div class="testimonial-author">
							<div class="initial-badge"><?php echo esc_html( iwg_initials( $t[1] ) ); ?></div>
							<div>
								<strong><?php echo esc_html( $t[1] ); ?></strong>
								<span><?php echo esc_html( $t[2] ); ?></span>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
