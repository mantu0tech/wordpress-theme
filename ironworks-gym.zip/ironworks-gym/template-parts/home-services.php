<?php
/**
 * Home — Services teaser (pulls live from the gym_service CPT so it's
 * fully dynamic and managed from wp-admin).
 *
 * @package Ironworks_Gym
 */

$services = new WP_Query( array(
	'post_type'      => 'gym_service',
	'posts_per_page' => 6,
	'orderby'        => 'menu_order date',
	'order'          => 'ASC',
) );
?>
<section class="section" id="services">
	<div class="container">
		<?php iwg_section_head( 'Programs', 'Train With A Plan', 'Every service below is coached, programmed, and built around real results — not just a room full of equipment.' ); ?>

		<?php if ( $services->have_posts() ) : ?>
			<div class="card-grid">
				<?php
				while ( $services->have_posts() ) :
					$services->the_post();
					$icon     = get_post_meta( get_the_ID(), '_service_icon', true );
					$price    = get_post_meta( get_the_ID(), '_service_price', true );
					$duration = get_post_meta( get_the_ID(), '_service_duration', true );
					?>
					<div class="program-card reveal">
						<div class="icon"><?php echo iwg_icon( $icon ? $icon : 'target' ); ?></div>
						<h3><?php the_title(); ?></h3>
						<?php if ( $price || $duration ) : ?>
							<span class="meta"><?php echo esc_html( $price ); ?><?php echo ( $price && $duration ) ? ' · ' : ''; ?><?php echo esc_html( $duration ); ?></span>
						<?php endif; ?>
						<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
						<a class="card-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Learn More', 'ironworks-gym' ); ?> <?php echo iwg_icon( 'arrow' ); ?></a>
					</div>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
			<p style="text-align:center; margin-top:46px;"><a href="<?php echo esc_url( get_post_type_archive_link( 'gym_service' ) ); ?>" class="btn btn--primary"><?php esc_html_e( 'View All Services', 'ironworks-gym' ); ?></a></p>
		<?php else : ?>
			<div class="empty-state"><p><?php esc_html_e( 'Services will appear here once added under Services in wp-admin.', 'ironworks-gym' ); ?></p></div>
		<?php endif; ?>
	</div>
</section>
