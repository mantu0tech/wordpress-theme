<?php
/**
 * Home — CTA band.
 *
 * @package Ironworks_Gym
 */
?>
<section class="cta-band">
	<div class="container">
		<h2><?php esc_html_e( 'Ready To Get Started?', 'ironworks-gym' ); ?></h2>
		<p><?php esc_html_e( 'Your first class is on us. Come see the floor, meet a coach, and find out what real training feels like.', 'ironworks-gym' ); ?></p>
		<div class="hero-actions" style="justify-content:center;">
			<a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>" class="btn btn--primary"><?php esc_html_e( 'Claim Free Trial', 'ironworks-gym' ); ?></a>
			<a href="<?php echo esc_url( home_url( '/services/' ) ); ?>" class="btn btn--ghost"><?php esc_html_e( 'Browse Programs', 'ironworks-gym' ); ?></a>
		</div>
	</div>
</section>
