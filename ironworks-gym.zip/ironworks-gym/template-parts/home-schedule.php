<?php
/**
 * Home — Weekly schedule.
 *
 * @package Ironworks_Gym
 */

$schedule = iwg_get_schedule();
?>
<section class="section section--alt" id="schedule">
	<div class="container">
		<?php iwg_section_head( 'This Week', 'Class Schedule', 'Drop into any class below — no sign-up required for members.' ); ?>

		<?php if ( ! empty( $schedule ) ) : ?>
			<div class="schedule-table-wrap reveal">
				<table class="schedule-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Day', 'ironworks-gym' ); ?></th>
							<th><?php esc_html_e( 'Time', 'ironworks-gym' ); ?></th>
							<th><?php esc_html_e( 'Class', 'ironworks-gym' ); ?></th>
							<th><?php esc_html_e( 'Coach', 'ironworks-gym' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $schedule as $row ) : ?>
							<tr>
								<td><?php echo esc_html( $row[0] ); ?></td>
								<td class="time"><?php echo esc_html( $row[1] ); ?></td>
								<td><?php echo esc_html( $row[2] ); ?></td>
								<td><?php echo esc_html( $row[3] ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>
	</div>
</section>
