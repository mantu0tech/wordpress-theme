<?php
/**
 * Shown when no posts are found.
 *
 * @package Ironworks_Gym
 */
?>
<div class="empty-state">
	<h3><?php esc_html_e( 'Nothing found', 'ironworks-gym' ); ?></h3>
	<p><?php esc_html_e( 'Try a different search.', 'ironworks-gym' ); ?></p>
	<?php get_search_form(); ?>
</div>
