<?php
/**
 * Home — Hero section.
 *
 * @package Ironworks_Gym
 */
?>
<section class="hero" id="home">
	<div class="container">
		<div class="hero-grid">
			<div class="hero-copy">
				<span class="eyebrow"><?php echo esc_html( get_theme_mod( 'iwg_hero_eyebrow', '' ) ); ?></span>
				<h1>
					<?php echo esc_html( get_theme_mod( 'iwg_hero_title_1', '' ) ); ?><br>
					<span class="accent"><?php echo esc_html( get_theme_mod( 'iwg_hero_title_2', '' ) ); ?></span>
				</h1>
				<p class="lede"><?php echo esc_html( get_theme_mod( 'iwg_hero_lede', '' ) ); ?></p>
				<div class="hero-actions">
					<a href="<?php echo esc_url( get_theme_mod( 'iwg_hero_cta_url', '#contact' ) ); ?>" class="btn btn--primary"><?php echo esc_html( get_theme_mod( 'iwg_hero_cta_text', 'Start Free Trial' ) ); ?></a>
					<a href="<?php echo esc_url( get_theme_mod( 'iwg_hero_cta2_url', '/services/' ) ); ?>" class="btn btn--ghost"><?php echo esc_html( get_theme_mod( 'iwg_hero_cta2_text', 'View Services' ) ); ?></a>
				</div>
				<div class="hero-stats">
					<div class="hero-stat">
						<div class="num"><?php echo esc_html( get_theme_mod( 'iwg_hero_stat1_num', '9' ) ); ?></div>
						<div class="label"><?php echo esc_html( get_theme_mod( 'iwg_hero_stat1_label', 'Years Open' ) ); ?></div>
					</div>
					<div class="hero-stat">
						<div class="num"><?php echo esc_html( get_theme_mod( 'iwg_hero_stat2_num', '800+' ) ); ?></div>
						<div class="label"><?php echo esc_html( get_theme_mod( 'iwg_hero_stat2_label', 'Active Members' ) ); ?></div>
					</div>
					<div class="hero-stat">
						<div class="num"><?php echo esc_html( get_theme_mod( 'iwg_hero_stat3_num', '20+' ) ); ?></div>
						<div class="label"><?php echo esc_html( get_theme_mod( 'iwg_hero_stat3_label', 'Weekly Classes' ) ); ?></div>
					</div>
				</div>
			</div>

			<div class="hero-panel">
				<h3><?php esc_html_e( "Today's Floor", 'ironworks-gym' ); ?></h3>
				<ul>
					<li><span class="dot"></span> <?php esc_html_e( '6 Power Racks — open now', 'ironworks-gym' ); ?></li>
					<li><span class="dot"></span> <?php esc_html_e( 'Rowing bank — open now', 'ironworks-gym' ); ?></li>
					<li><span class="dot"></span> <?php esc_html_e( 'HIIT Circuit — 5:30 PM', 'ironworks-gym' ); ?></li>
					<li><span class="dot"></span> <?php esc_html_e( 'Coach on floor — all hours', 'ironworks-gym' ); ?></li>
				</ul>
			</div>
		</div>
	</div>
</section>
<div class="hazard-divider" role="presentation"></div>
