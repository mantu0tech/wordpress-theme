<?php
/**
 * Home — Membership pricing.
 *
 * @package Ironworks_Gym
 */

$plans = iwg_get_pricing();
?>
<section class="section" id="membership">
	<div class="container">
		<?php iwg_section_head( 'Membership', 'Pick Your Plan', 'No long-term contracts. Cancel anytime.', true ); ?>

		<?php if ( ! empty( $plans ) ) : ?>
			<div class="pricing-grid">
				<?php foreach ( $plans as $plan ) :
					$name     = $plan[0];
					$price    = $plan[1];
					$period   = $plan[2];
					$featured = isset( $plan[3] ) && 'yes' === strtolower( trim( $plan[3] ) );
					$features = isset( $plan[4] ) ? array_map( 'trim', explode( ',', $plan[4] ) ) : array();
					?>
					<div class="price-card reveal<?php echo $featured ? ' is-featured' : ''; ?>">
						<h3><?php echo esc_html( $name ); ?></h3>
						<div class="price"><?php echo esc_html( $price ); ?> <span><?php echo esc_html( $period ); ?></span></div>
						<ul>
							<?php foreach ( $features as $feature ) : ?>
								<li><?php echo iwg_icon( 'check' ); ?> <span><?php echo esc_html( $feature ); ?></span></li>
							<?php endforeach; ?>
						</ul>
						<a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>" class="btn <?php echo $featured ? 'btn--primary' : 'btn--ghost'; ?>"><?php esc_html_e( 'Get Started', 'ironworks-gym' ); ?></a>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
