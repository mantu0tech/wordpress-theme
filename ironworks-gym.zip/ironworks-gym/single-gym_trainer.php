<?php
/**
 * Single Trainer template.
 *
 * @package Ironworks_Gym
 */

get_header();
?>
<section class="section" style="padding-top:170px;">
	<div class="container">
		<?php while ( have_posts() ) : the_post();
			$role = get_post_meta( get_the_ID(), '_trainer_role', true );
			$ig   = get_post_meta( get_the_ID(), '_trainer_instagram', true );
			$fb   = get_post_meta( get_the_ID(), '_trainer_facebook', true );
			?>
			<div class="about-grid">
				<div class="reveal">
					<div class="trainer-avatar" style="max-width:360px;">
						<?php if ( has_post_thumbnail() ) : ?>
							<?php the_post_thumbnail( 'iwg-avatar' ); ?>
						<?php else : ?>
							<span class="initials"><?php echo esc_html( iwg_initials( get_the_title() ) ); ?></span>
						<?php endif; ?>
					</div>
				</div>
				<div class="reveal">
					<p class="date"><a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>">&larr; <?php esc_html_e( 'Meet The Team', 'ironworks-gym' ); ?></a></p>
					<h1><?php the_title(); ?></h1>
					<?php if ( $role ) : ?><span class="eyebrow"><?php echo esc_html( $role ); ?></span><?php endif; ?>
					<div class="entry-content" style="margin-top:20px;"><?php the_content(); ?></div>
					<?php if ( $ig || $fb ) : ?>
						<div class="trainer-social" style="margin-top:24px;">
							<?php if ( $ig ) : ?><a href="<?php echo esc_url( $ig ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><?php echo iwg_icon( 'instagram' ); ?></a><?php endif; ?>
							<?php if ( $fb ) : ?><a href="<?php echo esc_url( $fb ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Facebook"><?php echo iwg_icon( 'facebook' ); ?></a><?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		<?php endwhile; ?>
	</div>
</section>
<?php
get_footer();
