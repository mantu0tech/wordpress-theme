<?php
/**
 * Single Service template.
 *
 * @package Ironworks_Gym
 */

get_header();
?>
<section class="section" style="padding-top:170px;">
	<div class="container">
		<?php while ( have_posts() ) : the_post();
			$icon     = get_post_meta( get_the_ID(), '_service_icon', true );
			$price    = get_post_meta( get_the_ID(), '_service_price', true );
			$duration = get_post_meta( get_the_ID(), '_service_duration', true );
			?>
			<div class="entry-header reveal">
				<p class="date"><a href="<?php echo esc_url( get_post_type_archive_link( 'gym_service' ) ); ?>">&larr; <?php esc_html_e( 'All Services', 'ironworks-gym' ); ?></a></p>
				<div class="icon" style="margin:0 auto 20px;"><?php echo iwg_icon( $icon ? $icon : 'target' ); ?></div>
				<h1><?php the_title(); ?></h1>
				<?php if ( $price || $duration ) : ?>
					<p class="lede" style="font-family:var(--font-mono); color:var(--hazard);"><?php echo esc_html( $price ); ?><?php echo ( $price && $duration ) ? ' · ' : ''; ?><?php echo esc_html( $duration ); ?></p>
				<?php endif; ?>
			</div>

			<?php if ( has_post_thumbnail() ) : ?>
				<div class="entry-thumb reveal"><?php the_post_thumbnail( 'iwg-hero' ); ?></div>
			<?php endif; ?>

			<div class="entry-content reveal">
				<?php the_content(); ?>
			</div>

			<div style="text-align:center; margin-top:56px;">
				<a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>" class="btn btn--primary"><?php esc_html_e( 'Get Started', 'ironworks-gym' ); ?></a>
			</div>
		<?php endwhile; ?>
	</div>
</section>
<?php
get_footer();
