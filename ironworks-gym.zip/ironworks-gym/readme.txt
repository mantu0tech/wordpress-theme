=== Ironworks Gym ===
A complete custom WordPress theme for gyms & strength clubs.
Requires at least: 5.9 | Requires PHP: 7.4 | License: GPLv2 or later

== What's Included ==

Core template files (as requested): style.css, functions.php, header.php,
footer.php, index.php, page.php, single.php — plus everything needed for
a real, working site: front-page.php (Home), template-about.php,
template-services.php, template-contact.php, single/archive templates for
Services & Trainers, 404.php, search.php, archive.php, comments.php,
sidebar.php, and the /inc/ and /template-parts/ support files.

== Installation ==

1. WP Admin → Appearance → Themes → Add New → Upload Theme → choose
   ironworks-gym.zip → Install → Activate.

2. Create your 4 pages (Pages → Add New) and assign templates under
   Page Attributes → Template:
   - "Home"        → leave as Default Template (front-page.php runs it automatically once set as homepage — step 3 below)
   - "About Us"    → Template: "About Us"
   - "Services"    → Template: "Services"
   - "Contact Us"  → Template: "Contact Us"

3. Go to Settings → Reading → "Your homepage displays" → Static Page →
   set Homepage to your "Home" page.

4. Go to Appearance → Menus, create a menu with Home / About Us / Services
   / Contact Us, and assign it to the "Primary Menu" location (a sensible
   fallback menu is already shown if you skip this step).

5. Go to Appearance → Customize to edit all homepage/about/contact copy:
   Homepage Hero, About Content, Equipment Showcase, Testimonials, Weekly
   Schedule, Membership Pricing, Contact & Location, Footer.

6. Add real content:
   - Services (wp-admin menu) — each has Price, Duration, an Icon picker,
     and a Featured Image field. Six sample services are pre-loaded.
   - Trainers (wp-admin menu) — each has Role, Instagram/Facebook links,
     bio (post content) and a Featured Image (photo). Four sample
     trainers are pre-loaded.
   - Upload your own logo under Customize → Site Identity.

== Adding Your Own Gym Photos ==

No photo files were provided when this theme was generated, so equipment
and trainer visuals default to a custom vector icon set that matches the
theme's design (dumbbell, barbell rack, treadmill, kettlebell, rower,
battle ropes, etc.) — the site looks complete out of the box.

To swap in your real photos:
- Trainers: open each Trainer in wp-admin → set a Featured Image → their
  real photo replaces the initials avatar automatically.
- Services: open each Service → set a Featured Image → it replaces the
  icon automatically on the Services page (homepage cards keep the icon
  for a consistent grid — this is intentional, but you can adjust in
  template-parts/home-services.php if you'd like photos there too).
- Equipment Showcase (About/Home section) currently uses icons only by
  design; if you'd like real machine photos there instead, that section
  can be swapped from icons to an image grid — ask your developer to
  update template-parts/home-equipment.php, or send us the photos and we
  can wire it up.

== Contact Form → Stored In WordPress ==

Every submission through the Contact Us page form is:
1. Saved to the WordPress database as a "Submission" (wp-admin → Submissions
   in the left menu) — visible with Name, Email, Phone, Subject, Message
   and received date/time as sortable admin columns.
2. Emailed to the address set in Customize → Contact & Location → "Send
   form notifications to" (defaults to your WordPress admin email).

Submissions are never public — the post type is admin-only. A hidden
honeypot field blocks basic spam bots without needing a CAPTCHA.

For reliable email delivery on most hosts, consider installing an SMTP
plugin (e.g. WP Mail SMTP) — but even without one, submissions are always
safely stored in the database regardless of email delivery.

== Design ==

Industrial / warehouse-gym aesthetic: near-black backgrounds, safety-
yellow accent, Anton display type + Work Sans body + Space Mono for
stats/schedule. Fully responsive from mobile through desktop. Motion
respects prefers-reduced-motion.

== Changelog ==

= 1.0.0 =
* Initial release.
