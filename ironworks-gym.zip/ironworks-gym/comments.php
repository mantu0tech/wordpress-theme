<?php
/**
 * Comments template.
 *
 * @package Ironworks_Gym
 */

if ( post_password_required() ) {
	return;
}
?>
<div class="comments-area">
	<?php if ( have_comments() ) : ?>
		<h3 style="margin-bottom:24px;"><?php comments_number( __( 'No Comments', 'ironworks-gym' ), __( '1 Comment', 'ironworks-gym' ), __( '% Comments', 'ironworks-gym' ) ); ?></h3>
		<ol class="comment-list">
			<?php wp_list_comments( array( 'style' => 'ol', 'short_ping' => true ) ); ?>
		</ol>
		<?php the_comments_pagination(); ?>
	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() ) : ?>
		<p><?php esc_html_e( 'Comments are closed.', 'ironworks-gym' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form( array(
		'class_submit' => 'btn btn--primary',
		'title_reply'  => __( 'Leave a Comment', 'ironworks-gym' ),
	) );
	?>
</div>
