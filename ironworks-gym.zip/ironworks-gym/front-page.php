<?php
/**
 * Homepage template.
 *
 * @package Ironworks_Gym
 */

get_header();
?>

<?php get_template_part( 'template-parts/home', 'hero' ); ?>
<?php get_template_part( 'template-parts/home', 'about' ); ?>
<?php get_template_part( 'template-parts/home', 'equipment' ); ?>
<?php get_template_part( 'template-parts/home', 'services' ); ?>
<?php get_template_part( 'template-parts/home', 'schedule' ); ?>
<?php get_template_part( 'template-parts/home', 'pricing' ); ?>
<?php get_template_part( 'template-parts/home', 'testimonials' ); ?>
<?php get_template_part( 'template-parts/home', 'cta' ); ?>

<?php
get_footer();
