/**
 * Ironworks Gym — theme interactions (vanilla JS, no dependencies).
 */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {

		/* ---------------------------------------------------------
		 * Mobile nav toggle
		 * --------------------------------------------------------- */
		var toggle = document.getElementById('navToggle');
		var nav = document.getElementById('primary-nav');

		if (toggle && nav) {
			toggle.addEventListener('click', function () {
				var isOpen = nav.classList.toggle('is-open');
				toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
			});

			// Close menu when a link inside it is clicked (mobile).
			nav.addEventListener('click', function (e) {
				if (e.target.tagName === 'A' && nav.classList.contains('is-open')) {
					nav.classList.remove('is-open');
					toggle.setAttribute('aria-expanded', 'false');
				}
			});
		}

		/* ---------------------------------------------------------
		 * Smooth scroll for same-page anchor links (e.g. #contact)
		 * --------------------------------------------------------- */
		document.querySelectorAll('a[href*="#"]').forEach(function (link) {
			var href = link.getAttribute('href');
			if (!href || href === '#') { return; }

			var hashIndex = href.indexOf('#');
			var path = href.substring(0, hashIndex);
			var hash = href.substring(hashIndex);

			var samePage = path === '' || path === window.location.pathname || path === window.location.href.split('#')[0];
			if (!samePage) { return; }

			var target = document.querySelector(hash);
			if (!target) { return; }

			link.addEventListener('click', function (e) {
				e.preventDefault();
				var headerOffset = 90;
				var top = target.getBoundingClientRect().top + window.pageYOffset - headerOffset;
				window.scrollTo({ top: top, behavior: 'smooth' });
			});
		});

		/* ---------------------------------------------------------
		 * Scroll reveal (IntersectionObserver, progressive enhancement)
		 * --------------------------------------------------------- */
		var revealEls = document.querySelectorAll('.reveal');
		if ('IntersectionObserver' in window && revealEls.length) {
			var observer = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) {
						entry.target.classList.add('is-visible');
						observer.unobserve(entry.target);
					}
				});
			}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

			revealEls.forEach(function (el) { observer.observe(el); });
		} else {
			revealEls.forEach(function (el) { el.classList.add('is-visible'); });
		}

		/* ---------------------------------------------------------
		 * AJAX contact form — stores submission in WordPress via
		 * admin-ajax.php (see inc/contact-form.php)
		 * --------------------------------------------------------- */
		var form = document.getElementById('iwgContactForm');
		var msgBox = document.getElementById('iwgFormMsg');

		if (form && typeof iwgData !== 'undefined') {
			form.addEventListener('submit', function (e) {
				e.preventDefault();

				var submitBtn = form.querySelector('button[type="submit"]');
				var originalText = submitBtn.textContent;
				submitBtn.disabled = true;
				submitBtn.textContent = 'Sending…';

				msgBox.className = 'form-msg';
				msgBox.textContent = '';

				var data = new FormData(form);
				data.append('action', 'iwg_contact_form');
				data.append('nonce', iwgData.nonce);

				fetch(iwgData.ajaxUrl, {
					method: 'POST',
					body: data,
					credentials: 'same-origin'
				})
					.then(function (res) { return res.json(); })
					.then(function (json) {
						if (json && json.success) {
							msgBox.classList.add('is-success');
							msgBox.textContent = json.data.message;
							form.reset();
						} else {
							msgBox.classList.add('is-error');
							msgBox.textContent = (json && json.data && json.data.message) || 'Something went wrong. Please try again.';
						}
					})
					.catch(function () {
						msgBox.classList.add('is-error');
						msgBox.textContent = 'Network error — please try again or call us directly.';
					})
					.finally(function () {
						submitBtn.disabled = false;
						submitBtn.textContent = originalText;
					});
			});
		}

		/* ---------------------------------------------------------
		 * Active nav-link highlight based on scroll position
		 * (only meaningful on the one-page homepage sections)
		 * --------------------------------------------------------- */
		var sections = document.querySelectorAll('main section[id]');
		var navLinks = document.querySelectorAll('.primary-nav a[href*="#"]');
		if (sections.length && navLinks.length && 'IntersectionObserver' in window) {
			var navObserver = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					if (entry.isIntersecting) {
						var id = entry.target.getAttribute('id');
						navLinks.forEach(function (link) {
							link.parentElement.classList.toggle('current-menu-item', link.getAttribute('href').indexOf('#' + id) !== -1);
						});
					}
				});
			}, { rootMargin: '-45% 0px -50% 0px' });

			sections.forEach(function (s) { navObserver.observe(s); });
		}

	});
})();
