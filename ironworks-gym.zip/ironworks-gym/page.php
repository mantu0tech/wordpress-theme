<?php
/**
 * Default page template — used for any Page not assigned a custom
 * Page Attributes template (About Us, Services, and Contact Us each use
 * their own dedicated templates: template-about.php, template-services.php,
 * template-contact.php).
 *
 * @package Ironworks_Gym
 */

get_header();
?>
<section class="section" style="padding-top:170px;">
	<div class="container">
		<?php while ( have_posts() ) : the_post(); ?>
			<div class="entry-header reveal">
				<h1><?php the_title(); ?></h1>
			</div>

			<?php if ( has_post_thumbnail() ) : ?>
				<div class="entry-thumb reveal"><?php the_post_thumbnail( 'iwg-hero' ); ?></div>
			<?php endif; ?>

			<div class="entry-content reveal">
				<?php the_content(); ?>
				<?php
				wp_link_pages( array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'ironworks-gym' ),
					'after'  => '</div>',
				) );
				?>
			</div>

			<?php if ( comments_open() || get_comments_number() ) : ?>
				<?php comments_template(); ?>
			<?php endif; ?>
		<?php endwhile; ?>
	</div>
</section>
<?php
get_footer();
