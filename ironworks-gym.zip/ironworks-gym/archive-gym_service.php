<?php
/**
 * Archive for all Services (fallback — the "Services" page template
 * covers the main navigation link, but this handles the CPT archive URL
 * directly too).
 *
 * @package Ironworks_Gym
 */

get_header();
?>
<section class="section" style="padding-top:170px;">
	<div class="container">
		<div class="section-head center reveal" style="max-width:720px;">
			<span class="eyebrow"><?php esc_html_e( 'What We Offer', 'ironworks-gym' ); ?></span>
			<h1><?php esc_html_e( 'Our Services', 'ironworks-gym' ); ?></h1>
		</div>

		<?php if ( have_posts() ) : ?>
			<div class="card-grid">
				<?php while ( have_posts() ) : the_post();
					$icon     = get_post_meta( get_the_ID(), '_service_icon', true );
					$price    = get_post_meta( get_the_ID(), '_service_price', true );
					$duration = get_post_meta( get_the_ID(), '_service_duration', true );
					?>
					<div class="program-card reveal">
						<div class="icon"><?php echo iwg_icon( $icon ? $icon : 'target' ); ?></div>
						<h3><?php the_title(); ?></h3>
						<?php if ( $price || $duration ) : ?>
							<span class="meta"><?php echo esc_html( $price ); ?><?php echo ( $price && $duration ) ? ' · ' : ''; ?><?php echo esc_html( $duration ); ?></span>
						<?php endif; ?>
						<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22 ) ); ?></p>
						<a class="card-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Learn More', 'ironworks-gym' ); ?> <?php echo iwg_icon( 'arrow' ); ?></a>
					</div>
				<?php endwhile; ?>
			</div>
		<?php else : ?>
			<div class="empty-state"><p><?php esc_html_e( 'No services found.', 'ironworks-gym' ); ?></p></div>
		<?php endif; ?>
	</div>
</section>
<?php get_footer();
