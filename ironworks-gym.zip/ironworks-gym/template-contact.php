<?php
/**
 * Template Name: Contact Us
 *
 * @package Ironworks_Gym
 */

get_header();

$addr  = get_theme_mod( 'iwg_contact_address', '' );
$city  = get_theme_mod( 'iwg_contact_city', '' );
$phone = get_theme_mod( 'iwg_contact_phone', '' );
$email = get_theme_mod( 'iwg_contact_email', '' );
$hours = get_theme_mod( 'iwg_contact_hours', '' );
$map   = get_theme_mod( 'iwg_contact_map_embed', '' );
?>

<section class="section" style="padding-top:170px;">
	<div class="container">
		<div class="section-head center reveal" style="max-width:720px;">
			<span class="eyebrow"><?php esc_html_e( 'Get In Touch', 'ironworks-gym' ); ?></span>
			<h1><?php the_title(); ?></h1>
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<?php if ( get_the_content() ) : the_content(); else : ?>
					<p><?php esc_html_e( 'Questions about membership, programming, or just want to see the floor first? Send us a message or stop by during open hours.', 'ironworks-gym' ); ?></p>
				<?php endif; ?>
			<?php endwhile; endif; ?>
		</div>

		<div class="contact-grid">
			<div class="reveal">
				<h3><?php esc_html_e( 'Visit Or Call', 'ironworks-gym' ); ?></h3>
				<div class="contact-info-list">
					<?php if ( $addr ) : ?>
						<div class="contact-info-item">
							<div class="icon"><?php echo iwg_icon( 'pin' ); ?></div>
							<div>
								<h4><?php esc_html_e( 'Address', 'ironworks-gym' ); ?></h4>
								<p><?php echo esc_html( $addr ); ?><?php echo $city ? '<br>' . esc_html( $city ) : ''; ?></p>
							</div>
						</div>
					<?php endif; ?>
					<?php if ( $phone ) : ?>
						<div class="contact-info-item">
							<div class="icon"><?php echo iwg_icon( 'phone' ); ?></div>
							<div>
								<h4><?php esc_html_e( 'Phone', 'ironworks-gym' ); ?></h4>
								<p><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></p>
							</div>
						</div>
					<?php endif; ?>
					<?php if ( $email ) : ?>
						<div class="contact-info-item">
							<div class="icon"><?php echo iwg_icon( 'mail' ); ?></div>
							<div>
								<h4><?php esc_html_e( 'Email', 'ironworks-gym' ); ?></h4>
								<p><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></p>
							</div>
						</div>
					<?php endif; ?>
					<?php if ( $hours ) : ?>
						<div class="contact-info-item">
							<div class="icon"><?php echo iwg_icon( 'clock' ); ?></div>
							<div>
								<h4><?php esc_html_e( 'Hours', 'ironworks-gym' ); ?></h4>
								<?php foreach ( explode( "\n", $hours ) as $line ) : ?>
									<?php if ( trim( $line ) ) : ?><p style="margin:0;"><?php echo esc_html( trim( $line ) ); ?></p><?php endif; ?>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endif; ?>
				</div>

				<?php if ( $map ) : ?>
					<div class="reveal" style="margin-top:30px; border-radius:4px; overflow:hidden; border:1px solid var(--concrete-line);">
						<iframe src="<?php echo esc_url( $map ); ?>" width="100%" height="280" style="border:0; display:block;" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="<?php esc_attr_e( 'Gym location map', 'ironworks-gym' ); ?>"></iframe>
					</div>
				<?php endif; ?>
			</div>

			<div class="contact-form-panel reveal">
				<h3><?php esc_html_e( 'Send A Message', 'ironworks-gym' ); ?></h3>
				<p style="margin-bottom:24px;"><?php esc_html_e( "Fill this out and it lands directly with our team — we'll reply within one business day.", 'ironworks-gym' ); ?></p>

				<div id="iwgFormMsg" class="form-msg" role="status" aria-live="polite"></div>

				<form id="iwgContactForm" novalidate>
					<div class="form-row-cols">
						<div class="form-row">
							<label for="iwg_name"><?php esc_html_e( 'Full Name', 'ironworks-gym' ); ?></label>
							<input type="text" id="iwg_name" name="name" required>
						</div>
						<div class="form-row">
							<label for="iwg_phone"><?php esc_html_e( 'Phone (optional)', 'ironworks-gym' ); ?></label>
							<input type="tel" id="iwg_phone" name="phone">
						</div>
					</div>
					<div class="form-row">
						<label for="iwg_email"><?php esc_html_e( 'Email', 'ironworks-gym' ); ?></label>
						<input type="email" id="iwg_email" name="email" required>
					</div>
					<div class="form-row">
						<label for="iwg_subject"><?php esc_html_e( 'Subject', 'ironworks-gym' ); ?></label>
						<select id="iwg_subject" name="subject">
							<option value="Membership Inquiry"><?php esc_html_e( 'Membership Inquiry', 'ironworks-gym' ); ?></option>
							<option value="Personal Training"><?php esc_html_e( 'Personal Training', 'ironworks-gym' ); ?></option>
							<option value="Class Schedule"><?php esc_html_e( 'Class Schedule', 'ironworks-gym' ); ?></option>
							<option value="General Question"><?php esc_html_e( 'General Question', 'ironworks-gym' ); ?></option>
						</select>
					</div>
					<div class="form-row">
						<label for="iwg_message"><?php esc_html_e( 'Message', 'ironworks-gym' ); ?></label>
						<textarea id="iwg_message" name="message" rows="5" required></textarea>
					</div>
					<!-- Honeypot — hidden from real visitors, catches simple bots -->
					<div style="position:absolute; left:-9999px;" aria-hidden="true">
						<label for="iwg_website">Website</label>
						<input type="text" id="iwg_website" name="website" tabindex="-1" autocomplete="off">
					</div>
					<button type="submit" class="btn btn--primary" style="width:100%;"><?php esc_html_e( 'Send Message', 'ironworks-gym' ); ?></button>
				</form>
			</div>
		</div>
	</div>
</section>

<?php
get_footer();
