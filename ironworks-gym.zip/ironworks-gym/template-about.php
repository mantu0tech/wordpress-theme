<?php
/**
 * Template Name: About Us
 *
 * @package Ironworks_Gym
 */

get_header();

$pillars   = iwg_get_pillars();
$body      = get_theme_mod( 'iwg_about_body', '' );
$paras     = array_filter( array_map( 'trim', explode( "\n", $body ) ) );
$equipment = iwg_get_equipment();

$trainers = new WP_Query( array(
	'post_type'      => 'gym_trainer',
	'posts_per_page' => -1,
	'orderby'        => 'menu_order date',
	'order'          => 'ASC',
) );
?>

<section class="section" style="padding-top:170px;">
	<div class="container">
		<div class="section-head center reveal" style="max-width:720px;">
			<span class="eyebrow"><?php echo esc_html( get_theme_mod( 'iwg_about_eyebrow', 'Our Story' ) ); ?></span>
			<h1><?php the_title(); ?></h1>
		</div>

		<div class="about-grid">
			<div class="about-copy reveal">
				<h2><?php echo esc_html( get_theme_mod( 'iwg_about_title', '' ) ); ?></h2>
				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<?php if ( get_the_content() ) : ?>
						<div class="entry-content" style="margin:0;"><?php the_content(); ?></div>
					<?php else : ?>
						<?php foreach ( $paras as $p ) : ?><p><?php echo esc_html( $p ); ?></p><?php endforeach; ?>
					<?php endif; ?>
				<?php endwhile; endif; ?>
			</div>

			<div class="pillars reveal">
				<?php foreach ( $pillars as $i => $pillar ) : ?>
					<div class="pillar">
						<span class="index"><?php echo esc_html( str_pad( $i + 1, 2, '0', STR_PAD_LEFT ) ); ?></span>
						<div>
							<h4><?php echo esc_html( $pillar[0] ); ?></h4>
							<p><?php echo esc_html( $pillar[1] ); ?></p>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>

<section class="section section--alt">
	<div class="container">
		<?php iwg_section_head( 'On The Floor', 'The Equipment We Train On', '', true ); ?>
		<div class="card-grid">
			<?php foreach ( $equipment as $item ) : ?>
				<div class="program-card reveal">
					<div class="icon"><?php echo iwg_icon( $item[0] ); ?></div>
					<h3><?php echo esc_html( $item[1] ); ?></h3>
					<p><?php echo esc_html( $item[2] ); ?></p>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section">
	<div class="container">
		<?php iwg_section_head( 'Coaching Staff', 'Meet The Team', 'The coaches who write your programs and watch your form — not app algorithms.', true ); ?>

		<?php if ( $trainers->have_posts() ) : ?>
			<div class="trainer-grid">
				<?php while ( $trainers->have_posts() ) : $trainers->the_post();
					$role = get_post_meta( get_the_ID(), '_trainer_role', true );
					$ig   = get_post_meta( get_the_ID(), '_trainer_instagram', true );
					$fb   = get_post_meta( get_the_ID(), '_trainer_facebook', true );
					?>
					<div class="trainer-card reveal">
						<div class="trainer-avatar">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'iwg-avatar' ); ?>
							<?php else : ?>
								<span class="initials"><?php echo esc_html( iwg_initials( get_the_title() ) ); ?></span>
							<?php endif; ?>
						</div>
						<h4><?php the_title(); ?></h4>
						<?php if ( $role ) : ?><span class="role"><?php echo esc_html( $role ); ?></span><?php endif; ?>
						<p><?php echo esc_html( wp_trim_words( get_the_content(), 18 ) ); ?></p>
						<?php if ( $ig || $fb ) : ?>
							<div class="trainer-social">
								<?php if ( $ig ) : ?><a href="<?php echo esc_url( $ig ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><?php echo iwg_icon( 'instagram' ); ?></a><?php endif; ?>
								<?php if ( $fb ) : ?><a href="<?php echo esc_url( $fb ); ?>" target="_blank" rel="noopener noreferrer" aria-label="Facebook"><?php echo iwg_icon( 'facebook' ); ?></a><?php endif; ?>
							</div>
						<?php endif; ?>
					</div>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		<?php else : ?>
			<div class="empty-state"><p><?php esc_html_e( 'Trainers will appear here once added under Trainers in wp-admin.', 'ironworks-gym' ); ?></p></div>
		<?php endif; ?>
	</div>
</section>

<?php get_template_part( 'template-parts/home', 'cta' ); ?>

<?php
get_footer();
