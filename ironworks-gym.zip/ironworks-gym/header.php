<?php
/**
 * The header for the theme.
 *
 * @package Ironworks_Gym
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php if ( is_front_page() ) : ?>
		<meta name="description" content="<?php echo esc_attr( get_bloginfo( 'description' ) ? get_bloginfo( 'description' ) : 'A strength club built on real equipment and real coaching.' ); ?>">
	<?php endif; ?>
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#main-content"><?php esc_html_e( 'Skip to content', 'ironworks-gym' ); ?></a>

<header class="site-header">
	<div class="container">
		<div class="site-branding">
			<?php if ( has_custom_logo() ) : ?>
				<?php the_custom_logo(); ?>
			<?php else : ?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand-name" rel="home">
					IRON<span>WORKS</span>
				</a>
			<?php endif; ?>
		</div>

		<nav class="primary-nav" id="primary-nav" aria-label="<?php esc_attr_e( 'Primary', 'ironworks-gym' ); ?>">
			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu( array(
					'theme_location' => 'primary',
					'container'      => false,
					'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s</ul>',
					'walker'         => new Ironworks_Nav_Walker(),
				) );
			} else {
				iwg_fallback_menu();
			}
			?>
		</nav>

		<div class="header-cta">
			<a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>" class="btn btn--primary btn--sm btn--sm-desktop"><?php esc_html_e( 'Join Now', 'ironworks-gym' ); ?></a>
			<button class="nav-toggle" id="navToggle" aria-expanded="false" aria-controls="primary-nav" aria-label="<?php esc_attr_e( 'Toggle menu', 'ironworks-gym' ); ?>">
				<span></span><span></span><span></span>
			</button>
		</div>
	</div>
</header>

<main id="main-content">
