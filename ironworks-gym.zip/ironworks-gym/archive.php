<?php
/**
 * Generic archive template (categories, tags, dates, authors).
 *
 * @package Ironworks_Gym
 */

get_header();
?>
<section class="section" style="padding-top:170px;">
	<div class="container">
		<div class="section-head center reveal" style="max-width:720px;">
			<h1><?php the_archive_title(); ?></h1>
			<?php the_archive_description( '<p>', '</p>' ); ?>
		</div>
		<div class="about-grid" style="grid-template-columns: 2fr 1fr;">
			<div>
				<?php if ( have_posts() ) : ?>
					<div class="post-grid" style="grid-template-columns:1fr;">
						<?php while ( have_posts() ) : the_post(); ?>
							<?php get_template_part( 'template-parts/content' ); ?>
						<?php endwhile; ?>
					</div>
					<?php iwg_pagination(); ?>
				<?php else : ?>
					<?php get_template_part( 'template-parts/content', 'none' ); ?>
				<?php endif; ?>
			</div>
			<div><?php get_sidebar(); ?></div>
		</div>
	</div>
</section>
<?php
get_footer();
