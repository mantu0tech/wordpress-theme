<?php
/**
 * Contact form handling. Every valid submission is saved as a
 * "gym_submission" post (visible under Submissions in wp-admin) AND an
 * email notification is sent, so the gym owner never misses a lead even
 * if they only check email.
 *
 * @package Ironworks_Gym
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwg_handle_contact_form() {
	check_ajax_referer( 'iwg_contact_nonce', 'nonce' );

	// Honeypot spam trap — real users never fill this hidden field in.
	if ( ! empty( $_POST['website'] ) ) {
		wp_send_json_success( array( 'message' => __( 'Thanks! We\'ll be in touch shortly.', 'ironworks-gym' ) ) );
	}

	$name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$subject = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	if ( empty( $name ) || empty( $email ) || ! is_email( $email ) || empty( $message ) ) {
		wp_send_json_error( array( 'message' => __( 'Please fill in your name, a valid email, and a message.', 'ironworks-gym' ) ) );
	}

	// 1. Store in the WordPress database as a gym_submission post.
	$post_id = wp_insert_post( array(
		'post_type'   => 'gym_submission',
		'post_title'  => sprintf( '%s — %s', $name, $subject ? $subject : __( 'Contact form', 'ironworks-gym' ) ),
		'post_status' => 'publish',
	) );

	if ( ! $post_id || is_wp_error( $post_id ) ) {
		wp_send_json_error( array( 'message' => __( 'Something went wrong saving your message. Please try again or call us directly.', 'ironworks-gym' ) ) );
	}

	update_post_meta( $post_id, '_submission_name', $name );
	update_post_meta( $post_id, '_submission_email', $email );
	update_post_meta( $post_id, '_submission_phone', $phone );
	update_post_meta( $post_id, '_submission_subject', $subject );
	update_post_meta( $post_id, '_submission_message', $message );
	update_post_meta( $post_id, '_submission_date', current_time( 'mysql' ) );
	update_post_meta( $post_id, '_submission_ip', isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' );

	// 2. Email notification (best-effort — storage above already succeeded).
	$to      = get_theme_mod( 'iwg_notify_email', get_option( 'admin_email' ) );
	$subj    = sprintf( '[%s] New contact form message from %s', get_bloginfo( 'name' ), $name );
	$body    = "New contact form submission:\n\n";
	$body   .= "Name: {$name}\nEmail: {$email}\n";
	$body   .= $phone ? "Phone: {$phone}\n" : '';
	$body   .= $subject ? "Subject: {$subject}\n" : '';
	$body   .= "\nMessage:\n{$message}\n\n";
	$body   .= 'View in wp-admin: ' . admin_url( 'post.php?post=' . $post_id . '&action=edit' );
	$headers = array( 'Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $name . ' <' . $email . '>' );

	wp_mail( $to, $subj, $body, $headers );

	wp_send_json_success( array( 'message' => __( 'Thanks! Your message has been received — we\'ll get back to you shortly.', 'ironworks-gym' ) ) );
}
add_action( 'wp_ajax_iwg_contact_form', 'iwg_handle_contact_form' );
add_action( 'wp_ajax_nopriv_iwg_contact_form', 'iwg_handle_contact_form' );
