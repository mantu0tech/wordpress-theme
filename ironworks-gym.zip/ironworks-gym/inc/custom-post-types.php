<?php
/**
 * Custom Post Types
 * - gym_service: services offered (Services page)
 * - gym_trainer: coaching staff (About page)
 * - gym_submission: stored contact-form entries (admin-only, not public)
 *
 * @package Ironworks_Gym
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwg_register_post_types() {

	/* ---------------------------------------------------------
	 * SERVICES
	 * --------------------------------------------------------- */
	register_post_type( 'gym_service', array(
		'labels' => array(
			'name'               => __( 'Services', 'ironworks-gym' ),
			'singular_name'      => __( 'Service', 'ironworks-gym' ),
			'add_new_item'       => __( 'Add New Service', 'ironworks-gym' ),
			'edit_item'          => __( 'Edit Service', 'ironworks-gym' ),
			'all_items'          => __( 'All Services', 'ironworks-gym' ),
			'search_items'       => __( 'Search Services', 'ironworks-gym' ),
			'not_found'          => __( 'No services found', 'ironworks-gym' ),
			'featured_image'     => __( 'Service Image', 'ironworks-gym' ),
		),
		'public'       => true,
		'menu_icon'    => 'dashicons-universal-access-alt',
		'menu_position'=> 5,
		'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
		'has_archive'  => 'services',
		'rewrite'      => array( 'slug' => 'services', 'with_front' => false ),
		'show_in_rest' => true,
	) );

	/* ---------------------------------------------------------
	 * TRAINERS
	 * --------------------------------------------------------- */
	register_post_type( 'gym_trainer', array(
		'labels' => array(
			'name'           => __( 'Trainers', 'ironworks-gym' ),
			'singular_name'  => __( 'Trainer', 'ironworks-gym' ),
			'add_new_item'   => __( 'Add New Trainer', 'ironworks-gym' ),
			'edit_item'      => __( 'Edit Trainer', 'ironworks-gym' ),
			'all_items'      => __( 'All Trainers', 'ironworks-gym' ),
			'not_found'      => __( 'No trainers found', 'ironworks-gym' ),
			'featured_image' => __( 'Trainer Photo', 'ironworks-gym' ),
		),
		'public'       => true,
		'menu_icon'    => 'dashicons-groups',
		'menu_position'=> 6,
		'supports'     => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		'has_archive'  => false,
		'rewrite'      => array( 'slug' => 'trainers' ),
		'show_in_rest' => true,
	) );

	/* ---------------------------------------------------------
	 * CONTACT SUBMISSIONS (private, admin-only)
	 * --------------------------------------------------------- */
	register_post_type( 'gym_submission', array(
		'labels' => array(
			'name'          => __( 'Form Submissions', 'ironworks-gym' ),
			'singular_name' => __( 'Submission', 'ironworks-gym' ),
			'all_items'     => __( 'Submissions', 'ironworks-gym' ),
			'search_items'  => __( 'Search Submissions', 'ironworks-gym' ),
			'not_found'     => __( 'No submissions yet', 'ironworks-gym' ),
			'view_item'     => __( 'View Submission', 'ironworks-gym' ),
		),
		'public'              => false,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_icon'           => 'dashicons-email-alt',
		'menu_position'       => 25,
		'capability_type'     => 'page',
		'capabilities'        => array(
			'create_posts' => 'do_not_allow', // Entries are only ever created programmatically.
		),
		'map_meta_cap'        => true,
		'supports'            => array( 'title' ),
		'has_archive'         => false,
		'exclude_from_search' => true,
		'show_in_rest'        => false,
	) );
}
add_action( 'init', 'iwg_register_post_types' );

/**
 * Meta boxes: Service (price, duration) and Trainer (role, socials).
 */
function iwg_add_meta_boxes() {
	add_meta_box( 'iwg_service_details', __( 'Service Details', 'ironworks-gym' ), 'iwg_service_details_cb', 'gym_service', 'normal', 'high' );
	add_meta_box( 'iwg_trainer_details', __( 'Trainer Details', 'ironworks-gym' ), 'iwg_trainer_details_cb', 'gym_trainer', 'normal', 'high' );
	add_meta_box( 'iwg_submission_details', __( 'Submitted Details', 'ironworks-gym' ), 'iwg_submission_details_cb', 'gym_submission', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'iwg_add_meta_boxes' );

function iwg_service_details_cb( $post ) {
	wp_nonce_field( 'iwg_save_service', 'iwg_service_nonce' );
	$price    = get_post_meta( $post->ID, '_service_price', true );
	$duration = get_post_meta( $post->ID, '_service_duration', true );
	$icon     = get_post_meta( $post->ID, '_service_icon', true );
	$icons    = iwg_icon_choices();
	?>
	<p>
		<label><strong><?php esc_html_e( 'Price (e.g. $49/mo or leave blank)', 'ironworks-gym' ); ?></strong></label><br>
		<input type="text" name="service_price" class="widefat" value="<?php echo esc_attr( $price ); ?>">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Duration / Frequency (e.g. 45 min sessions)', 'ironworks-gym' ); ?></strong></label><br>
		<input type="text" name="service_duration" class="widefat" value="<?php echo esc_attr( $duration ); ?>">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Icon', 'ironworks-gym' ); ?></strong></label><br>
		<select name="service_icon" class="widefat">
			<?php foreach ( $icons as $key => $label ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $icon, $key ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<?php
}

function iwg_trainer_details_cb( $post ) {
	wp_nonce_field( 'iwg_save_trainer', 'iwg_trainer_nonce' );
	$role      = get_post_meta( $post->ID, '_trainer_role', true );
	$instagram = get_post_meta( $post->ID, '_trainer_instagram', true );
	$facebook  = get_post_meta( $post->ID, '_trainer_facebook', true );
	?>
	<p>
		<label><strong><?php esc_html_e( 'Role / Specialty', 'ironworks-gym' ); ?></strong></label><br>
		<input type="text" name="trainer_role" class="widefat" value="<?php echo esc_attr( $role ); ?>" placeholder="Head Strength Coach">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Instagram URL', 'ironworks-gym' ); ?></strong></label><br>
		<input type="url" name="trainer_instagram" class="widefat" value="<?php echo esc_attr( $instagram ); ?>">
	</p>
	<p>
		<label><strong><?php esc_html_e( 'Facebook URL', 'ironworks-gym' ); ?></strong></label><br>
		<input type="url" name="trainer_facebook" class="widefat" value="<?php echo esc_attr( $facebook ); ?>">
	</p>
	<?php
}

function iwg_submission_details_cb( $post ) {
	$fields = array(
		'_submission_name'    => __( 'Name', 'ironworks-gym' ),
		'_submission_email'   => __( 'Email', 'ironworks-gym' ),
		'_submission_phone'   => __( 'Phone', 'ironworks-gym' ),
		'_submission_subject' => __( 'Subject', 'ironworks-gym' ),
		'_submission_message' => __( 'Message', 'ironworks-gym' ),
		'_submission_date'    => __( 'Submitted', 'ironworks-gym' ),
	);
	echo '<table class="form-table">';
	foreach ( $fields as $key => $label ) {
		$value = get_post_meta( $post->ID, $key, true );
		printf(
			'<tr><th style="width:140px;">%1$s</th><td>%2$s</td></tr>',
			esc_html( $label ),
			'_submission_message' === $key ? nl2br( esc_html( $value ) ) : esc_html( $value )
		);
	}
	echo '</table>';
}

function iwg_save_meta_boxes( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( isset( $_POST['iwg_service_nonce'] ) && wp_verify_nonce( $_POST['iwg_service_nonce'], 'iwg_save_service' ) ) {
		if ( isset( $_POST['service_price'] ) ) {
			update_post_meta( $post_id, '_service_price', sanitize_text_field( wp_unslash( $_POST['service_price'] ) ) );
		}
		if ( isset( $_POST['service_duration'] ) ) {
			update_post_meta( $post_id, '_service_duration', sanitize_text_field( wp_unslash( $_POST['service_duration'] ) ) );
		}
		if ( isset( $_POST['service_icon'] ) ) {
			update_post_meta( $post_id, '_service_icon', sanitize_key( wp_unslash( $_POST['service_icon'] ) ) );
		}
	}

	if ( isset( $_POST['iwg_trainer_nonce'] ) && wp_verify_nonce( $_POST['iwg_trainer_nonce'], 'iwg_save_trainer' ) ) {
		if ( isset( $_POST['trainer_role'] ) ) {
			update_post_meta( $post_id, '_trainer_role', sanitize_text_field( wp_unslash( $_POST['trainer_role'] ) ) );
		}
		if ( isset( $_POST['trainer_instagram'] ) ) {
			update_post_meta( $post_id, '_trainer_instagram', esc_url_raw( wp_unslash( $_POST['trainer_instagram'] ) ) );
		}
		if ( isset( $_POST['trainer_facebook'] ) ) {
			update_post_meta( $post_id, '_trainer_facebook', esc_url_raw( wp_unslash( $_POST['trainer_facebook'] ) ) );
		}
	}
}
add_action( 'save_post', 'iwg_save_meta_boxes' );

/**
 * Available icon keys for the Service icon select + generic icon helper.
 */
function iwg_icon_choices() {
	return array(
		'dumbbell'  => __( 'Dumbbell', 'ironworks-gym' ),
		'barbell'   => __( 'Barbell / Rack', 'ironworks-gym' ),
		'treadmill' => __( 'Treadmill', 'ironworks-gym' ),
		'kettlebell'=> __( 'Kettlebell', 'ironworks-gym' ),
		'rower'     => __( 'Rowing Machine', 'ironworks-gym' ),
		'ropes'     => __( 'Battle Ropes', 'ironworks-gym' ),
		'heart'     => __( 'Heart / Cardio', 'ironworks-gym' ),
		'target'    => __( 'Target / Goals', 'ironworks-gym' ),
		'trophy'    => __( 'Trophy', 'ironworks-gym' ),
		'users'     => __( 'Group / Community', 'ironworks-gym' ),
		'clock'     => __( 'Clock', 'ironworks-gym' ),
	);
}

/**
 * Sample content seeded once on first activation so the site isn't empty.
 */
function iwg_seed_sample_content() {
	if ( get_option( 'iwg_sample_seeded' ) ) {
		return;
	}

	$services = array(
		array( 'title' => 'Strength & Conditioning', 'icon' => 'barbell', 'price' => '$59/mo', 'duration' => '60 min sessions', 'desc' => 'Progressive barbell programming built around squat, bench, deadlift and press — coached, not guessed.' ),
		array( 'title' => 'HIIT Circuits', 'icon' => 'heart', 'price' => '$49/mo', 'duration' => '30-45 min sessions', 'desc' => 'High-output interval circuits mixing kettlebells, sleds and bodyweight work to build conditioning fast.' ),
		array( 'title' => 'Personal Training', 'icon' => 'target', 'price' => 'From $75/session', 'duration' => '1-on-1, flexible', 'desc' => 'One-on-one coaching with a programmed plan, form correction and accountability check-ins.' ),
		array( 'title' => 'Group Rowing & Cardio', 'icon' => 'rower', 'price' => '$39/mo', 'duration' => '45 min sessions', 'desc' => 'Rowing-machine intervals and cardio circuits designed for engine-building, scaled to any level.' ),
		array( 'title' => 'Mobility & Recovery', 'icon' => 'clock', 'price' => '$29/mo', 'duration' => '40 min sessions', 'desc' => 'Guided mobility drills and recovery protocols to keep you training pain-free, week after week.' ),
		array( 'title' => 'Team & Corporate Training', 'icon' => 'users', 'price' => 'Custom quote', 'duration' => 'Scheduled sessions', 'desc' => 'Group programming for teams and workplaces — built around your group\'s goals and schedule.' ),
	);

	foreach ( $services as $s ) {
		$id = wp_insert_post( array(
			'post_type'    => 'gym_service',
			'post_title'   => $s['title'],
			'post_content' => $s['desc'],
			'post_excerpt' => $s['desc'],
			'post_status'  => 'publish',
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_service_icon', $s['icon'] );
			update_post_meta( $id, '_service_price', $s['price'] );
			update_post_meta( $id, '_service_duration', $s['duration'] );
		}
	}

	$trainers = array(
		array( 'name' => 'Marcus Reyes', 'role' => 'Head Strength Coach', 'bio' => 'Fifteen years coaching raw powerlifting and general strength — Marcus builds programs around your actual life, not a template.' ),
		array( 'name' => 'Dana Whitfield', 'role' => 'HIIT & Conditioning Coach', 'bio' => 'Former collegiate rower turned conditioning coach, Dana runs the circuit and rowing programming with relentless energy.' ),
		array( 'name' => 'Theo Okafor', 'role' => 'Personal Trainer', 'bio' => 'Theo specializes in one-on-one coaching for people returning to training after injury or a long break.' ),
		array( 'name' => 'Priya Nair', 'role' => 'Mobility & Recovery Coach', 'bio' => 'A certified physiotherapist by training, Priya keeps the whole gym moving well and staying injury-free.' ),
	);

	foreach ( $trainers as $t ) {
		$id = wp_insert_post( array(
			'post_type'    => 'gym_trainer',
			'post_title'   => $t['name'],
			'post_content' => $t['bio'],
			'post_status'  => 'publish',
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_trainer_role', $t['role'] );
		}
	}

	update_option( 'iwg_sample_seeded', 1 );
}
add_action( 'after_switch_theme', 'iwg_seed_sample_content' );
