<?php
/**
 * Template helper functions, including the inline SVG icon library used
 * throughout the theme (gym equipment icons + UI icons) so the site works
 * beautifully even before real photos are uploaded.
 *
 * @package Ironworks_Gym
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Parse a "field | field | field" per-line textarea setting into an array
 * of trimmed arrays.
 */
function iwg_parse_repeater( $raw, $min_parts = 2 ) {
	$rows = array();
	$raw  = trim( (string) $raw );
	if ( '' === $raw ) {
		return $rows;
	}
	foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = array_map( 'trim', explode( '|', $line ) );
		if ( count( $parts ) < $min_parts ) {
			continue;
		}
		$rows[] = $parts;
	}
	return $rows;
}

function iwg_get_pillars() {
	return iwg_parse_repeater( get_theme_mod( 'iwg_about_pillars', '' ), 2 );
}
function iwg_get_equipment() {
	return iwg_parse_repeater( get_theme_mod( 'iwg_equipment_list', '' ), 3 );
}
function iwg_get_testimonials() {
	return iwg_parse_repeater( get_theme_mod( 'iwg_testimonials_list', '' ), 3 );
}
function iwg_get_schedule() {
	return iwg_parse_repeater( get_theme_mod( 'iwg_schedule_list', '' ), 4 );
}
function iwg_get_pricing() {
	return iwg_parse_repeater( get_theme_mod( 'iwg_pricing_list', '' ), 5 );
}

/**
 * Section heading markup used repeatedly across templates.
 */
function iwg_section_head( $eyebrow, $title, $desc = '', $center = false ) {
	?>
	<div class="section-head reveal<?php echo $center ? ' center' : ''; ?>">
		<?php if ( $eyebrow ) : ?><span class="eyebrow"><?php echo esc_html( $eyebrow ); ?></span><?php endif; ?>
		<h2><?php echo esc_html( $title ); ?></h2>
		<?php if ( $desc ) : ?><p><?php echo esc_html( $desc ); ?></p><?php endif; ?>
	</div>
	<?php
}

function iwg_pagination() {
	the_posts_pagination( array(
		'mid_size'  => 1,
		'prev_text' => __( '&larr; Previous', 'ironworks-gym' ),
		'next_text' => __( 'Next &rarr;', 'ironworks-gym' ),
		'class'     => 'pagination',
	) );
}

/**
 * Inline SVG icon library. Centralized so every icon shares the same
 * stroke weight/viewbox and can be recolored purely with CSS (currentColor).
 *
 * @param string $name  Icon key.
 * @param string $class Extra CSS classes on the <svg>.
 * @return string SVG markup (escaped-safe, contains no user input).
 */
function iwg_icon( $name, $class = '' ) {
	$icons = array(
		'dumbbell'   => '<path d="M4 9v6M2 10.5v3M22 9v6M20 10.5v3M8 12h8M6 8v8a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1zM16 8v8a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1h-1a1 1 0 0 0-1 1z"/>',
		'barbell'    => '<path d="M4 12h16M2 9v6M6 7v10M18 7v10M22 9v6"/>',
		'treadmill'  => '<path d="M3 17h13a4 4 0 0 0 4-4M6 17V9l6-3M6 9h5M9 21l-2-4M15 21l-1.5-3"/><circle cx="17" cy="6" r="2"/>',
		'kettlebell' => '<circle cx="12" cy="14" r="7"/><path d="M9 7a3 3 0 0 1 6 0v3H9V7z"/>',
		'rower'      => '<path d="M3 19h18M4 19V9l16-4v6L4 15M15 5 9 15"/>',
		'ropes'      => '<path d="M3 6c4 3 4-3 8 0s4-3 8 0M3 12c4 3 4-3 8 0s4-3 8 0M3 18c4 3 4-3 8 0s4-3 8 0"/>',
		'heart'      => '<path d="M12 21s-7.5-4.9-10-9.3C.4 8.2 2 4.5 5.6 4A5 5 0 0 1 12 7a5 5 0 0 1 6.4-3c3.6.5 5.2 4.2 3.6 7.7C19.5 16.1 12 21 12 21z"/>',
		'target'     => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
		'trophy'     => '<path d="M8 21h8M12 17v4M7 4h10v4a5 5 0 0 1-10 0V4z"/><path d="M7 5H4a3 3 0 0 0 3 5M17 5h3a3 3 0 0 1-3 5"/>',
		'users'      => '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17.5" cy="9" r="2.4"/><path d="M15.5 14.2c2.3.4 4 2.3 4 4.6v1.2"/>',
		'clock'      => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
		'check'      => '<path d="M20 6 9 17l-5-5"/>',
		'quote'      => '<path d="M7 7h4v4a4 4 0 0 1-4 4H6v-3h1a1 1 0 0 0 1-1V8a1 1 0 0 1 1-1zm10 0h4v4a4 4 0 0 1-4 4h-1v-3h1a1 1 0 0 0 1-1V8a1 1 0 0 1 1-1z"/>',
		'pin'        => '<path d="M12 22s7-7.4 7-12.5A7 7 0 0 0 5 9.5C5 14.6 12 22 12 22z"/><circle cx="12" cy="9.5" r="2.5"/>',
		'phone'      => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
		'mail'       => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
		'instagram'  => '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r="1"/>',
		'facebook'   => '<path d="M14 9h3V6h-3a4 4 0 0 0-4 4v2H8v3h2v6h3v-6h3l1-3h-4v-2a1 1 0 0 1 1-1z"/>',
		'youtube'    => '<rect x="2" y="5" width="20" height="14" rx="4"/><path d="M10 9v6l5-3z" fill="currentColor" stroke="none"/>',
		'menu'       => '<path d="M4 7h16M4 12h16M4 17h16"/>',
		'close'      => '<path d="M6 6l12 12M18 6 6 18"/>',
		'arrow'      => '<path d="M5 12h14M13 6l6 6-6 6"/>',
	);

	if ( ! isset( $icons[ $name ] ) ) {
		return '';
	}

	return sprintf(
		'<svg class="icon-svg %1$s" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">%2$s</svg>',
		esc_attr( $class ),
		$icons[ $name ] // Fixed internal markup, not user input.
	);
}

/**
 * Trainer initials fallback avatar (used when no featured image is set).
 */
function iwg_initials( $name ) {
	$words = preg_split( '/\s+/', trim( $name ) );
	$initials = '';
	foreach ( array_slice( $words, 0, 2 ) as $w ) {
		$initials .= mb_substr( $w, 0, 1 );
	}
	return mb_strtoupper( $initials );
}
