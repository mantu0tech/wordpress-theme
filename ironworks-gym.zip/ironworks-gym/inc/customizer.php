<?php
/**
 * Theme Customizer.
 *
 * @package Ironworks_Gym
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function iwg_customize_register( $wp_customize ) {

	/* ===== HERO ============================================= */
	$wp_customize->add_section( 'iwg_hero', array( 'title' => __( 'Homepage Hero', 'ironworks-gym' ), 'priority' => 30 ) );

	$hero_fields = array(
		'iwg_hero_eyebrow' => array( 'default' => 'Warehouse District · Est. 2016', 'label' => 'Eyebrow Text' ),
		'iwg_hero_title_1' => array( 'default' => 'Strength Is Built.', 'label' => 'Headline Line 1' ),
		'iwg_hero_title_2' => array( 'default' => 'Not Born.', 'label' => 'Headline Line 2 (accent color)' ),
		'iwg_hero_lede'    => array( 'default' => 'A no-nonsense strength club with real equipment, real coaching, and a community that shows up. Train here.', 'label' => 'Supporting Text', 'type' => 'textarea' ),
		'iwg_hero_cta_text'=> array( 'default' => 'Start Free Trial', 'label' => 'Primary Button Text' ),
		'iwg_hero_cta_url' => array( 'default' => '#contact', 'label' => 'Primary Button Link' ),
		'iwg_hero_cta2_text' => array( 'default' => 'View Services', 'label' => 'Secondary Button Text' ),
		'iwg_hero_cta2_url'  => array( 'default' => '/services/', 'label' => 'Secondary Button Link' ),
		'iwg_hero_stat1_num' => array( 'default' => '9', 'label' => 'Stat 1 Number' ),
		'iwg_hero_stat1_label' => array( 'default' => 'Years Open', 'label' => 'Stat 1 Label' ),
		'iwg_hero_stat2_num' => array( 'default' => '800+', 'label' => 'Stat 2 Number' ),
		'iwg_hero_stat2_label' => array( 'default' => 'Active Members', 'label' => 'Stat 2 Label' ),
		'iwg_hero_stat3_num' => array( 'default' => '20+', 'label' => 'Stat 3 Number' ),
		'iwg_hero_stat3_label' => array( 'default' => 'Weekly Classes', 'label' => 'Stat 3 Label' ),
	);
	foreach ( $hero_fields as $id => $f ) {
		$wp_customize->add_setting( $id, array( 'default' => $f['default'], 'sanitize_callback' => 'sanitize_text_field' ) );
		$wp_customize->add_control( $id, array( 'label' => __( $f['label'], 'ironworks-gym' ), 'section' => 'iwg_hero', 'type' => isset( $f['type'] ) ? $f['type'] : 'text' ) );
	}

	/* ===== ABOUT (used on Home teaser + About page template) === */
	$wp_customize->add_section( 'iwg_about', array( 'title' => __( 'About Content', 'ironworks-gym' ), 'priority' => 31 ) );

	$wp_customize->add_setting( 'iwg_about_eyebrow', array( 'default' => 'Our Story', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'iwg_about_eyebrow', array( 'label' => __( 'Eyebrow Text', 'ironworks-gym' ), 'section' => 'iwg_about' ) );

	$wp_customize->add_setting( 'iwg_about_title', array( 'default' => 'Built In A Warehouse. Built For Results.', 'sanitize_callback' => 'sanitize_text_field' ) );
	$wp_customize->add_control( 'iwg_about_title', array( 'label' => __( 'Title', 'ironworks-gym' ), 'section' => 'iwg_about' ) );

	$wp_customize->add_setting( 'iwg_about_body', array(
		'default' => "Ironworks opened in 2016 inside a converted warehouse because we wanted a gym that felt like a gym — heavy equipment, honest coaching, no gimmicks. Today we're a strength club built around barbells, kettlebells, rowing machines and a coaching staff that actually watches your form.\n\nWe're not a boutique studio. We're a place to get strong, get conditioned, and get coached by people who've done it themselves.",
		'sanitize_callback' => 'sanitize_textarea_field',
	) );
	$wp_customize->add_control( 'iwg_about_body', array( 'label' => __( 'Body Text (one paragraph per line)', 'ironworks-gym' ), 'section' => 'iwg_about', 'type' => 'textarea' ) );

	$default_pillars = "Real Equipment | Full racks, plates, rowers and sleds — not a room full of dumbbells.\nCoached, Not Guessed | Every program is written and adjusted by a real coach watching real reps.\nCommunity That Shows Up | Group classes and open-floor hours where people actually know your name.";
	$wp_customize->add_setting( 'iwg_about_pillars', array( 'default' => $default_pillars, 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'iwg_about_pillars', array( 'label' => __( 'Pillars (Title | Description, one per line)', 'ironworks-gym' ), 'section' => 'iwg_about', 'type' => 'textarea' ) );

	/* ===== EQUIPMENT (About / Home showcase) ================ */
	$wp_customize->add_section( 'iwg_equipment', array( 'title' => __( 'Equipment Showcase', 'ironworks-gym' ), 'priority' => 32, 'description' => __( 'Icon | Name | Short description — one per line. Icon must be one of: dumbbell, barbell, treadmill, kettlebell, rower, ropes.', 'ironworks-gym' ) ) );

	$default_equipment = "barbell | Full Power Racks | Six competition power racks with bumper plates for squat, bench and deadlift work.\nkettlebell | Kettlebell Wall | 8kg to 48kg kettlebells for swings, cleans, and conditioning circuits.\nrower | Rowing Machines | A bank of Concept2 rowers for interval work and cardio programming.\ntreadmill | Cardio Deck | Treadmills and assault bikes for warm-ups, finishers and steady-state work.\ndumbbell | Free Weight Floor | Dumbbells from 5lb to 100lb plus a full adjustable bench line-up.\nropes | Conditioning Rig | Battle ropes, sleds and a functional rig for circuit-based conditioning.";
	$wp_customize->add_setting( 'iwg_equipment_list', array( 'default' => $default_equipment, 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'iwg_equipment_list', array( 'label' => __( 'Equipment List', 'ironworks-gym' ), 'section' => 'iwg_equipment', 'type' => 'textarea' ) );

	/* ===== TESTIMONIALS ======================================= */
	$wp_customize->add_section( 'iwg_testimonials', array( 'title' => __( 'Testimonials', 'ironworks-gym' ), 'priority' => 33, 'description' => __( 'Quote | Name | Role/achievement — one per line.', 'ironworks-gym' ) ) );

	$default_testimonials = "I went from barely deadlifting the bar to a 315lb pull in eight months. The coaching here is the real difference.|Jordan M.|Member since 2022\nBest gym I've trained at. Equipment is always available and the coaches actually correct your form.|Alicia R.|Member since 2021\nThe HIIT classes wrecked me in the best way. Down 30lbs and stronger than I've ever been.|Sam T.|Member since 2023";
	$wp_customize->add_setting( 'iwg_testimonials_list', array( 'default' => $default_testimonials, 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'iwg_testimonials_list', array( 'label' => __( 'Testimonials', 'ironworks-gym' ), 'section' => 'iwg_testimonials', 'type' => 'textarea' ) );

	/* ===== SCHEDULE ============================================ */
	$wp_customize->add_section( 'iwg_schedule', array( 'title' => __( 'Weekly Schedule', 'ironworks-gym' ), 'priority' => 34, 'description' => __( 'Day | Time | Class | Coach — one per line.', 'ironworks-gym' ) ) );

	$default_schedule = "Monday | 6:00 AM | Strength & Conditioning | Marcus\nMonday | 5:30 PM | HIIT Circuits | Dana\nTuesday | 6:00 AM | Mobility & Recovery | Priya\nTuesday | 6:00 PM | Group Rowing | Dana\nWednesday | 6:00 AM | Strength & Conditioning | Marcus\nThursday | 5:30 PM | HIIT Circuits | Dana\nFriday | 6:00 AM | Strength & Conditioning | Marcus\nSaturday | 9:00 AM | Open Floor + Coaching | Theo";
	$wp_customize->add_setting( 'iwg_schedule_list', array( 'default' => $default_schedule, 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'iwg_schedule_list', array( 'label' => __( 'Schedule', 'ironworks-gym' ), 'section' => 'iwg_schedule', 'type' => 'textarea' ) );

	/* ===== MEMBERSHIP PRICING ================================== */
	$wp_customize->add_section( 'iwg_pricing', array( 'title' => __( 'Membership Pricing', 'ironworks-gym' ), 'priority' => 35, 'description' => __( 'Name | Price | Period | Featured(yes/no) | Features (comma separated) — one plan per line.', 'ironworks-gym' ) ) );

	$default_pricing = "Basic | \$39 | per month | no | Open floor access,Standard equipment,Locker room access\nUnlimited | \$69 | per month | yes | Unlimited classes,Open floor access,1 free PT session/mo,Priority booking\nAnnual | \$599 | per year | no | Everything in Unlimited,2 months free,Free guest passes";
	$wp_customize->add_setting( 'iwg_pricing_list', array( 'default' => $default_pricing, 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'iwg_pricing_list', array( 'label' => __( 'Membership Plans', 'ironworks-gym' ), 'section' => 'iwg_pricing', 'type' => 'textarea' ) );

	/* ===== CONTACT INFO (used across Contact page + footer) ==== */
	$wp_customize->add_section( 'iwg_contact', array( 'title' => __( 'Contact & Location', 'ironworks-gym' ), 'priority' => 36 ) );

	$contact_fields = array(
		'iwg_contact_address'  => array( 'default' => '412 Foundry Street, Warehouse District' ),
		'iwg_contact_city'     => array( 'default' => 'Portland, OR 97209' ),
		'iwg_contact_phone'    => array( 'default' => '(503) 555-0192' ),
		'iwg_contact_email'    => array( 'default' => 'hello@ironworksgym.test' ),
		'iwg_contact_hours'    => array( 'default' => "Mon–Fri: 5:00 AM – 10:00 PM\nSat–Sun: 7:00 AM – 6:00 PM" ),
		'iwg_contact_map_embed'=> array( 'default' => '' ),
		'iwg_notify_email'     => array( 'default' => get_option( 'admin_email' ), 'label' => 'Send form notifications to (in addition to storing them in WP)' ),
	);
	foreach ( $contact_fields as $id => $f ) {
		$type = ( 'iwg_contact_hours' === $id || 'iwg_contact_map_embed' === $id ) ? 'textarea' : 'text';
		$wp_customize->add_setting( $id, array( 'default' => $f['default'], 'sanitize_callback' => 'iwg_contact_map_embed' === $id ? 'wp_kses_post' : 'sanitize_textarea_field' ) );
		$wp_customize->add_control( $id, array(
			'label'       => isset( $f['label'] ) ? __( $f['label'], 'ironworks-gym' ) : ucwords( str_replace( array( 'iwg_contact_', '_' ), array( '', ' ' ), $id ) ),
			'section'     => 'iwg_contact',
			'type'        => $type,
			'description' => 'iwg_contact_map_embed' === $id ? __( 'Optional: paste a Google Maps embed iframe URL (Share > Embed a map > copy the src="..." value only).', 'ironworks-gym' ) : '',
		) );
	}

	$wp_customize->add_setting( 'iwg_social_instagram', array( 'default' => 'https://instagram.com', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'iwg_social_instagram', array( 'label' => __( 'Instagram URL', 'ironworks-gym' ), 'section' => 'iwg_contact' ) );
	$wp_customize->add_setting( 'iwg_social_facebook', array( 'default' => 'https://facebook.com', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'iwg_social_facebook', array( 'label' => __( 'Facebook URL', 'ironworks-gym' ), 'section' => 'iwg_contact' ) );
	$wp_customize->add_setting( 'iwg_social_youtube', array( 'default' => 'https://youtube.com', 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control( 'iwg_social_youtube', array( 'label' => __( 'YouTube URL', 'ironworks-gym' ), 'section' => 'iwg_contact' ) );

	/* ===== FOOTER ================================================ */
	$wp_customize->add_section( 'iwg_footer', array( 'title' => __( 'Footer', 'ironworks-gym' ), 'priority' => 37 ) );
	$wp_customize->add_setting( 'iwg_footer_about', array( 'default' => 'A no-nonsense strength club with real equipment and real coaching, since 2016.', 'sanitize_callback' => 'sanitize_textarea_field' ) );
	$wp_customize->add_control( 'iwg_footer_about', array( 'label' => __( 'Short About (footer column)', 'ironworks-gym' ), 'section' => 'iwg_footer', 'type' => 'textarea' ) );
}
add_action( 'customize_register', 'iwg_customize_register' );
