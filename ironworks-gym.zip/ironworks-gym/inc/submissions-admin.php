<?php
/**
 * Admin list-table customization for the gym_submission CPT, so the site
 * owner can see contact form entries at a glance in wp-admin without
 * opening each one.
 *
 * @package Ironworks_Gym
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Custom columns.
 */
function iwg_submission_columns( $columns ) {
	$new = array(
		'cb'                => $columns['cb'],
		'title'             => __( 'Name', 'ironworks-gym' ),
		'submission_email'  => __( 'Email', 'ironworks-gym' ),
		'submission_phone'  => __( 'Phone', 'ironworks-gym' ),
		'submission_subject'=> __( 'Subject', 'ironworks-gym' ),
		'submission_message'=> __( 'Message', 'ironworks-gym' ),
		'date'              => __( 'Received', 'ironworks-gym' ),
	);
	return $new;
}
add_filter( 'manage_gym_submission_posts_columns', 'iwg_submission_columns' );

function iwg_submission_column_content( $column, $post_id ) {
	switch ( $column ) {
		case 'submission_email':
			$email = get_post_meta( $post_id, '_submission_email', true );
			echo $email ? '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' : '&mdash;';
			break;
		case 'submission_phone':
			$phone = get_post_meta( $post_id, '_submission_phone', true );
			echo $phone ? esc_html( $phone ) : '&mdash;';
			break;
		case 'submission_subject':
			$subject = get_post_meta( $post_id, '_submission_subject', true );
			echo $subject ? esc_html( $subject ) : '&mdash;';
			break;
		case 'submission_message':
			$message = get_post_meta( $post_id, '_submission_message', true );
			echo $message ? esc_html( wp_trim_words( $message, 12 ) ) : '&mdash;';
			break;
	}
}
add_action( 'manage_gym_submission_posts_custom_column', 'iwg_submission_column_content', 10, 2 );

/**
 * Remove the "Add New" screen for submissions — entries are only ever
 * created by the contact form handler, never manually in wp-admin.
 */
function iwg_hide_submission_add_new() {
	global $pagenow, $typenow;
	if ( 'gym_submission' === $typenow && in_array( $pagenow, array( 'post-new.php' ), true ) ) {
		wp_safe_redirect( admin_url( 'edit.php?post_type=gym_submission' ) );
		exit;
	}
}
add_action( 'admin_init', 'iwg_hide_submission_add_new' );

/**
 * Flag unread submissions (no "_submission_read" meta yet) with a small
 * badge in the admin menu count.
 */
function iwg_submission_menu_badge( $menu ) {
	$count = get_posts( array(
		'post_type'      => 'gym_submission',
		'posts_per_page' => -1,
		'fields'         => 'ids',
		'meta_query'     => array(
			array( 'key' => '_submission_read', 'compare' => 'NOT EXISTS' ),
		),
	) );
	if ( empty( $count ) ) {
		return $menu;
	}
	foreach ( $menu as $key => $item ) {
		if ( isset( $item[2] ) && 'edit.php?post_type=gym_submission' === $item[2] ) {
			$menu[ $key ][0] .= ' <span class="update-plugins count-' . count( $count ) . '"><span class="update-count">' . count( $count ) . '</span></span>';
		}
	}
	return $menu;
}
add_filter( 'menu_order', 'iwg_submission_menu_badge' );

/**
 * Mark a submission as read the first time it's opened in wp-admin.
 */
function iwg_mark_submission_read() {
	global $pagenow, $typenow;
	if ( 'gym_submission' === $typenow && 'post.php' === $pagenow && isset( $_GET['post'] ) ) {
		$post_id = absint( $_GET['post'] );
		if ( $post_id && ! get_post_meta( $post_id, '_submission_read', true ) ) {
			update_post_meta( $post_id, '_submission_read', 1 );
		}
	}
}
add_action( 'current_screen', 'iwg_mark_submission_read' );
