<?php
/**
 * Template Name: Services
 *
 * @package Ironworks_Gym
 */

get_header();

$services = new WP_Query( array(
	'post_type'      => 'gym_service',
	'posts_per_page' => -1,
	'orderby'        => 'menu_order date',
	'order'          => 'ASC',
) );
?>

<section class="section" style="padding-top:170px;">
	<div class="container">
		<div class="section-head center reveal" style="max-width:720px;">
			<span class="eyebrow"><?php esc_html_e( 'What We Offer', 'ironworks-gym' ); ?></span>
			<h1><?php the_title(); ?></h1>
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<?php if ( get_the_content() ) : the_content(); else : ?>
					<p><?php esc_html_e( 'Every program below is coached and programmed by our staff — pick the one that matches your goal, or ask us and we\'ll point you in the right direction.', 'ironworks-gym' ); ?></p>
				<?php endif; ?>
			<?php endwhile; endif; ?>
		</div>

		<?php if ( $services->have_posts() ) : ?>
			<div class="card-grid">
				<?php
				while ( $services->have_posts() ) :
					$services->the_post();
					$icon     = get_post_meta( get_the_ID(), '_service_icon', true );
					$price    = get_post_meta( get_the_ID(), '_service_price', true );
					$duration = get_post_meta( get_the_ID(), '_service_duration', true );
					?>
					<div class="program-card reveal">
						<?php if ( has_post_thumbnail() ) : ?>
							<div style="margin:-32px -32px 20px; border-radius:4px 4px 0 0; overflow:hidden;">
								<?php the_post_thumbnail( 'iwg-card', array( 'style' => 'width:100%; height:180px; object-fit:cover;' ) ); ?>
							</div>
						<?php else : ?>
							<div class="icon"><?php echo iwg_icon( $icon ? $icon : 'target' ); ?></div>
						<?php endif; ?>
						<h3><?php the_title(); ?></h3>
						<?php if ( $price || $duration ) : ?>
							<span class="meta"><?php echo esc_html( $price ); ?><?php echo ( $price && $duration ) ? ' · ' : ''; ?><?php echo esc_html( $duration ); ?></span>
						<?php endif; ?>
						<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 22 ) ); ?></p>
						<a class="card-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Learn More', 'ironworks-gym' ); ?> <?php echo iwg_icon( 'arrow' ); ?></a>
					</div>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		<?php else : ?>
			<div class="empty-state"><p><?php esc_html_e( 'Services will appear here once added under Services in wp-admin.', 'ironworks-gym' ); ?></p></div>
		<?php endif; ?>
	</div>
</section>

<?php get_template_part( 'template-parts/home', 'pricing' ); ?>
<?php get_template_part( 'template-parts/home', 'cta' ); ?>

<?php
get_footer();
