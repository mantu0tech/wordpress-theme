<?php
/**
 * Ironworks Gym — theme functions and definitions
 *
 * @package Ironworks_Gym
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'IWG_VERSION', '1.0.0' );
define( 'IWG_DIR', get_template_directory() );
define( 'IWG_URI', get_template_directory_uri() );

/**
 * Theme setup.
 */
function iwg_setup() {
	load_theme_textdomain( 'ironworks-gym', IWG_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'custom-logo', array(
		'height'      => 60,
		'width'       => 220,
		'flex-height' => true,
		'flex-width'  => true,
	) );

	set_post_thumbnail_size( 800, 600, true );
	add_image_size( 'iwg-card', 640, 420, true );
	add_image_size( 'iwg-avatar', 500, 500, true );
	add_image_size( 'iwg-hero', 1400, 900, true );

	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'ironworks-gym' ),
		'footer'  => __( 'Footer Menu', 'ironworks-gym' ),
	) );
}
add_action( 'after_setup_theme', 'iwg_setup' );

function iwg_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'iwg_content_width', 1180 );
}
add_action( 'after_setup_theme', 'iwg_content_width', 0 );

/**
 * Enqueue styles & scripts.
 */
function iwg_scripts() {
	$v = IWG_VERSION;

	wp_enqueue_style( 'iwg-fonts', 'https://fonts.googleapis.com/css2?family=Anton&family=Work+Sans:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap', array(), null );
	wp_enqueue_style( 'ironworks-gym-style', get_stylesheet_uri(), array(), $v );

	wp_enqueue_script( 'ironworks-gym-main', IWG_URI . '/assets/js/main.js', array(), $v, true );
	wp_localize_script( 'ironworks-gym-main', 'iwgData', array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'iwg_contact_nonce' ),
	) );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'iwg_scripts' );

/**
 * Includes.
 */
require IWG_DIR . '/inc/class-nav-walker.php';
require IWG_DIR . '/inc/custom-post-types.php';
require IWG_DIR . '/inc/customizer.php';
require IWG_DIR . '/inc/template-tags.php';
require IWG_DIR . '/inc/contact-form.php';
require IWG_DIR . '/inc/submissions-admin.php';

/**
 * Widget areas.
 */
function iwg_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Blog Sidebar', 'ironworks-gym' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Shown on blog posts and the blog index.', 'ironworks-gym' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );

	register_sidebar( array(
		'name'          => __( 'Footer Widgets', 'ironworks-gym' ),
		'id'            => 'footer-1',
		'description'   => __( 'Optional extra footer column content.', 'ironworks-gym' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'iwg_widgets_init' );

/**
 * Fallback primary menu (mirrors the theme's core pages/sections) shown
 * when no menu is assigned in Appearance > Menus.
 */
function iwg_fallback_menu() {
	$items = array(
		home_url( '/' )                     => __( 'Home', 'ironworks-gym' ),
		home_url( '/about-us/' )            => __( 'About', 'ironworks-gym' ),
		home_url( '/services/' )            => __( 'Services', 'ironworks-gym' ),
		home_url( '/#schedule' )            => __( 'Schedule', 'ironworks-gym' ),
		home_url( '/contact-us/' )          => __( 'Contact', 'ironworks-gym' ),
	);
	echo '<ul id="primary-menu-fallback">';
	foreach ( $items as $url => $label ) {
		printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( $url ), esc_html( $label ) );
	}
	echo '</ul>';
}

/**
 * Excerpt tweaks.
 */
add_filter( 'excerpt_length', function ( $length ) { return 22; } );
add_filter( 'excerpt_more', function ( $more ) { return '&hellip;'; } );

/**
 * Editor styling.
 */
add_action( 'admin_init', function () {
	add_editor_style( 'style.css' );
} );

remove_action( 'wp_head', 'wp_generator' );

/**
 * Activation: seed default terms / flush rewrites.
 */
function iwg_after_switch_theme() {
	iwg_register_post_types();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'iwg_after_switch_theme' );
