<?php
/**
 * 404 error template.
 *
 * @package Ironworks_Gym
 */

get_header();
?>
<section class="section" style="padding-top:200px; text-align:center;">
	<div class="container">
		<div class="section-head center reveal" style="max-width:600px; margin:0 auto;">
			<span class="eyebrow">404</span>
			<h1><?php esc_html_e( 'Rep Not Found', 'ironworks-gym' ); ?></h1>
			<p><?php esc_html_e( "That page isn't on our floor. Let's get you back on track.", 'ironworks-gym' ); ?></p>
		</div>
		<div class="hero-actions" style="justify-content:center; margin-top:30px;">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn--primary"><?php esc_html_e( 'Back To Home', 'ironworks-gym' ); ?></a>
		</div>
		<div style="max-width:420px; margin:40px auto 0;"><?php get_search_form(); ?></div>
	</div>
</section>
<?php
get_footer();
