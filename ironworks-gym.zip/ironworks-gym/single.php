<?php
/**
 * Single blog post template.
 *
 * @package Ironworks_Gym
 */

get_header();
?>
<section class="section" style="padding-top:170px;">
	<div class="container">
		<?php while ( have_posts() ) : the_post(); ?>
			<div class="entry-header reveal">
				<span class="date"><?php echo esc_html( get_the_date() ); ?><?php $cats = get_the_category_list( ', ' ); echo $cats ? ' · ' . wp_kses_post( $cats ) : ''; ?></span>
				<h1><?php the_title(); ?></h1>
			</div>

			<?php if ( has_post_thumbnail() ) : ?>
				<div class="entry-thumb reveal"><?php the_post_thumbnail( 'iwg-hero' ); ?></div>
			<?php endif; ?>

			<div class="about-grid" style="grid-template-columns: 2fr 1fr; align-items:start;">
				<div>
					<div class="entry-content reveal">
						<?php the_content(); ?>
						<?php
						wp_link_pages( array(
							'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'ironworks-gym' ),
							'after'  => '</div>',
						) );
						?>
					</div>

					<?php if ( comments_open() || get_comments_number() ) : ?>
						<?php comments_template(); ?>
					<?php endif; ?>
				</div>
				<div><?php get_sidebar(); ?></div>
			</div>
		<?php endwhile; ?>
	</div>
</section>
<?php
get_footer();
