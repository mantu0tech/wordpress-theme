<?php
/**
 * The template for displaying single posts.
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main content-area">
	<div class="container">

		<div class="content-layout">
			<div class="content-main">

				<?php
				while ( have_posts() ) :
					the_post();
					?>

					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

						<header class="single-post-header">
							<?php if ( 'cafe_menu' === get_post_type() ) : ?>
								<span class="eyebrow"><?php esc_html_e( 'Cafe Menu', 'irani-cafe' ); ?></span>
							<?php else : ?>
								<div class="post-meta">
									<?php irani_cafe_posted_on(); ?>
									<?php irani_cafe_posted_by(); ?>
								</div>
							<?php endif; ?>

							<h1 class="entry-title"><?php the_title(); ?></h1>

							<?php if ( 'cafe_menu' === get_post_type() ) : ?>
								<p class="menu-item-price" style="font-size:1.4rem;"><?php echo esc_html( irani_cafe_get_price( get_the_ID() ) ); ?></p>
							<?php endif; ?>
						</header>

						<?php irani_cafe_the_post_thumbnail( 'large' ); ?>

						<div class="entry-content">
							<?php
							the_content();

							wp_link_pages( array(
								'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'irani-cafe' ),
								'after'  => '</div>',
							) );
							?>
						</div>

						<footer class="entry-footer">
							<?php irani_cafe_entry_footer(); ?>
						</footer>

					</article>

					<?php
					$prev_post = get_previous_post();
					$next_post = get_next_post();
					if ( $prev_post || $next_post ) :
						?>
						<nav class="post-navigation">
							<div class="nav-previous">
								<?php if ( $prev_post ) : ?>
									<span><?php esc_html_e( 'Previous', 'irani-cafe' ); ?></span>
									<a href="<?php echo esc_url( get_permalink( $prev_post ) ); ?>">&larr; <?php echo esc_html( get_the_title( $prev_post ) ); ?></a>
								<?php endif; ?>
							</div>
							<div class="nav-next">
								<?php if ( $next_post ) : ?>
									<span><?php esc_html_e( 'Next', 'irani-cafe' ); ?></span>
									<a href="<?php echo esc_url( get_permalink( $next_post ) ); ?>"><?php echo esc_html( get_the_title( $next_post ) ); ?> &rarr;</a>
								<?php endif; ?>
							</div>
						</nav>
					<?php endif; ?>

					<?php
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
					?>

				<?php endwhile; ?>

			</div>

			<?php get_sidebar(); ?>
		</div>

	</div>
</main><!-- #primary -->

<?php
get_footer();
