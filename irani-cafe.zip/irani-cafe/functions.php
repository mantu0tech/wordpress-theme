<?php
/**
 * Irani Cafe Theme functions and definitions
 *
 * @package Irani_Cafe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'IRANI_CAFE_VERSION', '1.0.0' );

/**
 * Theme Setup
 */
function irani_cafe_setup() {

	// Translation ready.
	load_theme_textdomain( 'irani-cafe', get_template_directory() . '/languages' );

	// Native WP feature support.
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
		'style',
		'script',
		'navigation-widgets',
	) );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );

	// Custom logo.
	add_theme_support( 'custom-logo', array(
		'height'      => 90,
		'width'       => 90,
		'flex-height' => true,
		'flex-width'  => true,
	) );

	// Custom background (Appearance > Background).
	add_theme_support( 'custom-background', array(
		'default-color' => 'f6ecda',
	) );

	// Featured image sizes used across the theme.
	set_post_thumbnail_size( 900, 600, true );
	add_image_size( 'irani-cafe-square', 400, 400, true );
	add_image_size( 'irani-cafe-hero', 900, 1100, true );

	// Nav menus.
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary Menu', 'irani-cafe' ),
		'footer'  => esc_html__( 'Footer Menu', 'irani-cafe' ),
	) );
}
add_action( 'after_setup_theme', 'irani_cafe_setup' );

/**
 * Content width for embeds/images.
 */
function irani_cafe_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'irani_cafe_content_width', 860 );
}
add_action( 'after_setup_theme', 'irani_cafe_content_width', 0 );

/**
 * Enqueue styles and scripts.
 */
function irani_cafe_scripts() {

	// Google Fonts (Playfair Display + Work Sans).
	wp_enqueue_style(
		'irani-cafe-fonts',
		'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Work+Sans:wght@400;500;600;700&display=swap',
		array(),
		null
	);

	// Main theme stylesheet.
	wp_enqueue_style( 'irani-cafe-style', get_stylesheet_uri(), array(), IRANI_CAFE_VERSION );

	// Theme script (mobile nav, menu tabs, back to top).
	wp_enqueue_script( 'irani-cafe-main', get_template_directory_uri() . '/js/main.js', array(), IRANI_CAFE_VERSION, true );

	// Threaded comment reply script on singular pages when needed.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'irani_cafe_scripts' );

/**
 * Register widget areas.
 */
function irani_cafe_widgets_init() {

	register_sidebar( array(
		'name'          => esc_html__( 'Blog Sidebar', 'irani-cafe' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Appears on blog, archive and single posts.', 'irani-cafe' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	$footer_columns = array(
		'footer-1' => esc_html__( 'Footer Column 1', 'irani-cafe' ),
		'footer-2' => esc_html__( 'Footer Column 2', 'irani-cafe' ),
		'footer-3' => esc_html__( 'Footer Column 3', 'irani-cafe' ),
	);

	foreach ( $footer_columns as $id => $name ) {
		register_sidebar( array(
			'name'          => $name,
			'id'            => $id,
			'description'   => esc_html__( 'Footer widget area.', 'irani-cafe' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h4 class="footer-widget-title">',
			'after_title'   => '</h4>',
		) );
	}
}
add_action( 'widgets_init', 'irani_cafe_widgets_init' );

/**
 * Fallback menu if no menu is assigned to a location.
 */
function irani_cafe_fallback_menu() {
	echo '<ul class="menu"><li><a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html__( 'Home', 'irani-cafe' ) . '</a></li>';
	wp_list_pages( array( 'title_li' => '' ) );
	echo '</ul>';
}

/**
 * Custom excerpt length and "read more" string.
 */
function irani_cafe_excerpt_length( $length ) {
	return 26;
}
add_filter( 'excerpt_length', 'irani_cafe_excerpt_length' );

function irani_cafe_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'irani_cafe_excerpt_more' );

/**
 * Pingback header.
 */
function irani_cafe_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">' . "\n", esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'irani_cafe_pingback_header' );

/**
 * Body classes.
 */
function irani_cafe_body_classes( $classes ) {
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}
	if ( is_front_page() && is_home() ) {
		$classes[] = 'is-default-front-page';
	}
	return $classes;
}
add_filter( 'body_class', 'irani_cafe_body_classes' );

/**
 * Register block editor / theme color palette (nice to have, native support).
 */
function irani_cafe_editor_styles() {
	add_theme_support( 'editor-color-palette', array(
		array( 'name' => esc_html__( 'Coffee Brown', 'irani-cafe' ), 'slug' => 'cafe-brown', 'color' => '#2b1b12' ),
		array( 'name' => esc_html__( 'Maroon', 'irani-cafe' ), 'slug' => 'cafe-maroon', 'color' => '#7a2e2e' ),
		array( 'name' => esc_html__( 'Mustard', 'irani-cafe' ), 'slug' => 'cafe-mustard', 'color' => '#d9a441' ),
		array( 'name' => esc_html__( 'Cream', 'irani-cafe' ), 'slug' => 'cafe-cream', 'color' => '#f6ecda' ),
		array( 'name' => esc_html__( 'Teal', 'irani-cafe' ), 'slug' => 'cafe-teal', 'color' => '#1f5f5b' ),
	) );
}
add_action( 'after_setup_theme', 'irani_cafe_editor_styles' );

/**
 * Handle the front-page contact form fallback submission (used only when no
 * form plugin such as Contact Form 7 is active). Sends mail via wp_mail().
 */
function irani_cafe_handle_contact_form() {

	if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'irani_cafe_contact_nonce' ) ) {
		wp_die( esc_html__( 'Security check failed.', 'irani-cafe' ) );
	}

	$name    = isset( $_POST['contact_name'] ) ? sanitize_text_field( $_POST['contact_name'] ) : '';
	$email   = isset( $_POST['contact_email'] ) ? sanitize_email( $_POST['contact_email'] ) : '';
	$message = isset( $_POST['contact_message'] ) ? sanitize_textarea_field( $_POST['contact_message'] ) : '';

	if ( $name && is_email( $email ) && $message ) {
		$to      = get_theme_mod( 'irani_cafe_email', get_option( 'admin_email' ) );
		$subject = sprintf( esc_html__( 'New enquiry from %s via website', 'irani-cafe' ), $name );
		$body    = $message . "\n\n" . esc_html__( 'Reply to:', 'irani-cafe' ) . ' ' . $email;
		$headers = array( 'Reply-To: ' . $email );

		wp_mail( $to, $subject, $body, $headers );
	}

	wp_safe_redirect( add_query_arg( 'contact', 'sent', wp_get_referer() ? wp_get_referer() : home_url( '/' ) ) );
	exit;
}
add_action( 'admin_post_irani_cafe_contact', 'irani_cafe_handle_contact_form' );
add_action( 'admin_post_nopriv_irani_cafe_contact', 'irani_cafe_handle_contact_form' );

/**
 * Include additional theme files.
 */
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/cafe-menu-cpt.php';
require get_template_directory() . '/inc/customizer.php';
