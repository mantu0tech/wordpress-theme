<?php
/**
 * The header for the theme.
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">

<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'irani-cafe' ); ?></a>

<div class="tag-strip" aria-hidden="true"></div>

<header id="masthead" class="site-header">
	<div class="container header-inner">

		<div class="site-branding">
			<?php
			if ( has_custom_logo() ) {
				the_custom_logo();
			} else {
				echo '<span class="site-icon" aria-hidden="true" style="font-size:2rem;">☕</span>';
			}
			?>
			<div class="site-branding-text">
				<?php if ( is_front_page() && is_home() ) : ?>
					<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php else : ?>
					<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
				<?php endif; ?>
				<?php $description = get_bloginfo( 'description', 'display' ); ?>
				<?php if ( $description || is_customize_preview() ) : ?>
					<p class="site-description"><?php echo $description; // phpcs:ignore ?></p>
				<?php endif; ?>
			</div>
		</div><!-- .site-branding -->

		<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
			<span></span><span></span><span></span>
			<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'irani-cafe' ); ?></span>
		</button>

		<nav id="site-navigation" class="primary-navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'irani-cafe' ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'menu_id'        => 'primary-menu',
				'container'      => false,
				'fallback_cb'    => 'irani_cafe_fallback_menu',
			) );
			?>
		</nav>

		<div class="header-cta">
			<a href="#contact" class="btn"><span><?php esc_html_e( 'Book a Table', 'irani-cafe' ); ?></span> →</a>
		</div>

	</div>
</header><!-- #masthead -->

<div class="nav-overlay"></div>
