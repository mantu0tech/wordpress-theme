<?php
/**
 * The template for displaying all static pages.
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main content-area">
	<div class="container">

		<div class="content-layout">
			<div class="content-main">

				<?php
				while ( have_posts() ) :
					the_post();
					?>

					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

						<header class="page-header">
							<h1 class="page-title"><?php the_title(); ?></h1>
						</header>

						<?php irani_cafe_the_post_thumbnail( 'large' ); ?>

						<div class="entry-content">
							<?php
							the_content();

							wp_link_pages( array(
								'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'irani-cafe' ),
								'after'  => '</div>',
							) );
							?>
						</div>

					</article>

					<?php
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
					?>

				<?php endwhile; ?>

			</div>

			<?php get_sidebar(); ?>
		</div>

	</div>
</main><!-- #primary -->

<?php
get_footer();
