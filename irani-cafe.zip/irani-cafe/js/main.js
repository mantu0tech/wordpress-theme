/**
 * Irani Cafe theme JS
 * Mobile navigation, submenu accordion, cafe-menu tab filtering.
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {

		/* ---------- Mobile menu toggle ---------- */
		var toggle  = document.querySelector( '.menu-toggle' );
		var nav     = document.querySelector( '.primary-navigation' );
		var overlay = document.querySelector( '.nav-overlay' );

		function closeNav() {
			if ( ! toggle || ! nav ) return;
			toggle.setAttribute( 'aria-expanded', 'false' );
			nav.classList.remove( 'is-open' );
			if ( overlay ) overlay.classList.remove( 'is-open' );
			document.body.style.overflow = '';
		}

		function openNav() {
			toggle.setAttribute( 'aria-expanded', 'true' );
			nav.classList.add( 'is-open' );
			if ( overlay ) overlay.classList.add( 'is-open' );
			document.body.style.overflow = 'hidden';
		}

		if ( toggle && nav ) {
			toggle.addEventListener( 'click', function () {
				var isOpen = toggle.getAttribute( 'aria-expanded' ) === 'true';
				isOpen ? closeNav() : openNav();
			} );
		}

		if ( overlay ) {
			overlay.addEventListener( 'click', closeNav );
		}

		/* ---------- Mobile submenu accordion ---------- */
		var parentLinks = document.querySelectorAll( '.primary-navigation .menu-item-has-children > a' );
		parentLinks.forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				if ( window.innerWidth <= 782 ) {
					var parentLi = link.parentElement;
					var submenu  = parentLi.querySelector( '.sub-menu' );
					if ( submenu ) {
						e.preventDefault();
						parentLi.classList.toggle( 'submenu-open' );
					}
				}
			} );
		} );

		/* Close mobile nav when a normal link is clicked */
		if ( nav ) {
			nav.querySelectorAll( 'a' ).forEach( function ( a ) {
				a.addEventListener( 'click', function () {
					if ( window.innerWidth <= 782 && ! a.parentElement.classList.contains( 'menu-item-has-children' ) ) {
						closeNav();
					}
				} );
			} );
		}

		/* ---------- Sticky header shadow on scroll ---------- */
		var header = document.querySelector( '.site-header' );
		if ( header ) {
			window.addEventListener( 'scroll', function () {
				if ( window.scrollY > 10 ) {
					header.style.boxShadow = '0 8px 24px rgba(43,27,18,0.08)';
				} else {
					header.style.boxShadow = 'none';
				}
			} );
		}

		/* ---------- Cafe menu tab filtering (front page menu highlights) ---------- */
		var tabs  = document.querySelectorAll( '.menu-tab' );
		var items = document.querySelectorAll( '[data-menu-category]' );

		if ( tabs.length && items.length ) {
			tabs.forEach( function ( tab ) {
				tab.addEventListener( 'click', function () {
					tabs.forEach( function ( t ) { t.classList.remove( 'is-active' ); } );
					tab.classList.add( 'is-active' );

					var category = tab.getAttribute( 'data-filter' );

					items.forEach( function ( item ) {
						if ( category === 'all' || item.getAttribute( 'data-menu-category' ) === category ) {
							item.style.display = '';
						} else {
							item.style.display = 'none';
						}
					} );
				} );
			} );
		}

	} );
} )();
