<?php
/**
 * Template part for displaying posts in a card, used on index/archive/search.
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>

	<?php irani_cafe_the_post_thumbnail( 'large' ); ?>

	<div class="post-card-body">
		<div class="post-meta">
			<?php irani_cafe_posted_on(); ?>
			<?php irani_cafe_posted_by(); ?>
		</div>

		<?php the_title( sprintf( '<h2><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

		<div class="entry-summary">
			<?php the_excerpt(); ?>
		</div>

		<a class="read-more-link" href="<?php the_permalink(); ?>">
			<?php esc_html_e( 'Read More', 'irani-cafe' ); ?> →
		</a>
	</div>
</article>
