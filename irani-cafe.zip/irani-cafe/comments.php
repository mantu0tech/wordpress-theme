<?php
/**
 * The template for displaying comments.
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			$comment_count = get_comments_number();
			if ( 1 === (int) $comment_count ) {
				esc_html_e( '1 Comment', 'irani-cafe' );
			} else {
				printf( esc_html( _n( '%1$s Comment', '%1$s Comments', $comment_count, 'irani-cafe' ) ), number_format_i18n( $comment_count ) ); // phpcs:ignore
			}
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments( array(
				'style'      => 'ol',
				'short_ping' => true,
				'avatar_size'=> 48,
			) );
			?>
		</ol>

		<?php
		the_comments_pagination( array(
			'prev_text' => esc_html__( '&larr; Older Comments', 'irani-cafe' ),
			'next_text' => esc_html__( 'Newer Comments &rarr;', 'irani-cafe' ),
		) );
		?>

	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'irani-cafe' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form( array(
		'class_form'   => 'comment-form',
		'title_reply'  => esc_html__( 'Leave a Reply', 'irani-cafe' ),
		'label_submit' => esc_html__( 'Post Comment', 'irani-cafe' ),
	) );
	?>

</div><!-- #comments -->
