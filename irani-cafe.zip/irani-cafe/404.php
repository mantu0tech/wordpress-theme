<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main">
	<div class="container">
		<div class="error-404 not-found">

			<p class="error-code" aria-hidden="true">404</p>
			<h1><?php esc_html_e( 'Looks like this table isn\'t set.', 'irani-cafe' ); ?></h1>
			<p><?php esc_html_e( 'The page you were looking for has been cleared away, like an empty chai cup. Let\'s find you something else from the menu.', 'irani-cafe' ); ?></p>

			<?php get_search_form(); ?>

			<p style="margin-top:2rem;">
				<a class="btn btn-mustard" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php esc_html_e( 'Back to Home', 'irani-cafe' ); ?>
				</a>
			</p>

			<?php if ( post_type_exists( 'cafe_menu' ) ) : ?>
				<div class="section-tight">
					<h2><?php esc_html_e( 'Popular from our menu', 'irani-cafe' ); ?></h2>
					<div class="grid grid-3">
						<?php
						$popular = new WP_Query( array(
							'post_type'      => 'cafe_menu',
							'posts_per_page' => 3,
							'orderby'        => 'rand',
						) );
						if ( $popular->have_posts() ) :
							while ( $popular->have_posts() ) :
								$popular->the_post();
								?>
								<div class="menu-item-card">
									<?php if ( has_post_thumbnail() ) : ?>
										<div class="menu-item-thumb"><?php the_post_thumbnail( 'irani-cafe-square' ); ?></div>
									<?php endif; ?>
									<div class="menu-item-body">
										<div class="menu-item-top">
											<h4><a href="<?php the_permalink(); ?>" style="color:inherit;"><?php the_title(); ?></a></h4>
											<span class="menu-item-price"><?php echo esc_html( irani_cafe_get_price( get_the_ID() ) ); ?></span>
										</div>
									</div>
								</div>
								<?php
							endwhile;
							wp_reset_postdata();
						endif;
						?>
					</div>
				</div>
			<?php endif; ?>

		</div>
	</div>
</main>

<?php
get_footer();
