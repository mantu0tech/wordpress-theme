<?php
/**
 * The homepage template — hero, about, menu highlights, gallery, testimonials, contact.
 * Uses native WordPress functions only (get_theme_mod, WP_Query, dynamic_sidebar, etc).
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$hero_image = get_theme_mod( 'irani_cafe_hero_image', '' );
?>

<main id="primary" class="site-main">

	<!-- ============ HERO ============ -->
	<section class="hero">
		<div class="container hero-inner">
			<div class="hero-content">
				<span class="hero-eyebrow"><?php echo esc_html( get_theme_mod( 'irani_cafe_hero_eyebrow', __( 'Est. 1962 · Since Generations', 'irani-cafe' ) ) ); ?></span>
				<h1><?php echo esc_html( get_theme_mod( 'irani_cafe_hero_title', __( 'Bun Maska, Irani Chai & Old-World Charm', 'irani-cafe' ) ) ); ?></h1>
				<p><?php echo esc_html( get_theme_mod( 'irani_cafe_hero_text', __( 'A cosy corner cafe serving the city\'s finest bun-maska, keema pav, and slow-brewed Irani chai since generations. Pull up a bentwood chair and stay a while.', 'irani-cafe' ) ) ); ?></p>
				<div class="hero-actions">
					<a href="#menu" class="btn btn-mustard"><?php esc_html_e( 'View Menu', 'irani-cafe' ); ?></a>
					<a href="#contact" class="btn btn-outline"><?php esc_html_e( 'Reserve a Table', 'irani-cafe' ); ?></a>
				</div>
				<div class="hero-stats">
					<div class="hero-stat"><strong>60+</strong><span><?php esc_html_e( 'Years Old', 'irani-cafe' ); ?></span></div>
					<div class="hero-stat"><strong>40</strong><span><?php esc_html_e( 'Menu Specials', 'irani-cafe' ); ?></span></div>
					<div class="hero-stat"><strong>4.8★</strong><span><?php esc_html_e( 'Guest Rating', 'irani-cafe' ); ?></span></div>
				</div>
			</div>
			<div class="hero-media">
				<?php if ( $hero_image ) : ?>
					<img src="<?php echo esc_url( $hero_image ); ?>" alt="<?php esc_attr_e( 'Irani cafe interior', 'irani-cafe' ); ?>">
				<?php else : ?>
					<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/hero-placeholder.svg' ); ?>" alt="<?php esc_attr_e( 'Irani cafe interior', 'irani-cafe' ); ?>">
				<?php endif; ?>
			</div>
		</div>
	</section>

	<!-- ============ ABOUT ============ -->
	<section class="section">
		<div class="container">
			<div class="grid about-grid">
				<div class="about-media">
					<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/about-placeholder.svg' ); ?>" alt="<?php esc_attr_e( 'Cafe founder pouring chai', 'irani-cafe' ); ?>">
					<div class="about-badge"><?php esc_html_e( '100% Irani Recipe', 'irani-cafe' ); ?></div>
				</div>
				<div class="about-content">
					<span class="eyebrow"><?php esc_html_e( 'Our Story', 'irani-cafe' ); ?></span>
					<h2><?php esc_html_e( 'A Slice of Old-World Persia, Brewed Daily', 'irani-cafe' ); ?></h2>
					<p><?php esc_html_e( 'What began as a small tea stall run by our great-grandfather has grown into a beloved neighbourhood institution — but the recipes, the checkered floors, and the bentwood chairs remain untouched by time.', 'irani-cafe' ); ?></p>
					<p><?php esc_html_e( 'Every cup of chai is brewed slow, every bun is baked fresh at dawn, and every guest is treated like family — exactly how it has always been done.', 'irani-cafe' ); ?></p>
					<a href="<?php echo esc_url( get_permalink( get_page_by_path( 'about' ) ) ?: '#' ); ?>" class="btn"><?php esc_html_e( 'Read Our Story', 'irani-cafe' ); ?></a>
				</div>
			</div>
		</div>
	</section>

	<!-- ============ FEATURES ============ -->
	<section class="section section-cream">
		<div class="container">
			<div class="section-title">
				<span class="eyebrow"><?php esc_html_e( 'Why Guests Love Us', 'irani-cafe' ); ?></span>
				<h2><?php esc_html_e( 'Everything We Serve, We Serve With Heart', 'irani-cafe' ); ?></h2>
			</div>
			<div class="grid grid-3">
				<div class="feature-card">
					<div class="feature-icon">☕</div>
					<h3><?php esc_html_e( 'Slow-Brewed Chai', 'irani-cafe' ); ?></h3>
					<p><?php esc_html_e( 'Brewed for hours in copper kettles, exactly as it was 60 years ago.', 'irani-cafe' ); ?></p>
				</div>
				<div class="feature-card">
					<div class="feature-icon">🥖</div>
					<h3><?php esc_html_e( 'Fresh-Baked Bun Maska', 'irani-cafe' ); ?></h3>
					<p><?php esc_html_e( 'Baked in-house every morning, served warm with a slab of creamy butter.', 'irani-cafe' ); ?></p>
				</div>
				<div class="feature-card">
					<div class="feature-icon">🪑</div>
					<h3><?php esc_html_e( 'Timeless Interiors', 'irani-cafe' ); ?></h3>
					<p><?php esc_html_e( 'Checkered floors, bentwood chairs and marble-top tables since day one.', 'irani-cafe' ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<!-- ============ MENU HIGHLIGHTS ============ -->
	<section id="menu" class="section">
		<div class="container">
			<div class="section-title">
				<span class="eyebrow"><?php esc_html_e( 'From The Kitchen', 'irani-cafe' ); ?></span>
				<h2><?php esc_html_e( 'Cafe Menu Highlights', 'irani-cafe' ); ?></h2>
				<p><?php esc_html_e( 'A handful of the classics our regulars simply cannot do without.', 'irani-cafe' ); ?></p>
			</div>

			<?php
			$menu_terms = get_terms( array( 'taxonomy' => 'menu_category', 'hide_empty' => true ) );
			if ( ! is_wp_error( $menu_terms ) && ! empty( $menu_terms ) ) :
				?>
				<div class="menu-tabs">
					<button class="menu-tab is-active" data-filter="all"><?php esc_html_e( 'All', 'irani-cafe' ); ?></button>
					<?php foreach ( $menu_terms as $term ) : ?>
						<button class="menu-tab" data-filter="<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php
			$menu_query = new WP_Query( array(
				'post_type'      => 'cafe_menu',
				'posts_per_page' => 8,
			) );
			?>

			<div class="grid grid-2">
				<?php if ( $menu_query->have_posts() ) : ?>
					<?php
					while ( $menu_query->have_posts() ) :
						$menu_query->the_post();
						$terms = get_the_terms( get_the_ID(), 'menu_category' );
						$slugs = ( $terms && ! is_wp_error( $terms ) ) ? implode( ',', wp_list_pluck( $terms, 'slug' ) ) : '';
						?>
						<div class="menu-item-card" data-menu-category="<?php echo esc_attr( $slugs ); ?>">
							<?php if ( has_post_thumbnail() ) : ?>
								<div class="menu-item-thumb"><?php the_post_thumbnail( 'irani-cafe-square' ); ?></div>
							<?php endif; ?>
							<div class="menu-item-body">
								<div class="menu-item-top">
									<h4><a href="<?php the_permalink(); ?>" style="color:inherit;"><?php the_title(); ?></a></h4>
									<span class="menu-item-price"><?php echo esc_html( irani_cafe_get_price( get_the_ID() ) ); ?></span>
								</div>
								<p class="menu-item-desc"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 14 ) ); ?></p>
							</div>
						</div>
						<?php
					endwhile;
					wp_reset_postdata();
					?>
				<?php else : ?>
					<p style="grid-column:1/-1;text-align:center;color:var(--cafe-brown-soft);">
						<?php esc_html_e( 'Add items under Cafe Menu in wp-admin to display them here.', 'irani-cafe' ); ?>
					</p>
				<?php endif; ?>
			</div>

			<p style="text-align:center;margin-top:2.4rem;">
				<a class="btn" href="<?php echo esc_url( get_post_type_archive_link( 'cafe_menu' ) ); ?>"><?php esc_html_e( 'View Full Menu', 'irani-cafe' ); ?></a>
			</p>
		</div>
	</section>

	<!-- ============ GALLERY ============ -->
	<section class="section section-dark">
		<div class="container">
			<div class="section-title">
				<span class="eyebrow"><?php esc_html_e( 'Moments', 'irani-cafe' ); ?></span>
				<h2><?php esc_html_e( 'Inside The Cafe', 'irani-cafe' ); ?></h2>
			</div>
			<div class="grid gallery-strip">
				<?php for ( $i = 1; $i <= 8; $i++ ) : ?>
					<a href="<?php echo esc_url( get_template_directory_uri() . '/assets/images/gallery-placeholder.svg' ); ?>">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/gallery-placeholder.svg' ); ?>" alt="<?php esc_attr_e( 'Cafe gallery photo', 'irani-cafe' ); ?>" loading="lazy">
					</a>
				<?php endfor; ?>
			</div>
		</div>
	</section>

	<!-- ============ TESTIMONIALS ============ -->
	<section class="section section-cream">
		<div class="container">
			<div class="section-title">
				<span class="eyebrow"><?php esc_html_e( 'Guest Notes', 'irani-cafe' ); ?></span>
				<h2><?php esc_html_e( 'What People Say Over Chai', 'irani-cafe' ); ?></h2>
			</div>
			<div class="grid grid-3">
				<?php
				$testimonials = array(
					array( __( 'The bun maska here tastes exactly like it did when I was a child. Nothing has changed, and I love that.', 'irani-cafe' ), __( 'Farah D.', 'irani-cafe' ), __( 'Regular since 2004', 'irani-cafe' ) ),
					array( __( 'Best Irani chai in the city, hands down. The old bentwood chairs make it even better.', 'irani-cafe' ), __( 'Ankit S.', 'irani-cafe' ), __( 'Food Blogger', 'irani-cafe' ) ),
					array( __( 'A little piece of history tucked into a busy street. Always my first stop when in town.', 'irani-cafe' ), __( 'Meher K.', 'irani-cafe' ), __( 'Traveler', 'irani-cafe' ) ),
				);
				foreach ( $testimonials as $t ) :
					?>
					<div class="testimonial-card">
						<p>"<?php echo esc_html( $t[0] ); ?>"</p>
						<div class="testimonial-author">
							<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/avatar-placeholder.svg' ); ?>" alt="">
							<div>
								<strong><?php echo esc_html( $t[1] ); ?></strong>
								<span><?php echo esc_html( $t[2] ); ?></span>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- ============ CTA ============ -->
	<section class="section">
		<div class="container">
			<div class="cta-banner">
				<h2><?php esc_html_e( 'Craving Some Chai Already?', 'irani-cafe' ); ?></h2>
				<p><?php esc_html_e( 'Walk in, or call ahead to reserve your favourite corner table.', 'irani-cafe' ); ?></p>
				<a href="#contact" class="btn" style="background:var(--cafe-brown);border-color:var(--cafe-brown);"><?php esc_html_e( 'Get Directions', 'irani-cafe' ); ?></a>
			</div>
		</div>
	</section>

	<!-- ============ CONTACT ============ -->
	<section id="contact" class="section section-cream">
		<div class="container">
			<div class="section-title">
				<span class="eyebrow"><?php esc_html_e( 'Visit Us', 'irani-cafe' ); ?></span>
				<h2><?php esc_html_e( 'Come Say Hello', 'irani-cafe' ); ?></h2>
			</div>
			<div class="grid contact-grid">
				<div class="contact-info">
					<ul class="contact-info-list">
						<li><span class="dot">📍</span><span><?php echo esc_html( get_theme_mod( 'irani_cafe_address', __( '12 Camac Street, Kolkata', 'irani-cafe' ) ) ); ?></span></li>
						<li><span class="dot">📞</span><span><?php echo esc_html( get_theme_mod( 'irani_cafe_phone', '+91 98765 43210' ) ); ?></span></li>
						<li><span class="dot">✉️</span><span><?php echo esc_html( get_theme_mod( 'irani_cafe_email', 'hello@iranicafe.test' ) ); ?></span></li>
						<li><span class="dot">🕐</span><span><?php echo esc_html( get_theme_mod( 'irani_cafe_hours', __( 'Mon–Sun: 7:00 AM – 10:30 PM', 'irani-cafe' ) ) ); ?></span></li>
					</ul>
					<?php $map_url = get_theme_mod( 'irani_cafe_map_url' ); ?>
					<?php if ( $map_url ) : ?>
						<div class="map-embed">
							<iframe src="<?php echo esc_url( $map_url ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="<?php esc_attr_e( 'Cafe location map', 'irani-cafe' ); ?>"></iframe>
						</div>
					<?php endif; ?>
				</div>
				<div class="contact-form-wrap">
					<?php
					// Native WP: shows shortcode hint if no form plugin/shortcode is set; otherwise render simple mailto-based form.
					if ( shortcode_exists( 'contact-form-7' ) ) {
						echo do_shortcode( '[contact-form-7 id="" title="Contact form"]' );
					} else {
						?>
						<form class="contact-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
							<input type="hidden" name="action" value="irani_cafe_contact">
							<?php wp_nonce_field( 'irani_cafe_contact_nonce' ); ?>
							<input type="text" name="contact_name" placeholder="<?php esc_attr_e( 'Your Name', 'irani-cafe' ); ?>" required>
							<input type="email" name="contact_email" placeholder="<?php esc_attr_e( 'Your Email', 'irani-cafe' ); ?>" required>
							<textarea name="contact_message" placeholder="<?php esc_attr_e( 'Your Message', 'irani-cafe' ); ?>" required></textarea>
							<button type="submit" class="btn btn-mustard"><?php esc_html_e( 'Send Message', 'irani-cafe' ); ?></button>
						</form>
						<?php
					}
					?>
				</div>
			</div>
		</div>
	</section>

</main><!-- #primary -->

<?php
get_footer();
