<?php
/**
 * The template for displaying archive pages (categories, tags, dates, CPT archives).
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main content-area">
	<div class="container">

		<header class="page-header">
			<div class="section-title" style="margin-bottom:1rem;">
				<span class="eyebrow"><?php esc_html_e( 'Archive', 'irani-cafe' ); ?></span>
				<h1 class="page-title"><?php the_archive_title(); ?></h1>
				<?php the_archive_description( '<div class="archive-description">', '</div>' ); ?>
			</div>
		</header>

		<div class="content-layout">
			<div class="content-main">

				<?php if ( have_posts() ) : ?>

					<?php if ( 'cafe_menu' === get_post_type() ) : ?>

						<div class="grid grid-2">
							<?php
							while ( have_posts() ) :
								the_post();
								?>
								<div class="menu-item-card" data-menu-category="<?php echo esc_attr( implode( ',', wp_list_pluck( get_the_terms( get_the_ID(), 'menu_category' ) ?: array(), 'slug' ) ) ); ?>">
									<?php if ( has_post_thumbnail() ) : ?>
										<div class="menu-item-thumb">
											<?php the_post_thumbnail( 'irani-cafe-square' ); ?>
										</div>
									<?php endif; ?>
									<div class="menu-item-body">
										<div class="menu-item-top">
											<h4><a href="<?php the_permalink(); ?>" style="color:inherit;"><?php the_title(); ?></a></h4>
											<span class="menu-item-price"><?php echo esc_html( irani_cafe_get_price( get_the_ID() ) ); ?></span>
										</div>
										<p class="menu-item-desc"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 16 ) ); ?></p>
									</div>
								</div>
								<?php
							endwhile;
							?>
						</div>

					<?php else : ?>

						<?php while ( have_posts() ) : the_post(); ?>
							<?php get_template_part( 'template-parts/content' ); ?>
						<?php endwhile; ?>

					<?php endif; ?>

					<?php irani_cafe_pagination(); ?>

				<?php else : ?>
					<p><?php esc_html_e( 'Nothing found here yet.', 'irani-cafe' ); ?></p>
				<?php endif; ?>

			</div>

			<?php get_sidebar(); ?>
		</div>

	</div>
</main><!-- #primary -->

<?php
get_footer();
