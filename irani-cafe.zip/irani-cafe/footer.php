<?php
/**
 * The footer for the theme.
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
	<footer id="colophon" class="site-footer">
		<div class="container">
			<div class="grid footer-grid">

				<div class="footer-brand">
					<?php if ( has_custom_logo() ) : ?>
						<?php the_custom_logo(); ?>
					<?php endif; ?>
					<p class="site-title" style="font-family:var(--font-heading);font-size:1.4rem;">
						<?php bloginfo( 'name' ); ?>
					</p>
					<p><?php echo esc_html( get_theme_mod( 'irani_cafe_hero_text', __( 'A cosy corner cafe serving old-world charm, one cup of chai at a time.', 'irani-cafe' ) ) ); ?></p>
					<div class="social-links">
						<?php
						$socials = array(
							'irani_cafe_facebook'  => 'f',
							'irani_cafe_instagram' => '◎',
							'irani_cafe_twitter'   => '𝕏',
						);
						foreach ( $socials as $mod => $icon ) :
							$url = get_theme_mod( $mod );
							if ( $url ) :
								?>
								<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $mod ); ?>"><?php echo esc_html( $icon ); ?></a>
							<?php endif; endforeach; ?>
					</div>
				</div>

				<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
					<div class="footer-col"><?php dynamic_sidebar( 'footer-1' ); ?></div>
				<?php else : ?>
					<div class="footer-col">
						<h4 class="footer-widget-title"><?php esc_html_e( 'Explore', 'irani-cafe' ); ?></h4>
						<?php
						wp_nav_menu( array(
							'theme_location' => 'footer',
							'container'      => false,
							'menu_class'     => 'menu',
							'fallback_cb'    => 'irani_cafe_fallback_menu',
						) );
						?>
					</div>
				<?php endif; ?>

				<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
					<div class="footer-col"><?php dynamic_sidebar( 'footer-2' ); ?></div>
				<?php else : ?>
					<div class="footer-col">
						<h4 class="footer-widget-title"><?php esc_html_e( 'Timings', 'irani-cafe' ); ?></h4>
						<p><?php echo esc_html( get_theme_mod( 'irani_cafe_hours', __( 'Mon–Sun: 7:00 AM – 10:30 PM', 'irani-cafe' ) ) ); ?></p>
					</div>
				<?php endif; ?>

				<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
					<div class="footer-col"><?php dynamic_sidebar( 'footer-3' ); ?></div>
				<?php else : ?>
					<div class="footer-col">
						<h4 class="footer-widget-title"><?php esc_html_e( 'Visit Us', 'irani-cafe' ); ?></h4>
						<p>
							<?php echo esc_html( get_theme_mod( 'irani_cafe_address', __( '12 Camac Street, Kolkata', 'irani-cafe' ) ) ); ?><br>
							<?php echo esc_html( get_theme_mod( 'irani_cafe_phone', '+91 98765 43210' ) ); ?><br>
							<a href="mailto:<?php echo esc_attr( get_theme_mod( 'irani_cafe_email', 'hello@iranicafe.test' ) ); ?>"><?php echo esc_html( get_theme_mod( 'irani_cafe_email', 'hello@iranicafe.test' ) ); ?></a>
						</p>
					</div>
				<?php endif; ?>

			</div>
		</div>

		<div class="container">
			<div class="site-footer-bottom">
				<p>&copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'irani-cafe' ); ?></p>
				<p><?php esc_html_e( 'Made with', 'irani-cafe' ); ?> ♡ &amp; <?php esc_html_e( 'chai', 'irani-cafe' ); ?></p>
			</div>
		</div>
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
