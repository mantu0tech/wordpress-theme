=== Irani Cafe ===
Contributors: iranicafestudio
Tags: custom-menu, custom-logo, featured-images, threaded-comments, translation-ready, food-and-drink
Requires at least: 5.9
Tested up to: 6.6
Requires PHP: 7.4
Version: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A warm, modern, fully responsive WordPress theme for Irani cafes, bakeries and restaurants — built entirely with native WordPress template functions.

== Description ==

Irani Cafe is a clean, vintage-inspired theme designed for cafes, tea houses, bakeries and restaurants. It ships with:

* A designed homepage (front-page.php) with hero, about, menu highlights, gallery, testimonials, CTA and contact sections
* A custom "Cafe Menu" post type with categories (Chai, Snacks, Bakery, etc.) and a price field — manage your food menu right from wp-admin
* Native WordPress custom logo, custom menus (Primary + Footer), and 4 widget areas (Blog Sidebar + 3 Footer columns)
* Fully responsive, mobile-first layout with an accessible slide-in mobile navigation
* Threaded comments, search, 404, archive and blog templates
* Theme Customizer panels for Hero content, Contact info and Social links — no page builder required
* Translation-ready (text domain: irani-cafe)

== Installation ==

1. Download the theme as a .zip file (irani-cafe.zip).
2. In your WordPress dashboard go to Appearance > Themes > Add New > Upload Theme.
3. Choose the irani-cafe.zip file and click Install Now, then Activate.
4. Go to Appearance > Customize to:
   - Upload your logo (Site Identity)
   - Set your Hero heading, description and image (Hero Section)
   - Add your address, phone, email, hours and map embed URL (Cafe Contact Info)
   - Add your social links (Social Links)
5. Go to Appearance > Menus and create a "Primary" menu and a "Footer" menu, then assign them to their locations.
6. Go to Cafe Menu (in the left admin sidebar) > Add New to start adding your food & drink items. Assign a Menu Category (Chai, Bakery, Snacks, etc.), set a featured image, and fill in the Price field in the sidebar.
7. Create pages (About, Contact, Blog) via Pages > Add New, and set your Blog page under Settings > Reading if desired.
8. Widgets can be arranged under Appearance > Widgets (Blog Sidebar, Footer Column 1/2/3).

== Frequently Asked Questions ==

= Does this theme require any plugins? =

No. Everything — the custom post type, customizer options, widgets and menus — is built with native WordPress functions. If Contact Form 7 is active, the homepage contact form will automatically use it; otherwise a built-in fallback form (via admin-post.php + wp_mail) is used.

= How do I change the colors? =

Colors are defined as CSS variables at the top of style.css under `:root`. Edit the `--cafe-*` variables to re-theme the whole site.

= Where do I add my Google Maps embed? =

Appearance > Customize > Cafe Contact Info > Google Maps Embed URL. Paste the "src" URL from Google Maps' Share > Embed a map option.

== Changelog ==

= 1.0.0 =
* Initial release.

== Credits ==

* Fonts: Playfair Display & Work Sans (Google Fonts, SIL Open Font License).
* All placeholder illustrations are custom-made SVGs included with the theme; replace with your own photography before launch.
