<?php
/**
 * Custom template tags for this theme.
 *
 * @package Irani_Cafe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'irani_cafe_posted_on' ) ) {
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	function irani_cafe_posted_on() {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() )
		);
		echo '<span class="posted-on"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a></span>'; // phpcs:ignore
	}
}

if ( ! function_exists( 'irani_cafe_posted_by' ) ) {
	/**
	 * Prints HTML with meta information for the current author.
	 */
	function irani_cafe_posted_by() {
		echo '<span class="byline"> ' . esc_html__( 'by', 'irani-cafe' ) . ' <a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>';
	}
}

if ( ! function_exists( 'irani_cafe_entry_footer' ) ) {
	/**
	 * Prints category, tag and comment info for a post.
	 */
	function irani_cafe_entry_footer() {
		if ( 'post' === get_post_type() ) {
			$categories_list = get_the_category_list( ', ' );
			if ( $categories_list ) {
				printf( '<span class="cat-links">' . esc_html__( 'In %1$s', 'irani-cafe' ) . '</span>', $categories_list ); // phpcs:ignore
			}

			$tags_list = get_the_tag_list( '', ', ' );
			if ( $tags_list ) {
				printf( '<span class="tag-links">' . esc_html__( 'Tagged %1$s', 'irani-cafe' ) . '</span>', $tags_list ); // phpcs:ignore
			}
		}

		if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
			echo '<span class="comments-link">';
			comments_popup_link(
				esc_html__( 'Leave a comment', 'irani-cafe' ),
				esc_html__( '1 Comment', 'irani-cafe' ),
				esc_html__( '% Comments', 'irani-cafe' )
			);
			echo '</span>';
		}
	}
}

if ( ! function_exists( 'irani_cafe_the_post_thumbnail' ) ) {
	/**
	 * Displays featured image markup wrapped for card styling.
	 */
	function irani_cafe_the_post_thumbnail( $size = 'large' ) {
		if ( ! has_post_thumbnail() ) {
			return;
		}
		if ( is_singular() ) {
			echo '<div class="single-thumb">';
			the_post_thumbnail( $size, array( 'class' => 'single-thumb-img' ) );
			echo '</div>';
		} else {
			echo '<a class="post-thumb" href="' . esc_url( get_permalink() ) . '" aria-hidden="true" tabindex="-1">';
			the_post_thumbnail( $size );
			echo '</a>';
		}
	}
}

if ( ! function_exists( 'irani_cafe_pagination' ) ) {
	/**
	 * Numeric pagination for archives/blog.
	 */
	function irani_cafe_pagination() {
		the_posts_pagination( array(
			'mid_size'  => 2,
			'prev_text' => esc_html__( '&larr; Previous', 'irani-cafe' ),
			'next_text' => esc_html__( 'Next &rarr;', 'irani-cafe' ),
			'class'     => 'pagination',
		) );
	}
}
