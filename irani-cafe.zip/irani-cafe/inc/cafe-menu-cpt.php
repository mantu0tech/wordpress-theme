<?php
/**
 * Cafe Menu custom post type, taxonomy and price meta box.
 * Lets the cafe owner manage their food & drink menu natively from wp-admin.
 *
 * @package Irani_Cafe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the "Cafe Menu" custom post type.
 */
function irani_cafe_register_menu_cpt() {

	$labels = array(
		'name'               => esc_html__( 'Cafe Menu', 'irani-cafe' ),
		'singular_name'      => esc_html__( 'Menu Item', 'irani-cafe' ),
		'add_new_item'       => esc_html__( 'Add New Menu Item', 'irani-cafe' ),
		'edit_item'          => esc_html__( 'Edit Menu Item', 'irani-cafe' ),
		'new_item'           => esc_html__( 'New Menu Item', 'irani-cafe' ),
		'view_item'          => esc_html__( 'View Menu Item', 'irani-cafe' ),
		'search_items'       => esc_html__( 'Search Menu Items', 'irani-cafe' ),
		'not_found'          => esc_html__( 'No menu items found', 'irani-cafe' ),
		'menu_name'          => esc_html__( 'Cafe Menu', 'irani-cafe' ),
	);

	register_post_type( 'cafe_menu', array(
		'labels'        => $labels,
		'public'        => true,
		'has_archive'   => true,
		'rewrite'       => array( 'slug' => 'cafe-menu' ),
		'menu_icon'     => 'dashicons-coffee',
		'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
		'show_in_rest'  => true,
	) );

	register_taxonomy( 'menu_category', 'cafe_menu', array(
		'labels'            => array(
			'name'          => esc_html__( 'Menu Categories', 'irani-cafe' ),
			'singular_name' => esc_html__( 'Menu Category', 'irani-cafe' ),
		),
		'hierarchical'      => true,
		'show_admin_column' => true,
		'show_in_rest'      => true,
		'rewrite'           => array( 'slug' => 'menu-category' ),
	) );
}
add_action( 'init', 'irani_cafe_register_menu_cpt' );

/**
 * Price meta box.
 */
function irani_cafe_add_price_meta_box() {
	add_meta_box(
		'irani_cafe_price',
		esc_html__( 'Price', 'irani-cafe' ),
		'irani_cafe_price_meta_box_html',
		'cafe_menu',
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'irani_cafe_add_price_meta_box' );

function irani_cafe_price_meta_box_html( $post ) {
	wp_nonce_field( 'irani_cafe_save_price', 'irani_cafe_price_nonce' );
	$price = get_post_meta( $post->ID, '_irani_cafe_price', true );
	echo '<label for="irani_cafe_price_field" class="screen-reader-text">' . esc_html__( 'Price', 'irani-cafe' ) . '</label>';
	echo '<input type="text" id="irani_cafe_price_field" name="irani_cafe_price_field" value="' . esc_attr( $price ) . '" placeholder="e.g. ₹120" style="width:100%;" />';
}

function irani_cafe_save_price( $post_id ) {
	if ( ! isset( $_POST['irani_cafe_price_nonce'] ) || ! wp_verify_nonce( $_POST['irani_cafe_price_nonce'], 'irani_cafe_save_price' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( isset( $_POST['irani_cafe_price_field'] ) ) {
		update_post_meta( $post_id, '_irani_cafe_price', sanitize_text_field( $_POST['irani_cafe_price_field'] ) );
	}
}
add_action( 'save_post_cafe_menu', 'irani_cafe_save_price' );

/**
 * Helper: get the price for a menu item.
 */
function irani_cafe_get_price( $post_id ) {
	return get_post_meta( $post_id, '_irani_cafe_price', true );
}
