<?php
/**
 * Theme Customizer settings — hero section text, contact details, social links.
 * All native use of the WordPress Customize API.
 *
 * @package Irani_Cafe
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function irani_cafe_customize_register( $wp_customize ) {

	/* ---------------- Hero Section Panel ---------------- */
	$wp_customize->add_section( 'irani_cafe_hero_section', array(
		'title'    => esc_html__( 'Hero Section', 'irani-cafe' ),
		'priority' => 30,
	) );

	$wp_customize->add_setting( 'irani_cafe_hero_eyebrow', array(
		'default'           => esc_html__( 'Est. 1962 · Since Generations', 'irani-cafe' ),
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'irani_cafe_hero_eyebrow', array(
		'label'   => esc_html__( 'Eyebrow Text', 'irani-cafe' ),
		'section' => 'irani_cafe_hero_section',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'irani_cafe_hero_title', array(
		'default'           => esc_html__( 'Bun Maska, Irani Chai & Old-World Charm', 'irani-cafe' ),
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'irani_cafe_hero_title', array(
		'label'   => esc_html__( 'Hero Heading', 'irani-cafe' ),
		'section' => 'irani_cafe_hero_section',
		'type'    => 'text',
	) );

	$wp_customize->add_setting( 'irani_cafe_hero_text', array(
		'default'           => esc_html__( 'A cosy corner cafe serving the city\'s finest bun-maska, keema pav, and slow-brewed Irani chai since generations. Pull up a bentwood chair and stay a while.', 'irani-cafe' ),
		'sanitize_callback' => 'sanitize_textarea_field',
	) );
	$wp_customize->add_control( 'irani_cafe_hero_text', array(
		'label'   => esc_html__( 'Hero Description', 'irani-cafe' ),
		'section' => 'irani_cafe_hero_section',
		'type'    => 'textarea',
	) );

	$wp_customize->add_setting( 'irani_cafe_hero_image', array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
	) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'irani_cafe_hero_image', array(
		'label'   => esc_html__( 'Hero Image', 'irani-cafe' ),
		'section' => 'irani_cafe_hero_section',
	) ) );

	/* ---------------- Contact Info Panel ---------------- */
	$wp_customize->add_section( 'irani_cafe_contact_section', array(
		'title'    => esc_html__( 'Cafe Contact Info', 'irani-cafe' ),
		'priority' => 35,
	) );

	$fields = array(
		'irani_cafe_address' => array( esc_html__( 'Address', 'irani-cafe' ), esc_html__( '12 Camac Street, Kolkata', 'irani-cafe' ) ),
		'irani_cafe_phone'   => array( esc_html__( 'Phone', 'irani-cafe' ), '+91 98765 43210' ),
		'irani_cafe_email'   => array( esc_html__( 'Email', 'irani-cafe' ), 'hello@iranicafe.test' ),
		'irani_cafe_hours'   => array( esc_html__( 'Opening Hours', 'irani-cafe' ), esc_html__( 'Mon–Sun: 7:00 AM – 10:30 PM', 'irani-cafe' ) ),
		'irani_cafe_map_url' => array( esc_html__( 'Google Maps Embed URL', 'irani-cafe' ), '' ),
	);

	foreach ( $fields as $id => $data ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $data[1],
			'sanitize_callback' => 'sanitize_text_field',
		) );
		$wp_customize->add_control( $id, array(
			'label'   => $data[0],
			'section' => 'irani_cafe_contact_section',
			'type'    => 'text',
		) );
	}

	/* ---------------- Social Links Panel ---------------- */
	$wp_customize->add_section( 'irani_cafe_social_section', array(
		'title'    => esc_html__( 'Social Links', 'irani-cafe' ),
		'priority' => 40,
	) );

	$socials = array(
		'irani_cafe_facebook'  => esc_html__( 'Facebook URL', 'irani-cafe' ),
		'irani_cafe_instagram' => esc_html__( 'Instagram URL', 'irani-cafe' ),
		'irani_cafe_twitter'   => esc_html__( 'Twitter / X URL', 'irani-cafe' ),
	);

	foreach ( $socials as $id => $label ) {
		$wp_customize->add_setting( $id, array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		) );
		$wp_customize->add_control( $id, array(
			'label'   => $label,
			'section' => 'irani_cafe_social_section',
			'type'    => 'url',
		) );
	}
}
add_action( 'customize_register', 'irani_cafe_customize_register' );
