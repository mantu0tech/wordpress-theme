<?php
/**
 * The main template file.
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main content-area">
	<div class="container">

		<?php if ( is_home() && ! is_front_page() ) : ?>
			<header class="page-header">
				<h1 class="page-title"><?php single_post_title(); ?></h1>
			</header>
		<?php endif; ?>

		<div class="content-layout">
			<div class="content-main">

				<?php if ( have_posts() ) : ?>

					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'template-parts/content' ); ?>
					<?php endwhile; ?>

					<?php irani_cafe_pagination(); ?>

				<?php else : ?>

					<p><?php esc_html_e( 'No posts have been published yet. Check back soon!', 'irani-cafe' ); ?></p>

				<?php endif; ?>

			</div>

			<?php get_sidebar(); ?>
		</div>

	</div>
</main><!-- #primary -->

<?php
get_footer();
