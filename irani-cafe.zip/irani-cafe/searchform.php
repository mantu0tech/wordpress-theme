<?php
/**
 * Search form template.
 *
 * @package Irani_Cafe
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="s"><?php esc_html_e( 'Search for:', 'irani-cafe' ); ?></label>
	<input type="search" id="s" name="s" placeholder="<?php esc_attr_e( 'Search the menu, blog…', 'irani-cafe' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" required>
	<button type="submit" class="btn"><?php esc_html_e( 'Search', 'irani-cafe' ); ?></button>
</form>
